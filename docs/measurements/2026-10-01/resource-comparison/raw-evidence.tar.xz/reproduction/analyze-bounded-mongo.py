import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

BASE=Path('.testdata/resource-comparison-20261001')
ROOT=BASE/'mongo-bounded';PREP=BASE/'mongo-bounded-prep'
summary=json.loads((ROOT/'summary.json').read_text());OWNER=summary['owner'];LABEL='weir.load-comparison.owner'
ENV=dict(os.environ);ENV['KUBECTL_REMOTE_COMMAND_WEBSOCKETS']='false'
sys.path.insert(0,str(Path('scripts').resolve()))
spec=importlib.util.spec_from_file_location('common',Path('scripts/compare-load.py'));common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
source=(BASE/'finish-bounded-mongo.py').read_text()
syntax=ast.parse(source)
definitions=[n for n in syntax.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
module=ast.Module(body=definitions,type_ignores=[])
exec(compile(module,'finish-bounded-mongo.py','exec'))
archive=ROOT/'download.tar.gz'
if hashlib.sha256(archive.read_bytes()).hexdigest()!=(ROOT/'download.sha256').read_text().strip():raise RuntimeError('archive checksum mismatch')
cases=json.loads((ROOT/'cases.json').read_text())
exec(source[source.index("with tarfile.open(archive,'r:gz')"):])
