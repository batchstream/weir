import json
from pathlib import Path

root=Path('.testdata/resource-comparison-20261001')
x=json.loads((root/'resource-summary.json').read_text())
out=Path('docs/resource-load-test-2026-10-01.md')
evidence='measurements/2026-10-01/resource-comparison'
def med(c,k):return c[k]['median']
def interval(c,k,dec=0):
 s=c[k];return f"{s['median']:.{dec}f} [{s['minimum']:.{dec}f}–{s['maximum']:.{dec}f}]"
def cell(group,w,rate,mode):return next(c for c in x['cells'] if (c['group'],c['write_every'],c['offered_rps'],c['mode'])==(group,w,rate,mode))
def delta(group,w,key):
 a=med(cell(group,w,3200,'direct'),key);b=med(cell(group,w,3200,'weir'),key)
 return (b/a-1)*100
rows=[]
for c in x['cells']:
 rows.append('| '+ ' | '.join([c['group'], '90% 读 / 10% 写' if c['write_every']==10 else '纯写', str(c['offered_rps']), c['mode'],
   interval(c,'success_rps',1),interval(c,'p95_ms',1),interval(c,'db_cpu_cores',3),interval(c,'db_rss_mib',1),
   interval(c,'weir_cpu_cores',3) if c['mode']=='weir' else '—',interval(c,'weir_rss_mib',1) if c['mode']=='weir' else '—',
   f"{c['totals']['offered_loss_percent']:.2f}%"])+' |')
memrows=[]
for c in x['cells']:
 if c['offered_rps']!=3200:continue
 memrows.append('| '+ ' | '.join([c['group'],'混合' if c['write_every']==10 else '纯写',c['mode'],interval(c,'db_cgroup_memory_mib',1),
     interval(c,'weir_cgroup_memory_mib',1) if c['mode']=='weir' else '—',interval(c,'client_cpu_cores',3),interval(c,'client_rss_mib',1)])+' |')
counts={key:sum(c['totals'][key] for c in x['cells']) for key in ('planned','success','client_drop','unknown','api_failures')}
audit_applied=sum(c['audit_applied'] for c in x['cells']);audit_found=sum(c['audit_found'] for c in x['cells'])
errors=[e for c in x['cells'] for e in c['observer_errors']]
text=f'''# 有限资源下直连与 Weir 的 MongoDB / Elasticsearch 实测

测试日期：2026-10-01 至 2026-10-02（北京时间）。生产 Weir 源码为 `614eb443e298ffc531507a32743b15f5a4baea00`，本次只补充测试工具和测量报告，没有修改生产调度逻辑。

两种数据库分别在同一实例上比较直连与 Weir。数据库限制为 **0.25 核 CPU、1,536 MiB 内存**，Weir 为 **0.5 核、768 MiB**；另对 Elasticsearch 增加 Weir 1 核的复测。每个条件交替顺序 AB、BA、AB，三次测量，每次预热 10 秒、正式测量 20 秒。

在 3,200 次/秒的压力下，MongoDB 混合读写通过 Weir 的吞吐变化为 {delta('mongo-cpu0.5',10,'success_rps'):+.1f}%，纯写为 {delta('mongo-cpu0.5',1,'success_rps'):+.1f}%。Elasticsearch 的 0.5 核 Weir 在混合读写 / 纯写中分别变化 {delta('es-cpu0.5',10,'success_rps'):+.1f}% / {delta('es-cpu0.5',1,'success_rps'):+.1f}%。数据库 CPU 的降低不能单独视为节省资源，必须同时计算 Weir 自身 CPU 和未完成的负载。

Elasticsearch 给 Weir 1 核后，纯写吞吐中位数提高 {delta('es-cpu1',1,'success_rps'):.1f}%，数据库 CPU 变化 {delta('es-cpu1',1,'db_cpu_cores'):+.1f}%，但 Weir 自身使用约 {med(cell('es-cpu1',1,3200,'weir'),'weir_cpu_cores'):.2f} 核。混合读写在三对测试中没有一致收益。1 核组与 0.5 核组各有自己的直连基线，不能把不同组直接拼成 CPU 配额变化的因果结论。

## 结果

以下为三次测量的中位数，方括号为实际最小值到最大值；不是置信区间。CPU 单位为核，0.25 表示占满数据库配额。内存单位为 MiB，RSS 为各测量窗口内采样峰值的三次中位数。p95 从计划到达时刻算起，包含客户端及 Weir 排队，只统计成功操作，数值是直方图桶上界。丢失率为三次计划操作中未成功的比例，包含发出请求前的客户端丢弃。

| 组 | 负载 | 计划次/秒 | 路径 | 成功次/秒 | p95 ms | DB CPU 核 | DB RSS MiB | Weir CPU 核 | Weir RSS MiB | 未成功比例 |
| --- | --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

`mongo-cpu0.5` 在 EKS 测量，`es-cpu0.5` 和 `es-cpu1` 在本地 Docker 测量。不同数据库的绝对吞吐不能用来判断 MongoDB 和 Elasticsearch 的性能优劣。

容器内存包含文件缓存、tmpfs 数据等，与进程 RSS 含义不同。共享代码页可能计入祖先 cgroup 或首次加载它的容器，所以某个容器的 memory.current 也可能低于该进程 RSS，不能把两者相加。下面另列压力档的容器内存和负载生成器资源，方便检查是否把客户端瓶颈误认为数据库瓶颈。

| 组 | 负载 | 路径 | DB 容器内存 MiB | Weir 容器内存 MiB | 客户端 CPU 核 | 客户端 RSS MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
{chr(10).join(memrows)}

## 测量方法与边界

- Elasticsearch 8.19.22，镜像 ID `sha256:a1cc67962f24c058c854acc6aab0d0adaefefc945c0bfaaebb52aba6129de160`。JVM 堆 512 MiB，一个写线程，队列 200，一个主分片，无副本。字段不索引，按 ID 实时读取，写入不等待 refresh，translog durability=request，数据目录为独占 1 GiB tmpfs。
- MongoDB 8.0.32，镜像固定为 `mongo@sha256:4968f22d0c6c10ef29952f3e807f62872ba22b3312f25803564fbfc08255efc2`。单主节点 replica set，WiredTiger 缓存 256 MiB，oplog 固定为 64 MiB，majority 写确认，保留默认 journal 配置，数据目录为独占 1 GiB 内存 emptyDir。主节点与客户端、Weir 在同一 Pod，通过 localhost 通信；EKS 节点上还运行其他工作负载，本文不把该节点视为独占硬件。
- 本地 Docker 的 Linux 内核为 7.0.12，MongoDB 拒绝在该内核启动；[MongoDB 官方发布说明](https://www.mongodb.com/docs/manual/release-notes/8.0/)列出 6.19–7.0.13 的不兼容范围。因此没有绕过启动检查，改用已有 EKS 上独占的临时 namespace；节点内核及镜像实际身份保存在原始 provenance 中。
- 负载为确定性的 1 KiB 文档；混合负载读取 1,000 个预建键，并使用 Put 写入唯一新键。MongoDB 两条路径使用相同的 BSON 和 replacement-upsert 语义：直连也调用客户端 bulkWrite（每次一条），Weir 可聚合多条。MongoDB 的 [majority 及 journaling 语义](https://www.mongodb.com/docs/manual/reference/write-concern/)使用默认配置。
- Weir 使用当前 `routeclient.Record` API：每条操作创建一个有限 Route 会话，四条复用 gRPC 连接，最多八个并行客户端 worker / Route 会话；这不是长期复用 Route 的流式吞吐测试。后端并发上限四，最大批次 16。Weir 是一个进程，没有 Lua 子进程。
- 768 MiB 是本次 Weir 配置的内存预算和容器限制，不等于实际 RSS。八个 Route 会话具有显式预算；不能只根据约几十 MiB 的 RSS 将容器限制降至 256 MiB 并期望相同会话容量。
- 固定开环到达率为 800 和 3,200 次/秒；客户端两核、2,048 MiB，队列上限 256，到达过期 100 ms，单请求截止时间从计划到达算起为一秒，无业务重试。先通过纯 pacing 验证：无丢弃，唤醒 p99 不超过 5 ms。低负载组用来观察开销，压力组用来观察吞吐、丢弃和资源上限。
- 各试验重新创建任务独占的集合 / 索引及读取样本；各负载先分别通过直连与真实生产 Weir 路径训练 20 秒。ES 初始化 / 训练时数据库为一核，正式测量为 0.25 核；MongoDB 始终为 0.25 核。ES 每次启动新的 Weir 进程；MongoDB 为同一个 Weir 进程连续测试，RSS 可反映此前试验的 Go 堆保留。MongoDB 直连试验中 Weir 保持空闲，后台拓扑监控可能产生少量数据库负载。
- 数据库 CPU 使用 `/proc` 进程 CPU ticks 的差值，RSS 使用 `/proc` 页数。ES 的 Weir CPU / RSS 使用自身进程指标；MongoDB 的 Weir 使用 `/proc`。容器另采集 `cpu.stat`、`memory.current`、`memory.events`。进程 CPU 包含服务实际诊断开销，不包含外部采样 shell；容器 CPU 包含采样 shell。MongoDB 及 Weir 在各自容器内每秒采样，按负载开始的时间戳选取正式20秒窗口；原始时间戳和实际覆盖长度均保留，CPU 是采样平均值。
- ES 诊断及 Docker采样约一秒一次；MongoDB 使用额外的 Go 采样进程在容器内每秒记录 `/proc` 和 cgroup，每次正式测量至少十五点且首尾覆盖至少十五秒。数据库与 Weir 的进程 CPU / RSS 不包含该采样进程，容器资源包含其开销。MongoDB 整组试验在 Pod 内连续执行，控制连接只查询整体进度并取回文件；控制命令重试不重复启动已锁定的试验任务，数据库操作不重试。结果通过压缩归档传输及 SHA-256 校验，避免截断 stdout 被当成完整证据。

这些是短时、内存存储、按 ID 的读写测试，不能代表持久磁盘 I/O、完整业务索引、全文搜索、多副本网络、长期内存泄漏或生产最大容量。出现客户端丢弃的档位也不能称为无损可持续容量。吞吐按测量到达队列的成功数量除以20秒计算；请求可在原始一秒截止时间内排空，原始记录保留排空时间及含排空的保守吞吐。

## 正确性与清理

共 {sum(len(g['runs']) for g in x['groups'].values())} 次正式试验、{counts['planned']:,} 次计划测量操作，成功 {counts['success']:,} 次，客户端丢弃 {counts['client_drop']:,} 次，测量 API 失败 {counts['api_failures']:,} 次，UNKNOWN {counts['unknown']:,} 次。写后审计覆盖包括预热在内的所有计划写入；APPLIED 为 {audit_applied:,} 条，实际查到 {audit_found:,} 条，原始审计逐条校验内容。采样记录的 OOM kill 为 {sum(c['oom_kills'] for c in x['cells'])}；远程采样异常 {len(errors)} 条，保存在证据中。

正式组清理回执均通过：ES 独占容器、网络和二进制镜像已移除，Docker inventory 恢复；MongoDB 临时 namespace 已删除并确认不存在。测试准备失败的试验未计入结果，其清理回执另存。另一个未显式限定 oplog 的先行组自动创建了 990 MiB oplog，在纯写压力阶段写满 1 GiB 内存数据目录，日志明确记录 `No space left on device` 和 WiredTiger panic；该组未用于本文性能统计，其原始日志与资源记录保存在 `storage-limit-probe/`。正式 MongoDB 组显式配置 64 MiB oplog，以控制任务运行过程中累积的复制历史。

测试工具通过 `go test ./...`、`go test -race ./internal/testutil/testcapacity`、`go test -tags integration ./internal/testutil/testcapacity`、`go vet -tags integration ./internal/testutil/testcapacity` 以及 Python 的10项编排测试（普通与 `-O` 模式）。默认 Go 测试没有连接这两个临时数据库；上述现场负载试验是实际数据库验证。

## 证据与复现

- [完整汇总 JSON]({evidence}/resource-summary.json)：每次试验、成对变化、三次中位数和范围、资源采样统计、审计与清理回执。
- [构建和源码清单]({evidence}/build-manifest.json)：基础提交、Go 版本、构建命令、二进制及源码 SHA-256。
- [原始证据压缩包]({evidence}/raw-evidence.tar.xz)：客户端 JSONL、资源采样、日志、配置、数据库身份、任务清理回执、源码快照和 EKS 复现脚本，不包含二进制。
- [证据 SHA-256 清单]({evidence}/sha256.json)：归档内原始文件及最终交付文件的哈希。

用构建清单命令生成 Linux arm64 client / Weir 后，本地 ES 主组命令为：

```sh
python3 scripts/compare-load.py --client /absolute/path/client --weir /absolute/path/weir --output /absolute/path/es-result --rates 800,3200 --write-every 10,1 --modes direct,weir --repetitions 3 --warm 10 --seconds 20 --pool 4 --db-cpu 0.25 --weir-cpu 0.5 --prewarm
```

1 核复测将 `--weir-cpu` 改为 `1`，`--rates` 改为 `3200`，使用新的输出目录。Docker 内核运行 MongoDB 兼容时，追加 `--backend mongodb --mongo-image mongo@sha256:4968f22d0c6c10ef29952f3e807f62872ba22b3312f25803564fbfc08255efc2` 可使用同一个编排工具。跨环境复现优先使用上述 `scripts/compare-load.py` 命令。归档的 `mongo-bounded/pod.json`、`suite.sh`、`cases.json`、配置文件和 `reproduction/` 脚本记录了本次 EKS 环境、执行顺序、采样与恢复操作。EKS 脚本包含固定任务路径和运行时关联实例，用于核查本次流程；重新部署时需创建新的独占 namespace，按归档的资源限制、64 MiB oplog、同 Pod localhost 拓扑配置实例，并提供构建清单中的二进制。
'''
out.write_text(text)
print(out)
