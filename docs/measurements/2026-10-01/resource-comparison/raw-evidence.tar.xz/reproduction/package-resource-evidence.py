import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root=Path('.testdata/resource-comparison-20261001')
target=Path('docs/measurements/2026-10-01/resource-comparison')
target.mkdir(parents=True,exist_ok=True)
build=json.loads((root/'build-manifest.json').read_text())
for name,old in build['source_files'].items():
 if name.startswith('internal/') and hashlib.sha256(Path(name).read_bytes()).hexdigest()!=old:
  raise RuntimeError('client source drift after build: '+name)
for name,old in build['binaries'].items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=old:raise RuntimeError('binary drift: '+name)
build['final_harness_sources']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ('scripts/compare-load.py','scripts/compare_load_test.py')}
build['notes']=['source_files records the initial build-time snapshot; final_harness_sources records the final reproduction harness.',
                'All client Go sources and both measured binary bytes were unchanged after the build. Production Weir sources were not modified.']
build['resource_sampler']=dict(source='reproduction/resource-sampler.go',source_sha256=hashlib.sha256((root/'resource-sampler.go').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256((root/'sampler').read_bytes()).hexdigest(),command='GOOS=linux GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -o sampler resource-sampler.go')
(target/'build-manifest.json').write_text(json.dumps(build,indent=2)+'\n')
(target/'resource-summary.json').write_bytes((root/'resource-summary.json').read_bytes())
files={}
for group in ('es-paired-v2','es-cpu1','mongo-bounded'):
 for p in sorted((root/group).iterdir()):
  if p.suffix in ('.json','.jsonl','.log','.yaml','.sh'):
   files[group+'/'+p.name]=p.read_bytes()
 files[group+'/orchestration.log']=(root/(group+'.log')).read_bytes()
 if group=='mongo-bounded':
  files[group+'/analysis-and-cleanup.log']=(root/'mongo-bounded-analysis.log').read_bytes()
  files[group+'/verified-download.sha256']=(root/'mongo-bounded/download.sha256').read_bytes()
preparation=[]
for p in sorted(root.glob('*/summary.json')):
 if p.parent.name in ('es-paired-v2','es-cpu1','mongo-bounded'):continue
 s=json.loads(p.read_text());preparation.append(dict(directory=p.parent.name,excluded_from_measurement=True,owner=s['owner'],runs=len(s.get('runs',[])),cleanup=s.get('cleanup')))
 if not s.get('cleanup') or not s['cleanup'].get('pass',s['cleanup'].get('pass_',False)):raise RuntimeError('preparation cleanup failed: '+str(p))
probe=root/'mongo-paired-final'
for name in ('storage-failure-evidence.tar.gz','storage-failure-evidence.sha256','database-container.log','resource-failure-diagnostics.log','failure-pod-status.json'):
 if (probe/name).exists():files['storage-limit-probe/'+name]=(probe/name).read_bytes()
for name in ('python-tests-final.log','python-tests-final-optimized.log'):
 files['validation/'+name]=(root/name).read_bytes()
files['sampler-check.jsonl']=(root/'sampler-check.jsonl').read_bytes()
files['preparation-cleanups.json']=(json.dumps(preparation,indent=2)+'\n').encode()
for p in (root/'mongo-smoke').glob('*-container.log'):files['preparation/'+p.name]=p.read_bytes()
for p in sorted(Path('internal/testutil/testcapacity').glob('*.go')):files['source/'+str(p)]=p.read_bytes()
for name in ('scripts/compare-load.py','scripts/compare_load_test.py','scripts/config_yaml.py'):
 files['source/'+name]=Path(name).read_bytes()
for name in ('compare-mongo-kube.py','finish-mongo-local-suite.py','prepare-bounded-mongo.py','finish-bounded-mongo.py','analyze-bounded-mongo.py','resource-sampler.go','summarize-resources.py','write-resource-report.py','package-resource-evidence.py'):
 files['reproduction/'+name]=(root/name).read_bytes()
files['source/changes.patch']=subprocess.run(['git','diff','--','internal/testutil/testcapacity','scripts/compare-load.py','scripts/compare_load_test.py'],capture_output=True,check=True).stdout
with tarfile.open(target/'raw-evidence.tar.xz','w:xz') as archive:
 for name,data in files.items():
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
manifest=dict(raw_files={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()},
              deliverables={name:dict(bytes=(target/name).stat().st_size,sha256=hashlib.sha256((target/name).read_bytes()).hexdigest()) for name in ('build-manifest.json','resource-summary.json','raw-evidence.tar.xz')},
              report=dict(path='docs/resource-load-test-2026-10-01.md',sha256=hashlib.sha256(Path('docs/resource-load-test-2026-10-01.md').read_bytes()).hexdigest()))
(target/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('evidence files',len(files),'archive bytes',(target/'raw-evidence.tar.xz').stat().st_size)
