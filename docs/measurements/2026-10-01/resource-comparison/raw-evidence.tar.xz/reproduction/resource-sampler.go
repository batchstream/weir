package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type resourceSample struct {
	Monotonic         float64          `json:"monotonic"`
	WallTime          float64          `json:"wall_time"`
	CPU               map[string]int64 `json:"cpu"`
	MemoryCurrent     int64            `json:"memory_current"`
	MemoryPeak        int64            `json:"memory_peak"`
	MemoryEvents      map[string]int64 `json:"memory_events"`
	ProcessCPUTicks   int64            `json:"process_cpu_ticks"`
	ProcessStartTicks int64            `json:"process_start_ticks"`
	RSSPages          int64            `json:"rss_pages"`
}

func readFile(name string) (string, error) {
	raw, err := os.ReadFile(name)
	return strings.TrimSpace(string(raw)), err
}

func scalar(name string) (int64, error) {
	raw, err := readFile(name)
	if err != nil {
		return 0, err
	}
	return strconv.ParseInt(raw, 10, 64)
}

func counters(name string) (map[string]int64, error) {
	raw, err := readFile(name)
	if err != nil {
		return nil, err
	}
	result := make(map[string]int64)
	for _, line := range strings.Split(raw, "\n") {
		fields := strings.Fields(line)
		if len(fields) != 2 {
			return nil, fmt.Errorf("invalid counters: %s", name)
		}
		n, err := strconv.ParseInt(fields[1], 10, 64)
		if err != nil {
			return nil, err
		}
		result[fields[0]] = n
	}
	return result, nil
}

func collect(pid int, started time.Time) (resourceSample, error) {
	sample := resourceSample{Monotonic: time.Since(started).Seconds(), WallTime: float64(time.Now().UnixNano()) / 1e9}
	var err error
	sample.CPU, err = counters("/sys/fs/cgroup/cpu.stat")
	if err != nil {
		return sample, err
	}
	sample.MemoryCurrent, err = scalar("/sys/fs/cgroup/memory.current")
	if err != nil {
		return sample, err
	}
	sample.MemoryPeak, err = scalar("/sys/fs/cgroup/memory.peak")
	if err != nil {
		return sample, err
	}
	sample.MemoryEvents, err = counters("/sys/fs/cgroup/memory.events")
	if err != nil {
		return sample, err
	}
	raw, err := readFile(fmt.Sprintf("/proc/%d/stat", pid))
	if err != nil {
		return sample, err
	}
	fields := strings.Fields(raw[strings.LastIndex(raw, ")")+2:])
	if len(fields) < 20 {
		return sample, fmt.Errorf("invalid proc stat")
	}
	user, err := strconv.ParseInt(fields[11], 10, 64)
	if err != nil {
		return sample, err
	}
	system, err := strconv.ParseInt(fields[12], 10, 64)
	if err != nil {
		return sample, err
	}
	sample.ProcessCPUTicks = user + system
	sample.ProcessStartTicks, err = strconv.ParseInt(fields[19], 10, 64)
	if err != nil {
		return sample, err
	}
	raw, err = readFile(fmt.Sprintf("/proc/%d/statm", pid))
	if err != nil {
		return sample, err
	}
	fields = strings.Fields(raw)
	if len(fields) < 2 {
		return sample, fmt.Errorf("invalid proc statm")
	}
	sample.RSSPages, err = strconv.ParseInt(fields[1], 10, 64)
	return sample, err
}

func main() {
	pid := flag.Int("pid", 0, "observed process PID")
	output := flag.String("output", "", "task-owned sample file")
	flag.Parse()
	if *pid <= 0 || *output == "" {
		panic("pid and output required")
	}
	file, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	encoder := json.NewEncoder(file)
	started := time.Now()
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	deadline := time.NewTimer(55 * time.Minute)
	defer deadline.Stop()
	for {
		sample, err := collect(*pid, started)
		if err != nil {
			panic(err)
		}
		if err := encoder.Encode(sample); err != nil {
			panic(err)
		}
		select {
		case <-ticker.C:
		case <-deadline.C:
			return
		}
	}
}
