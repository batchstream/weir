import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tarfile
import time

BASE=Path('.testdata/resource-comparison-20261001')
PREP=BASE/'mongo-bounded-prep'
ROOT=BASE/'mongo-bounded'
ROOT.mkdir(exist_ok=True)
OWNER=json.loads((PREP/'namespace.json').read_text())['metadata']['name']
LABEL='weir.load-comparison.owner'
sys.path.insert(0,str(Path('scripts').resolve()))
spec=importlib.util.spec_from_file_location('common',Path('scripts/compare-load.py'))
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
ENV=dict(os.environ);ENV['KUBECTL_REMOTE_COMMAND_WEBSOCKETS']='false'

def save(name,value):
 (ROOT/name).write_text(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')

def control(args,role=None,check=True):
 argv=['kubectl','-n',OWNER]
 if role:argv+=['exec','fixture2','-c',role,'--']
 argv+=args
 for attempt in range(5):
  try:r=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=120)
  except subprocess.TimeoutExpired:
   if not check:return subprocess.CompletedProcess(argv,124,'','control timeout')
   if attempt==4:raise
   continue
  if r.returncode==0:return r
  if not check:return r
  if attempt==4:raise RuntimeError(r.stderr)
  time.sleep(1)

def shell(role,code):return control(['sh','-c',code],role)

ns=json.loads(control(['get','namespace',OWNER,'-o','json']).stdout)
if ns['metadata']['labels'].get(LABEL)!=OWNER:raise RuntimeError('namespace owner mismatch')
save('namespace.json',ns)
for name in ('pod.json','network-policy.json','node.yaml','routes.yaml'): (ROOT/name).write_bytes((PREP/name).read_bytes())
for name in ('client','weir','sampler'):
 got=control(['sha256sum','/bench/'+name],'client').stdout.split()[0]
 if got!=hashlib.sha256((BASE/name).read_bytes()).hexdigest():raise RuntimeError('binary drift')
identity=control(['mongosh','--quiet','--norc','--eval','print(JSON.stringify({version:db.version(),hello:db.hello()}))'],'database').stdout
save('database-identity.json',json.loads(identity))
if json.loads(identity)['version']!='8.0.32' or not json.loads(identity)['hello']['isWritablePrimary']:raise RuntimeError('unexpected MongoDB identity')
shell('weir','if [ -f /bench/final-weir.pid ] && [ "$(cat /proc/$(cat /bench/final-weir.pid)/comm)" = weir ]; then exit 0; fi; /bench/weir serve --config /bench/node.yaml --routes /bench/routes.yaml > /bench/final-weir.log 2>&1 < /dev/null & echo $! > /bench/final-weir.pid')
time.sleep(2)
weir_pid=control(['cat','/bench/final-weir.pid'],'weir').stdout.strip()
if not weir_pid.isdecimal() or control(['cat','/proc/'+weir_pid+'/comm'],'weir').stdout.strip()!='weir':raise RuntimeError('Weir startup')
sampler_pids={}
for role,pid in [('database','1'),('weir',weir_pid)]:
 script='if [ -f /bench/final-'+role+'-sampler.pid ] && [ "$(cat /proc/$(cat /bench/final-'+role+'-sampler.pid)/comm)" = sampler ]; then exit 0; fi; /bench/sampler -pid '+pid+' -output /bench/final-'+role+'-samples.jsonl > /bench/final-'+role+'-sampler.log 2>&1 < /dev/null & echo $! > /bench/final-'+role+'-sampler.pid'
 shell(role,script)
 sampler_pid=control(['cat','/bench/final-'+role+'-sampler.pid'],role).stdout.strip()
 if not sampler_pid.isdecimal() or control(['cat','/proc/'+sampler_pid+'/comm'],role).stdout.strip()!='sampler':raise RuntimeError('sampler startup')
 sampler_pids[role]=sampler_pid
state=json.loads(control(['get','pod/fixture2','-o','json']).stdout)
node_result=subprocess.run(['kubectl','get','node',state['spec']['nodeName'],'-o','json'],capture_output=True,text=True,timeout=60,check=True)
node=json.loads(node_result.stdout)
cases=[]
backend='mongodb://127.0.0.1:27017/?directConnection=true'
prefix=['env','WEIR_CAPACITY_INTEGRATION=1','/bench/client']
pace=prefix+['-mode','pace','-rate','3200','-seconds','10','-write-every','1','-arrival-expiry-ms','100','-max-catchup','512','-client-queue','256']
cases.append(dict(name='pace-3200',kind='pace',command=pace))
number=0
for w in (10,1):
 for mode in ('direct','weir'):
  name='prewarm-'+str(w)+'-'+mode
  command=prefix+['-mode','trial','-backend',backend,'-rate','800','-warm','0','-seconds','20','-prefix',name,'-pool','4','-workers','8','-write-every',str(w),'-arrival-expiry-ms','100','-max-catchup','512','-client-queue','256','-mutation-reservation',str(1000+16000//w)]
  if mode=='weir':command+=['-target','127.0.0.1:7447']
  cases.append(dict(name=name,kind='prewarm',mode=mode,command=command))
 for rate in (800,3200):
  for repetition in range(3):
   for mode in (('direct','weir') if repetition%2==0 else ('weir','direct')):
    name='r%03d'%number;number+=1
    command=prefix+['-mode','trial','-backend',backend,'-rate',str(rate),'-warm','10','-seconds','20','-prefix',name,'-pool','4','-workers','8','-write-every',str(w),'-arrival-expiry-ms','100','-max-catchup','512','-client-queue','256','-mutation-reservation',str(1000+rate*30//w)]
    if mode=='weir':command+=['-target','127.0.0.1:7447']
    cases.append(dict(name=name,kind='trial',mode=mode,rate=rate,repetition=repetition,write_every=w,command=command))
save('cases.json',cases)
script=['#!/bin/sh','set -u','mkdir /bench/final-cases']
for c in cases:
 stem='/bench/final-cases/'+c['name']
 script += ['printf "starting '+c['name']+'\\n"','mkfifo '+stem+'.pipe','cat '+stem+'.pipe > '+stem+'.jsonl & weir_reader_pid=$!',shlex.join(c['command'])+' > '+stem+'.pipe 2> '+stem+'.stderr.log','weir_case_code=$?','wait "$weir_reader_pid"','printf "%s\\n" "$weir_case_code" > '+stem+'.exit','if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi','printf "completed '+c['name']+'\\n"']
save('suite.sh','\n'.join(script)+'\n')
control(['cp',str(ROOT/'suite.sh'),'fixture2:/bench/final-suite.sh','-c','client'])
shell('client','mkdir /bench/final-suite.lock && (sh /bench/final-suite.sh; weir_suite_code=$?; echo "$weir_suite_code" > /bench/final-suite.exit) < /dev/null > /bench/final-suite.log 2>&1 &')
summary=dict(owner=OWNER,runs=[],cleanup=None,provenance=dict(backend='mongodb',base_head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),binary_sha256={name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in ('client','weir','sampler')},node=state['spec']['nodeName'],node_identity=node['status']['nodeInfo'],images=state['status']['containerStatuses'],resources={c['name']:c['resources'] for c in state['spec']['containers']},options=dict(rates=[800,3200],write_every=[10,1],repetitions=3,warm=10,seconds=20,workers=8,pool=4,route_sessions=8,client_queue=256,arrival_expiry_ms=100,deadline_ms=1000),storage='1 GiB memory emptyDir; WiredTiger 256 MiB; oplog 64 MiB; single-primary; majority write concern; journal default',observer='Local one-second Go samplers for each process and its container; suite runs wholly in the pod, no control-network calls in the request path. Idle Weir remains alive during direct trials.'))
save('summary.json',summary)
print('Local suite started in '+OWNER,flush=True)
last=''
while True:
 status=control(['sh','-c','if [ -f /bench/final-suite.exit ]; then cat /bench/final-suite.exit; else tail -n 1 /bench/final-suite.log; fi'],'client',False)
 value=status.stdout.strip()
 if value and value!=last:print(value,flush=True);last=value
 if status.returncode==0 and value.isdecimal():
  if int(value):raise RuntimeError('local suite exit '+value)
  break
 time.sleep(30)
for role,pid in sampler_pids.items():
 shell(role,'test "$(cat /proc/'+pid+'/comm)" = sampler && kill -TERM '+pid)
shell('weir','test "$(cat /proc/'+weir_pid+'/comm)" = weir && kill -TERM '+weir_pid)
shell('client','cp /bench/final-database-samples.jsonl /bench/final-weir-samples.jsonl /bench/final-database-sampler.log /bench/final-weir-sampler.log /bench/final-weir.log /bench/final-suite.log /bench/final-cases/; tar -czf /bench/final-evidence.tar.gz -C /bench/final-cases .')
digest=control(['sha256sum','/bench/final-evidence.tar.gz'],'client').stdout.split()[0]
archive=ROOT/'download.tar.gz'
for attempt in range(5):
 control(['cp','fixture2:/bench/final-evidence.tar.gz',str(archive),'-c','client'])
 if hashlib.sha256(archive.read_bytes()).hexdigest()==digest:break
else:raise RuntimeError('archive checksum failed')
with tarfile.open(archive,'r:gz') as data:
 regular_files=[m for m in data.getmembers() if m.isfile()]
 data.extractall(ROOT,members=regular_files,filter='data')
samples={role:[json.loads(l) for l in (ROOT/('final-'+role+'-samples.jsonl')).read_text().splitlines()] for role in ('database','weir')}
for c in cases:
 records=[json.loads(l) for l in (ROOT/(c['name']+'.jsonl')).read_text().splitlines()]
 if c['kind']=='pace':
  pacing=records[0];m=pacing['trial']['measure']['all']
  if m['planned']!=m['success'] or m['client_drop'] or m['lag']['p99_us']>5000:raise RuntimeError('pacing qualification')
  summary['pacing']=pacing
  continue
 receipt=next(r for r in records if r.get('type')=='trial')
 audit=next(r for r in records if r.get('type')=='audit')
 if receipt['run_error']!='<nil>' or audit['error']!='<nil>':raise RuntimeError('trial/audit failure: '+c['name'])
 if c['kind']=='prewarm':continue
 t=receipt['trial'];begin=datetime.datetime.fromisoformat(t['start'].replace('Z','+00:00')).timestamp()+10
 options=dict(cpu=.25,ticks=100,page_size=4096)
 measured={role:[s for s in ss if begin<=s['wall_time']<=begin+20] for role,ss in samples.items()}
 for role in ('database','weir') if c['mode']=='weir' else ('database',):
  ss=measured[role]
  if len(ss)<15 or ss[-1]['wall_time']-ss[0]['wall_time']<15:raise RuntimeError('resource coverage: '+c['name'])
  if ss[0]['process_start_ticks']!=ss[-1]['process_start_ticks']:raise RuntimeError('PID changed')
 out=dict(prefix=c['name'],mode=c['mode'],rate=c['rate'],repetition=c['repetition'],write_every=c['write_every'],seconds=20,measure=t['measure'],windows=t['ten_second_windows'],audit=audit['audit'],database=common.resource_summary(measured['database'],options),observer_errors=[])
 if c['mode']=='weir':
  options=dict(cpu=.5,ticks=100,page_size=4096);out['weir']=common.resource_summary(measured['weir'],options)
 summary['runs'].append(out)
 (ROOT/(c['name']+'-client.jsonl')).write_bytes((ROOT/(c['name']+'.jsonl')).read_bytes())
 save('summary.json',summary)
 print(json.dumps(dict(prefix=c['name'],mode=c['mode'],rate=c['rate'],write_every=c['write_every'],success_rps=out['measure']['all']['success']/20,database=out['database'],weir=out.get('weir'))),flush=True)
ns=json.loads(control(['get','namespace',OWNER,'-o','json']).stdout)
if ns['metadata']['labels'].get(LABEL)!=OWNER:raise RuntimeError('cleanup owner mismatch')
control(['delete','namespace',OWNER,'--wait=true','--timeout=90s'])
absent=control(['get','namespace',OWNER],check=False)
if absent.returncode==0 or 'NotFound' not in absent.stderr:raise RuntimeError('namespace deletion unverified')
summary['cleanup']=dict(pass_=True,namespace_absent=True,stdout=absent.stderr)
save('summary.json',summary)
prep_summary=json.loads((PREP/'summary.json').read_text());prep_summary['cleanup']=summary['cleanup'];prep_summary['cleanup_by']='mongo-paired-final local suite';(PREP/'summary.json').write_text(json.dumps(prep_summary,indent=2)+'\n')
for receipt in BASE.glob('*/summary.json'):
 old=json.loads(receipt.read_text())
 if old.get('owner')==OWNER and old.get('cleanup') is None:
  old['cleanup']=summary['cleanup'];old['cleanup_by']='mongo-bounded';receipt.write_text(json.dumps(old,indent=2)+'\n')
print('Verified suite evidence and namespace cleanup',flush=True)
