import argparse
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid

REPO = Path.cwd()
sys.path.insert(0, str(REPO / 'scripts'))
import config_yaml
spec = importlib.util.spec_from_file_location('compare_load', REPO / 'scripts/compare-load.py')
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
ROOT = REPO / '.testdata/resource-comparison-20261001/mongo-paired-v10'
ROOT.mkdir(exist_ok=False)
OWNER = 'weir-load-' + uuid.uuid4().hex[:12]
LABEL = 'weir.load-comparison.owner'


def run(argv, timeout=120, check=True):
    import os
    env = dict(os.environ)
    env['KUBECTL_REMOTE_COMMAND_WEBSOCKETS'] = 'false'
    transient = ('connection reset by peer', 'unexpected EOF', 'TLS handshake timeout', 'i/o timeout')
    for attempt in range(5):
        try:
            result = subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=False,env=env)
        except subprocess.TimeoutExpired:
            if not check:
                return subprocess.CompletedProcess(argv,124,'','control connection timeout')
            if attempt==4:raise
            time.sleep(1)
            continue
        if result.returncode == 0 or not any(t in result.stderr for t in transient):
            break
        time.sleep(1)
    if check and result.returncode:
        save('failed-command-stdout.log', result.stdout)
        save('failed-command-stderr.log', result.stderr)
        raise RuntimeError(result.stderr)
    return result


def save(name, value):
    raw = value if isinstance(value, str) else json.dumps(value, indent=2)
    (ROOT / name).write_text(raw)


def kube(args, container=None, **options):
    command = ['kubectl', '-n', OWNER]
    if container:
        command += ['exec', 'fixture', '-c', container, '--']
    return run(command + args, **options)


def read_evidence(path):
    import base64
    import gzip
    metadata = kube(['sh', '-c', 'sha256sum ' + path + '; gzip -c ' + path + ' > ' + path + '.gz'], container='client').stdout
    digest = metadata.split()[0]
    for attempt in range(5):
        try:
            encoded = kube(['base64', path + '.gz'], container='client', timeout=30).stdout
            data = gzip.decompress(base64.b64decode(''.join(encoded.split()), validate=True))
            if hashlib.sha256(data).hexdigest() != digest:
                raise ValueError('evidence checksum mismatch')
            return data.decode()
        except (ValueError, EOFError, OSError) as exc:
            if attempt == 4:
                raise RuntimeError('evidence transfer failed: ' + path) from exc
            time.sleep(1)


job_number = 0

def client_job(command, timeout=180):
    global job_number
    import shlex
    job_number += 1
    stem = '/bench/job-' + str(job_number)
    script = ('mkdir ' + stem + '.lock && (mkfifo ' + stem + '.pipe; cat ' + stem + '.pipe > ' + stem + '.stdout & weir_reader=$!; ' + shlex.join(command) + ' > ' + stem + '.pipe 2> ' + stem + '.stderr; weir_code=$?; wait "$weir_reader"; echo "$weir_code" > ' + stem + '.exit) < /dev/null > /dev/null 2>&1 &')
    kube(['sh','-c',script],container='client',timeout=20)
    until = time.monotonic()+timeout
    while time.monotonic()<until:
        status = kube(['sh','-c','if [ -f '+stem+'.exit ]; then cat '+stem+'.exit; fi'],container='client',timeout=30,check=False)
        if status.returncode == 0 and status.stdout.strip():
            stdout = read_evidence(stem+'.stdout')
            stderr = read_evidence(stem+'.stderr')
            result = subprocess.CompletedProcess(command,int(status.stdout.strip()),stdout,stderr)
            if result.returncode:
                save('failed-client-stdout.log',stdout)
                save('failed-client-stderr.log',stderr)
                raise RuntimeError(stderr)
            return result
        time.sleep(2)
    raise TimeoutError('detached client job '+stem)



summary = dict(owner=OWNER, runs=[], cleanup=None)
sampler_pids = {}
created = False
completed = False
try:
    namespace = dict(apiVersion='v1', kind='Namespace', metadata=dict(name=OWNER, labels={LABEL:OWNER}))
    save('namespace.json', namespace)
    run(['kubectl', 'create', '-f', str(ROOT/'namespace.json')])
    created = True
    image = 'mongo@sha256:4968f22d0c6c10ef29952f3e807f62872ba22b3312f25803564fbfc08255efc2'
    policy = dict(apiVersion='networking.k8s.io/v1',kind='NetworkPolicy',
                  metadata=dict(name='isolated',namespace=OWNER),
                  spec=dict(podSelector={},policyTypes=['Ingress','Egress'],ingress=[],egress=[]))
    save('network-policy.json',policy)
    kube(['create','-f',str(ROOT/'network-policy.json')])
    db = dict(name='database',image=image,command=['mongod','--bind_ip','127.0.0.1','--replSet','weir_load_test','--wiredTigerCacheSizeGB','0.25'],
              resources=dict(requests=dict(cpu='250m',memory='1536Mi'),limits=dict(cpu='250m',memory='1536Mi')),
              volumeMounts=[dict(name='data',mountPath='/data/db'),dict(name='binaries',mountPath='/bench')])
    containers = [db]
    for name, cpu, memory in [('client','2','2048Mi'),('weir','500m','768Mi')]:
        container = dict(name=name,image='busybox:1.37.0',command=['sh','-c','exec sleep 3600'],
                         securityContext=dict(runAsUser=65532,runAsGroup=65532,allowPrivilegeEscalation=False),
                         resources=dict(requests=dict(cpu=cpu,memory=memory),limits=dict(cpu=cpu,memory=memory)),
                         volumeMounts=[dict(name='binaries',mountPath='/bench')])
        containers.append(container)
    pod = dict(apiVersion='v1',kind='Pod',metadata=dict(name='fixture',namespace=OWNER,labels={LABEL:OWNER}),
               spec=dict(restartPolicy='Never',automountServiceAccountToken=False,securityContext=dict(fsGroup=65532),
                         containers=containers,
                         volumes=[dict(name='data',emptyDir=dict(medium='Memory',sizeLimit='1Gi')),
                                  dict(name='binaries',emptyDir=dict(sizeLimit='128Mi'))]))
    save('pod.json',pod)
    kube(['create','-f',str(ROOT/'pod.json')])
    kube(['wait','--for=condition=Ready','pod/fixture','--timeout=180s'],timeout=190)
    init = 'rs.initiate({_id:"weir_load_test",members:[{_id:0,host:"127.0.0.1:27017"}]}); for(let i=0;i<120;i++){if(db.hello().isWritablePrimary)break;sleep(500)}; if(!db.hello().isWritablePrimary)throw new Error("primary timeout")'
    kube(['mongosh','--quiet','--norc','--eval',init],container='database',timeout=90)
    for name in ('client','weir','sampler'):
        binary = REPO/'.testdata/resource-comparison-20261001'/name
        kube(['cp',str(binary)+'.gz','fixture:/bench/'+name+'.gz','-c','client'],timeout=120)
        kube(['gzip','-df','/bench/'+name+'.gz'],container='client')
        kube(['chmod','555','/bench/'+name],container='client')
        digest = kube(['sha256sum','/bench/'+name],container='client').stdout.split()[0]
        if digest != hashlib.sha256(binary.read_bytes()).hexdigest():
            raise RuntimeError('uploaded binary checksum mismatch')
    config = dict(listeners=dict(application='127.0.0.1:7447'),diagnostics=dict(address='127.0.0.1:7449'),
                  memory='768MiB',transport=dict(max_connections=16,max_sessions=8))
    backend = 'mongodb://127.0.0.1:27017/?directConnection=true'
    local = dict(max_concurrency=4,max_batch_operations=16,mongodb=dict(uri=backend))
    routes = dict(services=[dict(name='database',local=local)],routes=[dict(store='records',service='database')])
    for name,value in [('node',config),('routes',routes)]:
        save(name+'.yaml',config_yaml.dumps(value))
        kube(['cp',str(ROOT/(name+'.yaml')),'fixture:/bench/'+name+'.yaml','-c','client'])
    prefix = ['env','WEIR_CAPACITY_INTEGRATION=1','/bench/client']
    client_job(prefix+['-mode','setup','-backend',backend,'-pool','4','-mutation-reservation','1000'])
    launch = kube(['sh','-c','/bench/weir serve --config /bench/node.yaml --routes /bench/routes.yaml > /bench/weir.log 2>&1 < /dev/null & echo $!'],container='weir')
    weir_pid = launch.stdout.strip()
    if not weir_pid.isdecimal():
        raise RuntimeError('Weir PID missing')
    kube(['sleep','2'],container='weir')
    comm = kube(['cat','/proc/'+weir_pid+'/comm'],container='weir',check=False)
    if comm.stdout.strip() != 'weir':
        raise RuntimeError('Weir startup: '+kube(['cat','/bench/weir.log'],container='weir').stdout)
    for role,pid in [('database','1'),('weir',weir_pid)]:
        script='/bench/sampler -pid '+pid+' -output /bench/'+role+'-resources.jsonl > /bench/'+role+'-sampler.log 2>&1 < /dev/null & echo $!'
        sampler_pid=kube(['sh','-c',script],container=role).stdout.strip()
        if not sampler_pid.isdecimal():raise RuntimeError('sampler PID missing')
        sampler_pids[role]=sampler_pid
        if kube(['cat','/proc/'+sampler_pid+'/comm'],container=role).stdout.strip()!='sampler':raise RuntimeError('sampler startup failed')
    state = json.loads(kube(['get','pod/fixture','-o','json']).stdout)
    node = json.loads(run(['kubectl','get','node',state['spec']['nodeName'],'-o','json']).stdout)
    identity = kube(['mongosh','--quiet','--norc','--eval','print(JSON.stringify({version:db.version(),hello:db.hello()}))'],container='database').stdout
    save('database-identity.json',json.loads(identity))
    summary['provenance'] = dict(base_head=run(['git','rev-parse','HEAD']).stdout.strip(),
        dirty_files=run(['git','status','--short']).stdout.splitlines(),
        binary_sha256={name:hashlib.sha256((REPO/'.testdata/resource-comparison-20261001'/name).read_bytes()).hexdigest() for name in ('client','weir','sampler')},
        backend='mongodb',node=state['spec']['nodeName'],node_identity=node['status']['nodeInfo'],
        images=state['status']['containerStatuses'],resources={c['name']:c['resources'] for c in containers},
        options=dict(rates=[800,3200],write_every=[10,1],repetitions=3,warm=10,seconds=20,workers=8,pool=4,
                     client_queue=256,arrival_expiry_ms=100,deadline_ms=1000,route_sessions=8),
        storage='1 GiB memory emptyDir, single-primary replica set, majority write concern, journal default',
        observer='local one-second Go sampler: process CPU ticks/RSS and container cpu.stat/memory.current; snapshot transfers checked by SHA-256; container counters include sampler overhead')
    save('summary.json',summary)
    for rate in (3200,):
        result=client_job(prefix+['-mode','pace','-rate',str(rate),'-seconds','10','-write-every','1',
                           '-arrival-expiry-ms','100','-max-catchup','512','-client-queue','256'])
        save('pace-'+str(rate)+'.jsonl',result.stdout)
        probe=json.loads(result.stdout)
        m=probe['trial']['measure']['all']
        if m['planned']!=m['success'] or m['client_drop'] or m['lag']['p99_us']>5000:
            raise RuntimeError('pacing qualification failed')
        summary['pacing']=probe
    for write_every in (10,1):
        for mode in ('direct','weir'):
            cmd=prefix+['-mode','trial','-backend',backend,'-rate','800','-seconds','20','-warm','0','-prefix','prewarm-'+str(write_every)+'-'+mode,
                        '-pool','4','-workers','8','-write-every',str(write_every),'-arrival-expiry-ms','100','-max-catchup','512','-client-queue','256',
                        '-mutation-reservation',str(1000+16000//write_every)]
            if mode=='weir':cmd+=['-target','127.0.0.1:7447']
            result=client_job(cmd)
            save('prewarm-'+str(write_every)+'-'+mode+'.jsonl',result.stdout)
            records=[json.loads(line) for line in result.stdout.splitlines()]
            if any(r.get('type')=='audit' and r['error']!='<nil>' for r in records):raise RuntimeError('prewarm audit')
        for rate in (800,3200):
            for repetition in range(3):
                for mode in (('direct','weir') if repetition%2==0 else ('weir','direct')):
                    name='r%03d'%len(summary['runs'])
                    cmd=prefix+['-mode','trial','-backend',backend,'-rate',str(rate),'-warm','10','-seconds','20','-prefix',name,
                                '-pool','4','-workers','8','-write-every',str(write_every),'-arrival-expiry-ms','100','-max-catchup','512',
                                '-client-queue','256','-mutation-reservation',str(1000+rate*30//write_every)]
                    if mode=='weir':cmd+=['-target','127.0.0.1:7447']
                    result=client_job(cmd)
                    save(name+'-client.jsonl',result.stdout)
                    save(name+'-stderr.log',result.stderr)
                    records=[json.loads(line) for line in result.stdout.splitlines()]
                    receipt=next(r for r in records if r.get('type')=='trial')
                    t=receipt['trial']
                    audit=next(r for r in records if r.get('type')=='audit')
                    if receipt['run_error']!='<nil>' or audit['error']!='<nil>':raise RuntimeError('trial/audit failure')
                    begin=datetime.datetime.fromisoformat(t['start'].replace('Z','+00:00')).timestamp()+10
                    measured_roles={}
                    for role in ('database','weir') if mode=='weir' else ('database',):
                        snapshot='/bench/'+name+'-'+role+'-samples.jsonl'
                        kube(['cp','/bench/'+role+'-resources.jsonl',snapshot],container='client')
                        raw=read_evidence(snapshot)
                        save(name+'-'+role+'-samples.jsonl',raw)
                        samples=[json.loads(line) for line in raw.splitlines()]
                        measured=[s for s in samples if begin<=s['wall_time']<=begin+20]
                        if len(measured)<15 or measured[-1]['wall_time']-measured[0]['wall_time']<15:raise RuntimeError('resource sample coverage insufficient: '+role)
                        if measured[0]['process_start_ticks']!=measured[-1]['process_start_ticks']:raise RuntimeError('observed process changed')
                        measured_roles[role]=measured
                    database_options=dict(cpu=.25,ticks=100,page_size=4096)
                    weir_options=dict(cpu=.5,ticks=100,page_size=4096)
                    out=dict(prefix=name,mode=mode,rate=rate,repetition=repetition,write_every=write_every,seconds=20,
                             measure=t['measure'],windows=t['ten_second_windows'],audit=audit['audit'],
                             database=common.resource_summary(measured_roles['database'],database_options),observer_errors=[])
                    if mode=='weir':out['weir']=common.resource_summary(measured_roles['weir'],weir_options)
                    summary['runs'].append(out)
                    save('summary.json',summary)
                    m=out['measure']['all']
                    print(json.dumps(dict(prefix=name,mode=mode,rate=rate,write_every=write_every,success_rps=m['success']/20,
                                          drops=m['client_drop'],failures=m['failures'],p95_us=m['success_arrival']['p95_us'],
                                          database=out['database'],weir=out.get('weir'))),flush=True)
    completed = True
finally:
    if not completed:
        save('summary.json',summary)
        print('Owned fixture retained for recovery: '+OWNER,flush=True)
    for role,pid in sampler_pids.items() if completed else []:
        kube(['sh','-c','test "$(cat /proc/'+pid+'/comm)" = sampler && kill -TERM '+pid],container=role,check=False)
        save(role+'-sampler.log',kube(['cat','/bench/'+role+'-sampler.log'],container=role,check=False).stdout)
    if completed and 'weir_pid' in globals() and weir_pid.isdecimal():
        kube(['sh','-c','test "$(cat /proc/'+weir_pid+'/comm)" = weir && kill -TERM '+weir_pid],container='weir',check=False)
        save('weir.log',kube(['cat','/bench/weir.log'],container='weir',check=False).stdout)
    if created and completed:
        for role in ('database','client','weir'):
            save(role+'-container.log',kube(['logs','fixture','-c',role],check=False).stdout)
        found=json.loads(run(['kubectl','get','namespace',OWNER,'-o','json']).stdout)
        if found['metadata']['labels'].get(LABEL)!=OWNER:raise RuntimeError('namespace ownership mismatch')
        result=run(['kubectl','delete','namespace',OWNER,'--wait=true','--timeout=90s'],timeout=100,check=False)
        summary['cleanup']=dict(pass_=result.returncode==0,stdout=result.stdout,stderr=result.stderr,
                                namespace_absent=run(['kubectl','get','namespace',OWNER],check=False).returncode!=0)
    save('summary.json',summary)
