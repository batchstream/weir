import hashlib,json,os,subprocess,time
from pathlib import Path
BASE=Path('.testdata/resource-comparison-20261001');OLD=BASE/'mongo-paired-final';ROOT=BASE/'mongo-bounded-prep';ROOT.mkdir(exist_ok=True)
OWNER=json.loads((OLD/'namespace.json').read_text())['metadata']['name'];LABEL='weir.load-comparison.owner'
ENV=dict(os.environ);ENV['KUBECTL_REMOTE_COMMAND_WEBSOCKETS']='false'
def call(args,role=None):
 argv=['kubectl','-n',OWNER]
 if role:argv+=['exec','fixture','-c',role,'--']
 for attempt in range(5):
  try:r=subprocess.run(argv+args,capture_output=True,text=True,env=ENV,timeout=120)
  except subprocess.TimeoutExpired:
   if attempt==4:raise
   continue
  if r.returncode==0:return r.stdout
  if attempt==4:raise RuntimeError(r.stderr)
  time.sleep(1)
def save(name,x):(ROOT/name).write_text(json.dumps(x,indent=2)+'\n')
ns=json.loads(call(['get','namespace',OWNER,'-o','json']))
if ns['metadata']['labels'].get(LABEL)!=OWNER:raise RuntimeError('owner mismatch')
for f in ['final-weir.pid','final-weir-sampler.pid']:
 comm='weir' if f=='final-weir.pid' else 'sampler'
 call(['sh','-c','weir_stop_pid=$(cat /bench/'+f+'); test "$(cat /proc/$weir_stop_pid/comm)" = '+comm+' && kill -TERM "$weir_stop_pid"'],'weir')
call(['sh','-c','tar -czf /bench/storage-failure-evidence.tar.gz -C /bench final-cases final-database-samples.jsonl final-weir-samples.jsonl final-weir.log final-database-sampler.log final-weir-sampler.log final-suite.log'],'client')
digest=call(['sha256sum','/bench/storage-failure-evidence.tar.gz'],'client').split()[0]
for attempt in range(5):
 call(['cp','fixture:/bench/storage-failure-evidence.tar.gz',str(OLD/'storage-failure-evidence.tar.gz'),'-c','client'])
 if hashlib.sha256((OLD/'storage-failure-evidence.tar.gz').read_bytes()).hexdigest()==digest:break
else:raise RuntimeError('failure evidence checksum')
(OLD/'storage-failure-evidence.sha256').write_text(digest+'\n')
call(['sh','-c','mkdir /bench/assets; for n in client weir sampler; do gzip -c /bench/$n > /bench/assets/$n.gz; done; busybox httpd -f -p 8080 -h /bench/assets > /bench/assets-http.log 2>&1 < /dev/null & echo $! > /bench/assets-http.pid'],'client')
old=json.loads(call(['get','pod/fixture','-o','json']));old_ip=old['status']['podIP']
policy=dict(apiVersion='networking.k8s.io/v1',kind='NetworkPolicy',metadata=dict(name='owned-binary-copy',namespace=OWNER),spec=dict(podSelector=dict(matchLabels={LABEL:OWNER}),policyTypes=['Ingress','Egress'],ingress=[dict(_from=[dict(podSelector=dict(matchLabels={LABEL:OWNER}))],ports=[dict(protocol='TCP',port=8080)])],egress=[dict(to=[dict(podSelector=dict(matchLabels={LABEL:OWNER}))],ports=[dict(protocol='TCP',port=8080)])]))
policy['spec']['ingress'][0]['from']=policy['spec']['ingress'][0].pop('_from')
save('binary-copy-policy.json',policy);call(['create','-f',str(ROOT/'binary-copy-policy.json')])
pod=json.loads((BASE/'mongo-paired-v10/pod.json').read_text());pod['metadata']['name']='fixture2';pod['spec']['nodeSelector']={'kubernetes.io/arch':'arm64'}
db=pod['spec']['containers'][0];db['command']+=['--oplogSize','64']
init_script='set -e; for n in client weir sampler; do wget -q -O /bench/$n.gz http://'+old_ip+':8080/$n.gz; gzip -df /bench/$n.gz; chmod 555 /bench/$n; done'
init=dict(name='binaries',image='busybox:1.37.0',command=['sh','-c',init_script],securityContext=dict(runAsUser=65532,runAsGroup=65532,allowPrivilegeEscalation=False),resources=dict(requests=dict(cpu='1',memory='128Mi'),limits=dict(cpu='1',memory='128Mi')),volumeMounts=[dict(name='binaries',mountPath='/bench')])
pod['spec']['initContainers']=[init]
save('namespace.json',ns);save('pod.json',pod);save('summary.json',dict(owner=OWNER,runs=[],cleanup=None))
(ROOT/'network-policy.json').write_bytes((BASE/'mongo-paired-v10/network-policy.json').read_bytes())
for name in ['node.yaml','routes.yaml']:(ROOT/name).write_bytes((BASE/'mongo-paired-v10'/name).read_bytes())
call(['create','-f',str(ROOT/'pod.json')]);call(['wait','--for=condition=Ready','pod/fixture2','--timeout=180s'])
argv=['kubectl','-n',OWNER,'exec','fixture2','-c','database','--','mongosh','--quiet','--norc','--eval','rs.initiate({_id:"weir_load_test",members:[{_id:0,host:"127.0.0.1:27017"}]}); for(let i=0;i<120;i++){if(db.hello().isWritablePrimary)break;sleep(500)}; if(!db.hello().isWritablePrimary)throw new Error("primary timeout")']
r=subprocess.run(argv,capture_output=True,text=True,env=ENV,timeout=120,check=True)
for name in ['node.yaml','routes.yaml']:
 subprocess.run(['kubectl','-n',OWNER,'cp',str(ROOT/name),'fixture2:/bench/'+name,'-c','client'],capture_output=True,text=True,env=ENV,timeout=120,check=True)
print('Bounded fixture ready; binary transfer stayed inside the owned namespace',flush=True)
