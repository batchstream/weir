import datetime
import hashlib
import json
from pathlib import Path
import statistics

ROOT=Path('.testdata/resource-comparison-20261001')
GROUPS={'es-cpu0.5':ROOT/'es-paired-v2','es-cpu1':ROOT/'es-cpu1','mongo-cpu0.5':ROOT/'mongo-bounded'}


def stats(values):
    return dict(median=statistics.median(values),minimum=min(values),maximum=max(values))


def client_cpu(records,t):
    samples=[r['sample'] for r in records if r.get('type') in ('client_start','client_sample','client_end')]
    begin=datetime.datetime.fromisoformat(t['start'].replace('Z','+00:00')).timestamp()+t['options']['WarmSeconds']
    end=begin+t['options']['Seconds']
    measured=[s for s in samples if begin<=datetime.datetime.fromisoformat(s['time'].replace('Z','+00:00')).timestamp()<=end]
    if len(measured)<2:raise ValueError('client resource coverage')
    def counters(s):return dict((k,int(v)) for k,v in (line.split() for line in s['files']['cpu.stat'].splitlines()))
    left,right=counters(measured[0]),counters(measured[-1])
    seconds=(measured[-1]['monotonic_ns']-measured[0]['monotonic_ns'])/1e9
    result=dict(cpu_cores_mean=(right['usage_usec']-left['usage_usec'])/1e6/seconds,
                throttled_seconds=(right['throttled_usec']-left['throttled_usec'])/1e6,
                rss_max=max(s['rss_bytes'] for s in measured),sample_seconds=seconds,
                sample_errors=[s.get('errors') for s in measured if s.get('errors')])
    return result


result=dict(groups={},cells=[],paired_directions=[])
for group,path in GROUPS.items():
    x=json.loads((path/'summary.json').read_text())
    if x['cleanup'] is None:raise ValueError('group not cleaned: '+group)
    cleaned=x['cleanup']
    if not cleaned.get('pass',cleaned.get('pass_',False)):raise ValueError('cleanup failed: '+group)
    if group.startswith('mongo') and not cleaned['namespace_absent']:raise ValueError('namespace remains')
    if group.startswith('es') and not cleaned['non_default_inventory_restored']:raise ValueError('Docker inventory changed')
    result['groups'][group]=x
    backend='mongodb' if group.startswith('mongo') else 'elasticsearch'
    for r in x['runs']:
        records=[json.loads(line) for line in (path/(r['prefix']+'-client.jsonl')).read_text().splitlines()]
        receipt=next(z for z in records if z.get('type')=='trial')
        if receipt['run_error']!='<nil>':raise ValueError('load receipt error')
        if any(z.get('type')=='audit' and z['error']!='<nil>' for z in records):raise ValueError('audit receipt error')
        r['client_independent']=client_cpu(records,receipt['trial'])
        if r['client_independent']['sample_errors']:raise ValueError('client observation errors')
    keys=sorted(set((r['write_every'],r['rate']) for r in x['runs']))
    for w,rate in keys:
        for mode in ('direct','weir'):
            runs=[r for r in x['runs'] if (r['write_every'],r['rate'],r['mode'])==(w,rate,mode)]
            if len(runs)!=3:raise ValueError('incomplete paired repetitions')
            cpu=0.5 if group.endswith('0.5') else 1
            cell=dict(group=group,backend=backend,weir_cpu_limit=cpu,workload='90% Read / 10% Put' if w==10 else '100% Put',
                      write_every=w,offered_rps=rate,mode=mode,repetitions=3,prefixes=[r['prefix'] for r in runs])
            functions=dict(success_rps=lambda r:r['measure']['all']['success']/r['seconds'],
                p95_ms=lambda r:r['measure']['all']['success_arrival']['p95_us']/1000,
                p99_ms=lambda r:r['measure']['all']['success_arrival']['p99_us']/1000,
                db_cpu_cores=lambda r:r['database']['cpu_cores_mean'],
                db_cpu_quota_percent=lambda r:r['database']['cpu_quota_percent'],
                db_rss_mib=lambda r:r['database']['rss_max']/1024**2,
                db_cgroup_memory_mib=lambda r:r['database']['cgroup_memory_max']/1024**2,
                db_throttled_seconds=lambda r:r['database']['throttled_seconds'],
                client_cpu_cores=lambda r:r['client_independent']['cpu_cores_mean'],
                client_rss_mib=lambda r:r['client_independent']['rss_max']/1024**2,
                server_cpu_cores=lambda r:r['database']['cpu_cores_mean']+r.get('weir',{}).get('cpu_cores_mean',0))
            if mode=='weir':
                functions.update(weir_cpu_cores=lambda r:r['weir']['cpu_cores_mean'],
                                 weir_rss_mib=lambda r:r['weir']['rss_max']/1024**2,
                                 weir_cgroup_memory_mib=lambda r:r['weir']['cgroup_memory_max']/1024**2)
            for key,f in functions.items():cell[key]=stats([f(r) for r in runs])
            counts={key:sum(r['measure']['all'][key] for r in runs) for key in ('planned','started','success','client_drop','unknown')}
            counts['api_failures']=sum(sum((r['measure']['all']['failures'] or {}).values()) for r in runs)
            counts['offered_loss']=counts['planned']-counts['success']
            counts['offered_loss_percent']=counts['offered_loss']/counts['planned']*100
            cell['totals']=counts
            cell['oom_kills']=sum(r['database']['oom_kills']+r.get('weir',{}).get('oom_kills',0) for r in runs)
            cell['audit_applied']=sum(r['audit']['applied'] for r in runs)
            cell['audit_found']=sum(r['audit'].get('found_documents',r['audit']['found_version1']) for r in runs)
            cell['audit_unknown_found']=sum(r['audit']['unknown_found'] for r in runs)
            cell['observer_errors']=[e for r in runs for e in r.get('observer_errors',[])]
            result['cells'].append(cell)
        for repetition in range(3):
            direct=next(r for r in x['runs'] if (r['write_every'],r['rate'],r['mode'],r['repetition'])==(w,rate,'direct',repetition))
            through=next(r for r in x['runs'] if (r['write_every'],r['rate'],r['mode'],r['repetition'])==(w,rate,'weir',repetition))
            a=direct['measure']['all']['success']/direct['seconds'];b=through['measure']['all']['success']/through['seconds']
            result['paired_directions'].append(dict(group=group,write_every=w,offered_rps=rate,repetition=repetition,
                order='direct,weir' if repetition%2==0 else 'weir,direct',direct_rps=a,weir_rps=b,change_percent=(b/a-1)*100))

def compact(value):
    if isinstance(value,dict):return {k:compact(v) for k,v in value.items() if k!='buckets'}
    if isinstance(value,list):return [compact(v) for v in value]
    return value

(ROOT/'resource-summary.json').write_text(json.dumps(compact(result),indent=2)+'\n')
for c in result['cells']:
    print(c['group'],c['write_every'],c['offered_rps'],c['mode'],'rps',round(c['success_rps']['median'],2),
          'p95',c['p95_ms']['median'],'dbCPU',round(c['db_cpu_cores']['median'],3),'dbRSS',round(c['db_rss_mib']['median'],1),
          'weirCPU',round(c.get('weir_cpu_cores',{}).get('median',0),3),'weirRSS',round(c.get('weir_rss_mib',{}).get('median',0),1),
          'loss',round(c['totals']['offered_loss_percent'],3),'clientCPU',round(c['client_cpu_cores']['median'],3))
