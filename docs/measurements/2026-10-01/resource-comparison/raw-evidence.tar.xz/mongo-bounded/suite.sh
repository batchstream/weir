#!/bin/sh
set -u
mkdir /bench/final-cases
printf "starting pace-3200\n"
mkfifo /bench/final-cases/pace-3200.pipe
cat /bench/final-cases/pace-3200.pipe > /bench/final-cases/pace-3200.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode pace -rate 3200 -seconds 10 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 > /bench/final-cases/pace-3200.pipe 2> /bench/final-cases/pace-3200.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/pace-3200.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed pace-3200\n"
printf "starting prewarm-10-direct\n"
mkfifo /bench/final-cases/prewarm-10-direct.pipe
cat /bench/final-cases/prewarm-10-direct.pipe > /bench/final-cases/prewarm-10-direct.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 0 -seconds 20 -prefix prewarm-10-direct -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 2600 > /bench/final-cases/prewarm-10-direct.pipe 2> /bench/final-cases/prewarm-10-direct.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/prewarm-10-direct.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed prewarm-10-direct\n"
printf "starting prewarm-10-weir\n"
mkfifo /bench/final-cases/prewarm-10-weir.pipe
cat /bench/final-cases/prewarm-10-weir.pipe > /bench/final-cases/prewarm-10-weir.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 0 -seconds 20 -prefix prewarm-10-weir -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 2600 -target 127.0.0.1:7447 > /bench/final-cases/prewarm-10-weir.pipe 2> /bench/final-cases/prewarm-10-weir.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/prewarm-10-weir.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed prewarm-10-weir\n"
printf "starting r000\n"
mkfifo /bench/final-cases/r000.pipe
cat /bench/final-cases/r000.pipe > /bench/final-cases/r000.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r000 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final-cases/r000.pipe 2> /bench/final-cases/r000.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r000.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r000\n"
printf "starting r001\n"
mkfifo /bench/final-cases/r001.pipe
cat /bench/final-cases/r001.pipe > /bench/final-cases/r001.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r001 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final-cases/r001.pipe 2> /bench/final-cases/r001.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r001.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r001\n"
printf "starting r002\n"
mkfifo /bench/final-cases/r002.pipe
cat /bench/final-cases/r002.pipe > /bench/final-cases/r002.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r002 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final-cases/r002.pipe 2> /bench/final-cases/r002.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r002.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r002\n"
printf "starting r003\n"
mkfifo /bench/final-cases/r003.pipe
cat /bench/final-cases/r003.pipe > /bench/final-cases/r003.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r003 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final-cases/r003.pipe 2> /bench/final-cases/r003.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r003.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r003\n"
printf "starting r004\n"
mkfifo /bench/final-cases/r004.pipe
cat /bench/final-cases/r004.pipe > /bench/final-cases/r004.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r004 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final-cases/r004.pipe 2> /bench/final-cases/r004.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r004.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r004\n"
printf "starting r005\n"
mkfifo /bench/final-cases/r005.pipe
cat /bench/final-cases/r005.pipe > /bench/final-cases/r005.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r005 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final-cases/r005.pipe 2> /bench/final-cases/r005.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r005.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r005\n"
printf "starting r006\n"
mkfifo /bench/final-cases/r006.pipe
cat /bench/final-cases/r006.pipe > /bench/final-cases/r006.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r006 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final-cases/r006.pipe 2> /bench/final-cases/r006.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r006.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r006\n"
printf "starting r007\n"
mkfifo /bench/final-cases/r007.pipe
cat /bench/final-cases/r007.pipe > /bench/final-cases/r007.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r007 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final-cases/r007.pipe 2> /bench/final-cases/r007.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r007.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r007\n"
printf "starting r008\n"
mkfifo /bench/final-cases/r008.pipe
cat /bench/final-cases/r008.pipe > /bench/final-cases/r008.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r008 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final-cases/r008.pipe 2> /bench/final-cases/r008.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r008.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r008\n"
printf "starting r009\n"
mkfifo /bench/final-cases/r009.pipe
cat /bench/final-cases/r009.pipe > /bench/final-cases/r009.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r009 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final-cases/r009.pipe 2> /bench/final-cases/r009.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r009.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r009\n"
printf "starting r010\n"
mkfifo /bench/final-cases/r010.pipe
cat /bench/final-cases/r010.pipe > /bench/final-cases/r010.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r010 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final-cases/r010.pipe 2> /bench/final-cases/r010.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r010.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r010\n"
printf "starting r011\n"
mkfifo /bench/final-cases/r011.pipe
cat /bench/final-cases/r011.pipe > /bench/final-cases/r011.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r011 -pool 4 -workers 8 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final-cases/r011.pipe 2> /bench/final-cases/r011.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r011.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r011\n"
printf "starting prewarm-1-direct\n"
mkfifo /bench/final-cases/prewarm-1-direct.pipe
cat /bench/final-cases/prewarm-1-direct.pipe > /bench/final-cases/prewarm-1-direct.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 0 -seconds 20 -prefix prewarm-1-direct -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 17000 > /bench/final-cases/prewarm-1-direct.pipe 2> /bench/final-cases/prewarm-1-direct.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/prewarm-1-direct.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed prewarm-1-direct\n"
printf "starting prewarm-1-weir\n"
mkfifo /bench/final-cases/prewarm-1-weir.pipe
cat /bench/final-cases/prewarm-1-weir.pipe > /bench/final-cases/prewarm-1-weir.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 0 -seconds 20 -prefix prewarm-1-weir -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 17000 -target 127.0.0.1:7447 > /bench/final-cases/prewarm-1-weir.pipe 2> /bench/final-cases/prewarm-1-weir.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/prewarm-1-weir.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed prewarm-1-weir\n"
printf "starting r012\n"
mkfifo /bench/final-cases/r012.pipe
cat /bench/final-cases/r012.pipe > /bench/final-cases/r012.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r012 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final-cases/r012.pipe 2> /bench/final-cases/r012.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r012.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r012\n"
printf "starting r013\n"
mkfifo /bench/final-cases/r013.pipe
cat /bench/final-cases/r013.pipe > /bench/final-cases/r013.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r013 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final-cases/r013.pipe 2> /bench/final-cases/r013.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r013.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r013\n"
printf "starting r014\n"
mkfifo /bench/final-cases/r014.pipe
cat /bench/final-cases/r014.pipe > /bench/final-cases/r014.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r014 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final-cases/r014.pipe 2> /bench/final-cases/r014.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r014.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r014\n"
printf "starting r015\n"
mkfifo /bench/final-cases/r015.pipe
cat /bench/final-cases/r015.pipe > /bench/final-cases/r015.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r015 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final-cases/r015.pipe 2> /bench/final-cases/r015.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r015.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r015\n"
printf "starting r016\n"
mkfifo /bench/final-cases/r016.pipe
cat /bench/final-cases/r016.pipe > /bench/final-cases/r016.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r016 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final-cases/r016.pipe 2> /bench/final-cases/r016.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r016.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r016\n"
printf "starting r017\n"
mkfifo /bench/final-cases/r017.pipe
cat /bench/final-cases/r017.pipe > /bench/final-cases/r017.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix r017 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final-cases/r017.pipe 2> /bench/final-cases/r017.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r017.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r017\n"
printf "starting r018\n"
mkfifo /bench/final-cases/r018.pipe
cat /bench/final-cases/r018.pipe > /bench/final-cases/r018.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r018 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final-cases/r018.pipe 2> /bench/final-cases/r018.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r018.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r018\n"
printf "starting r019\n"
mkfifo /bench/final-cases/r019.pipe
cat /bench/final-cases/r019.pipe > /bench/final-cases/r019.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r019 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final-cases/r019.pipe 2> /bench/final-cases/r019.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r019.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r019\n"
printf "starting r020\n"
mkfifo /bench/final-cases/r020.pipe
cat /bench/final-cases/r020.pipe > /bench/final-cases/r020.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r020 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final-cases/r020.pipe 2> /bench/final-cases/r020.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r020.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r020\n"
printf "starting r021\n"
mkfifo /bench/final-cases/r021.pipe
cat /bench/final-cases/r021.pipe > /bench/final-cases/r021.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r021 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final-cases/r021.pipe 2> /bench/final-cases/r021.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r021.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r021\n"
printf "starting r022\n"
mkfifo /bench/final-cases/r022.pipe
cat /bench/final-cases/r022.pipe > /bench/final-cases/r022.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r022 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final-cases/r022.pipe 2> /bench/final-cases/r022.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r022.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r022\n"
printf "starting r023\n"
mkfifo /bench/final-cases/r023.pipe
cat /bench/final-cases/r023.pipe > /bench/final-cases/r023.jsonl & weir_reader_pid=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix r023 -pool 4 -workers 8 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final-cases/r023.pipe 2> /bench/final-cases/r023.stderr.log
weir_case_code=$?
wait "$weir_reader_pid"
printf "%s\n" "$weir_case_code" > /bench/final-cases/r023.exit
if [ "$weir_case_code" -ne 0 ]; then exit "$weir_case_code"; fi
printf "completed r023\n"
