#!/usr/bin/env python3
"""Same-DB v3/v4 ABBA quota recovery, isolated parameter tuning, and high-load checks."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import subprocess
import threading
import time

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('instrumentation', HERE / 'es-v3-instrumentation.py')
instrumentation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(instrumentation)
comparison = instrumentation.comparison
common = instrumentation.v2main


class CapacityFixture(instrumentation.V3Fixture):
    def trial(self, mode, rate, repetition, write_every):
        before = len(self.summary['runs'])
        try:
            return super().trial(mode, rate, repetition, write_every)
        except (subprocess.SubprocessError, OSError) as error:
            # Fixture appends a run only after primary resource observation and
            # APPLIED audit pass. A subsequent optional command failure is saved
            # separately, while quota/identity mismatch remains a fatal error.
            if len(self.summary['runs']) != before + 1:
                raise
            record = self.summary['runs'][-1]
            record['instrument_error'] = str(error)[:1024]
            self.save(record['prefix'] + '-instrument-error.json', record['instrument_error'])
            self.save('summary.json', self.summary)

    def create(self, name, options, command, image=None):
        options = options.copy()
        if name == 'weir' and getattr(self, 'binary_version', 'v4') == 'v3':
            options[options.index('--entrypoint') + 1] = '/baseline'
        return super().create(name, options, command, image)

    def control_phases(self):
        initial = None
        try:
            until = time.monotonic() + 30
            while time.monotonic() < until and not self.phase_stop.is_set():
                raw = comparison.http(self.weir_url + '/metrics')
                if comparison.metric(raw, 'weir_store_executions_total') > 0:
                    break
                self.phase_stop.wait(.1)
            else:
                raise RuntimeError('phase actual Execute was not observed')
            for name, quota, seconds in [('baseline', .5, 40), ('limited', .08, 30), ('restored', .5, 70)]:
                comparison.run(['docker', 'update', '--cpus', str(quota), self.db])
                limits = comparison.run(['docker', 'inspect', '--format', '{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}} {{.RestartCount}}', self.db]).stdout.split()
                if limits != [str(int(quota * 1e9)), '0', str(1536 * 1024**2), '0']:
                    raise RuntimeError('database quota/memory/restart drift')
                cpu_max = comparison.run(['docker', 'exec', self.db, 'cat', '/sys/fs/cgroup/cpu.max']).stdout.strip()
                quota_actual, period = map(int, cpu_max.split())
                if abs(quota_actual / period - quota) > 1e-6:
                    raise RuntimeError('actual database cpu.max mismatch')
                resources = comparison.database_resources(self.db, self.db_pid)
                stat = resources['raw'].split('process_stat\n')[1].split('process_statm\n')[0].strip()
                start_ticks = int(stat[stat.rfind(')') + 2:].split()[19])
                state = json.loads(comparison.run(['docker', 'inspect', '--format', '{{json .State}}', self.db]).stdout)
                identity = (self.db, self.db_pid, start_ticks, state['Pid'], state['StartedAt'])
                if initial is None:
                    initial = identity
                if identity != initial or not state['Running'] or state['OOMKilled']:
                    raise RuntimeError('database identity changed within quota phases')
                control = {'phase': name, 'cpu_quota': quota, 'actual_cpu_max': cpu_max, 'duration_seconds': seconds, 'wall_time': time.time(), 'monotonic': time.monotonic(), 'database_container': self.db, 'database_pid': self.db_pid, 'database_start_ticks': start_ticks, 'docker_state': state, 'weir_container': self.weir, 'limits': limits, 'database_resources': resources, 'metrics': comparison.http(self.weir_url + '/metrics')}
                self.phase_controls.append(control)
                self.save('phase-controls-live.json', self.phase_controls)
                if self.phase_stop.wait(seconds):
                    break
        except Exception as exc:
            self.phase_errors.append(str(exc))
        finally:
            comparison.run(['docker', 'update', '--cpus', '.5', self.db], check=False)


def record_run(fixture, options):
    declared = common.configure(fixture, options['profile'])
    declared.update(database_cpu=fixture.args.db_cpu, client_queue=fixture.args.client_queue)
    fixture.binary_version = options['version']
    fixture.trial('weir', options['rate'], options['repetition'], options['write_every'])
    record = fixture.summary['runs'][-1]
    binary_key = 'baseline' if options['version'] == 'v3' else 'weir'
    record.update(version=options['version'], variant=options['variant'], profile=declared, binary_sha256=fixture.summary['provenance']['binary_sha256'][binary_key], helper_sha256=fixture.summary['provenance']['binary_sha256']['client'])
    for name in ('node.yaml', 'routes.yaml'):
        fixture.save(record['prefix'] + '-' + name, (fixture.root / name).read_text())
    if fixture.phase_enabled:
        record['controls'] = fixture.phase_controls
        fixture.save(record['prefix'] + '-controls.json', record['controls'])
    fixture.save('summary.json', fixture.summary)
    progress = {'event': 'v4_comparison_complete', 'prefix': record['prefix'], 'version':record['version'], 'variant':record['variant'], 'profile':declared, 'audit':record['audit']}
    print(json.dumps(progress), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bin-dir', type=Path, required=True)
    parser.add_argument('--reference-raw', type=Path, required=True)
    parser.add_argument('--v3-manifest', type=Path, required=True)
    parser.add_argument('--v4-manifest', type=Path, required=True)
    options = parser.parse_args()
    v3 = json.loads(options.v3_manifest.read_text())
    v4 = json.loads(options.v4_manifest.read_text())
    binary_options = [('weir-v3', v3['binaries']['weir']), ('weir', v4['binaries']['weir']), ('client', v4['binaries']['client'])]
    for name, expected in binary_options:
        if hashlib.sha256((options.bin_dir / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('frozen binary mismatch: ' + name)
    reference = json.loads((options.reference_raw / 'summary.json').read_text())
    values = reference['provenance']['options'].copy()
    values.update(client=options.bin_dir/'client',weir=options.bin_dir/'weir',baseline_weir=options.bin_dir/'weir-v3',baseline_source=v3['head'],output=options.output,workers=32,pool=4,batch_operations=8,collect_ms=3,max_read_size='16KiB',seconds=120,warm=20,client_queue=32,modes='weir',rates='2500',write_every='10',db_cpu=.5,recovery_rate=0,recovery_seconds=0)
    args = argparse.Namespace(**values)
    fixture = CapacityFixture(args)
    pressure = {'pool':4,'collect_ms':3,'max_read_size':'16KiB','workers':32,'batch':8}
    tuned_pressure = {'pool':2,'collect_ms':5,'max_read_size':'16KiB','workers':32,'batch':32}
    high = {'pool':2,'collect_ms':5,'max_read_size':'16KiB','workers':64,'batch':32}
    def interrupted(_signum,_frame):
        raise KeyboardInterrupt('owned v4 capacity fixture interrupted; cleanup follows')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        fixture.start()
        fixture.save('frozen-v3-manifest.json',v3)
        fixture.save('frozen-v4-manifest.json',v4)
        system = {'clock_ticks':fixture.db_ticks,'page_size':fixture.db_page_size,'database_container':fixture.db,'database_pid':fixture.db_pid}
        fixture.save('resource-system.json',system)
        fixture.summary['experiment'] = {'kind':'v3-v4-abba','started':time.time(),'runner':Path(__file__).name,'pressure_order':['v3','v4','v4','v3'],'phase_schedule':'first actual Execute: .5CPU40s then .08CPU30s then .5CPU70s; client warm20/measure120 at fixed2500/s/1s deadline. Only pure measurement windows count healthy: warm is excluded.','tuning_note':'V4-only pressure group changes batch8→32,pool4→2,collect3→5ms; w32/session32/memory2304 unchanged. High3200 regression has only1repeat/version/workload; not replacement for v3 3repeat matrix.','helper_note':'Same client-v4 on both versions, preserving validated mutation evidence on RPC error and bounded safe transport diagnostic tags. Earlier v3 measurements used older helper and remain intermediate, not direct matched.'}
        common.configure(fixture,pressure)
        fixture.binary_version = 'v4'
        fixture.prewarm(10)
        fixture.phase_enabled = True
        pressure_cases = [(version,'bp-'+version,pressure) for version in ('v3','v4','v4','v3')] + [('v4','bp-v4-tuned',tuned_pressure)]*2
        for repetition,(version,variant,profile) in enumerate(pressure_cases):
            run_options = {'version':version,'variant':variant,'profile':profile,'rate':2500,'repetition':repetition,'write_every':10}
            try:
                record_run(fixture,run_options)
            finally:
                if getattr(fixture,'phase_stop',None) is not None:
                    fixture.phase_stop.set()
                    fixture.phase_thread.join(15)
                fixture.save('phase-last-errors.json',getattr(fixture,'phase_errors',[]))
            if fixture.phase_errors or len(fixture.phase_controls)!=3:
                raise RuntimeError('phase controls failed: '+str(fixture.phase_errors))
        fixture.phase_enabled = False
        fixture.args.db_cpu,fixture.args.seconds,fixture.args.warm,fixture.args.client_queue = .25,20,10,256
        for write_every in (10,1):
            common.configure(fixture,high)
            fixture.binary_version='v4'
            fixture.prewarm(write_every)
            versions = ('v3','v4') if write_every==10 else ('v4','v3')
            for version in versions:
                run_options = {'version':version,'variant':'high-'+version,'profile':high,'rate':3200,'repetition':0,'write_every':write_every}
                record_run(fixture,run_options)
        fixture.summary['experiment']['completed']=time.time()
        fixture.save('summary.json',fixture.summary)
    finally:
        if not fixture.cleanup():
            raise RuntimeError('owned fixture cleanup incomplete')


if __name__=='__main__':
    main()
