#!/usr/bin/env python3
"""Independent ES v3/v4 ABBA pure-write tail follow-up, frozen binaries/helper."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import time

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('base',HERE/'es-v4-runner.py')
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--bin-dir',type=Path,required=True)
    parser.add_argument('--reference-raw',type=Path,required=True)
    options=parser.parse_args()
    reference=json.loads((options.reference_raw/'summary.json').read_text())
    expected=reference['provenance']['binary_sha256']
    for filename,key in [('weir','weir'),('weir-v3','baseline'),('client','client')]:
        if hashlib.sha256((options.bin_dir/filename).read_bytes()).hexdigest()!=expected[key]:
            raise RuntimeError('frozen binary mismatch: '+filename)
    values=reference['provenance']['options'].copy()
    values.update(client=options.bin_dir/'client',weir=options.bin_dir/'weir',baseline_weir=options.bin_dir/'weir-v3',output=options.output,workers=64,pool=2,batch_operations=32,collect_ms=5,max_read_size='16KiB',seconds=20,warm=10,client_queue=256,modes='weir',rates='3200',write_every='1',db_cpu=.25,recovery_rate=0,recovery_seconds=0)
    args=argparse.Namespace(**values)
    fixture=base.CapacityFixture(args)
    fixture.phase_enabled=False
    profile={'pool':2,'collect_ms':5,'max_read_size':'16KiB','workers':64,'batch':32}
    def interrupted(_signum,_frame):
        raise KeyboardInterrupt('owned pure-tail fixture interrupted; cleanup follows')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        fixture.start()
        for source in list(HERE.glob('*.py'))+[Path('/Users/liran/Projects/liran/go/weir/scripts/compare-load.py'),Path('/Users/liran/Projects/liran/go/weir/scripts/config_yaml.py')]:
            shutil.copyfile(source,fixture.root/source.name)
        for filename in ('frozen-v3-manifest.json','frozen-v4-manifest.json'):
            shutil.copyfile(options.reference_raw/filename,fixture.root/filename)
        system={'clock_ticks':fixture.db_ticks,'page_size':fixture.db_page_size,'database_container':fixture.db,'database_pid':fixture.db_pid}
        fixture.save('resource-system.json',system)
        fixture.summary['experiment']={'kind':'independent-pure-tail-abba','started':time.time(),'runner':Path(__file__).name,'order':['v3','v4','v4','v3'],'rate':3200,'write_every':1,'warm_seconds':10,'measure_seconds':20,'note':'Independent new owned ES DB process; do not pool with original10cells as3repetitions. Investigates original v4 pure p9538ms/v3p958.9ms unresolved single-run tail. Same frozen helper/binaries/resources, common JVM prewarm, all drops preserved.'}
        base.common.configure(fixture,profile)
        fixture.binary_version='v4'
        fixture.prewarm(1)
        for repetition,version in enumerate(('v3','v4','v4','v3')):
            run_options={'version':version,'variant':'pure-tail-'+version,'profile':profile,'rate':3200,'repetition':repetition,'write_every':1}
            base.record_run(fixture,run_options)
        fixture.summary['experiment']['completed']=time.time()
        fixture.save('summary.json',fixture.summary)
    finally:
        if not fixture.cleanup():
            raise RuntimeError('owned pure-tail cleanup incomplete')


if __name__=='__main__':
    main()
