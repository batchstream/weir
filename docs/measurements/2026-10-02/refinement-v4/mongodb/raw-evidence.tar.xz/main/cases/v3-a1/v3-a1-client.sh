set -eu
mkfifo /bench/v3-a1/v3-a1.pipe
cat /bench/v3-a1/v3-a1.pipe > /bench/v3-a1/v3-a1-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 2500 -warm 20 -seconds 120 -prefix v3-a1 -pool 4 -workers 32 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 32 -load-delay-ms 3000 -mutation-reservation 36000 > /bench/v3-a1/v3-a1.pipe 2> /bench/v3-a1/v3-a1-client-stderr.log
wait "$reader"
touch /bench/v3-a1/v3-a1.done
