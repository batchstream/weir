set -eu
mkfifo /bench/perf-v3-mixed/perf-v3-mixed.pipe
cat /bench/perf-v3-mixed/perf-v3-mixed.pipe > /bench/perf-v3-mixed/perf-v3-mixed-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 3200 -warm 10 -seconds 20 -prefix perf-v3-mixed -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 10600 > /bench/perf-v3-mixed/perf-v3-mixed.pipe 2> /bench/perf-v3-mixed/perf-v3-mixed-client-stderr.log
wait "$reader"
touch /bench/perf-v3-mixed/perf-v3-mixed.done
