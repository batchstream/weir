set -eu
mkfifo /bench/perf-v4-write/perf-v4-write.pipe
cat /bench/perf-v4-write/perf-v4-write.pipe > /bench/perf-v4-write/perf-v4-write-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 3200 -warm 10 -seconds 20 -prefix perf-v4-write -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 97000 > /bench/perf-v4-write/perf-v4-write.pipe 2> /bench/perf-v4-write/perf-v4-write-client-stderr.log
wait "$reader"
touch /bench/perf-v4-write/perf-v4-write.done
