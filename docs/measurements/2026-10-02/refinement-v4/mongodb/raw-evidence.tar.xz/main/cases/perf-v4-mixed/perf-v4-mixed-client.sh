set -eu
mkfifo /bench/perf-v4-mixed/perf-v4-mixed.pipe
cat /bench/perf-v4-mixed/perf-v4-mixed.pipe > /bench/perf-v4-mixed/perf-v4-mixed-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 3200 -warm 10 -seconds 20 -prefix perf-v4-mixed -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 10600 > /bench/perf-v4-mixed/perf-v4-mixed.pipe 2> /bench/perf-v4-mixed/perf-v4-mixed-client-stderr.log
wait "$reader"
touch /bench/perf-v4-mixed/perf-v4-mixed.done
