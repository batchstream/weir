import argparse
import base64
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile


def module(root):
    spec = importlib.util.spec_from_file_location('measurement_analysis', root / 'analyze.py')
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def inspect_case(root, case):
    directory = root / case['tag']
    result = json.loads((directory / 'analysis.json').read_text())
    manifest = json.loads((directory / 'manifest.json').read_text())
    raw_path = directory / 'raw.tar.gz'
    checks = {'archive_sha_matches_remote': hashlib.sha256(raw_path.read_bytes()).hexdigest() == manifest['raw_sha256']}
    raw = {}
    with tarfile.open(raw_path) as archive:
        for member in archive.getmembers():
            if member.isfile():
                raw[Path(member.name).name] = archive.extractfile(member).read()
    client = [json.loads(line) for line in raw[case['tag'] + '-client.jsonl'].splitlines()]
    trial_row = next(row for row in client if row['type'] == 'trial')
    audit = next(row for row in client if row['type'] == 'audit')
    trial = trial_row['trial']
    ledger = base64.b64decode(audit['ledger'], validate=True)
    counts = dict(sorted(Counter(ledger).items()))
    metrics = trial['measure']['all']
    options = trial['options']
    full = [trial['warm']['all'], metrics]
    failures = sum(sum((part.get('failures') or {}).values()) for part in full)
    checks['ledger_length'] = len(ledger) == options['Rate'] * (options['WarmSeconds'] + options['Seconds']) // options['WriteEvery']
    checks['ledger_values_valid'] = set(counts).issubset({0, 1, 2, 3, 4})
    checks['applied_all_audited'] = counts.get(1, 0) == audit['audit']['applied']
    checks['audit_no_error'] = audit['error'] == '<nil>'
    checks['run_no_error'] = trial_row['run_error'] == '<nil>'
    checks['measurement_conservation'] = metrics['planned'] == metrics['started'] + metrics['client_drop'] and metrics['started'] == metrics['success'] + sum((metrics.get('failures') or {}).values())
    checks['all_10s_conservation'] = all(window['all']['planned'] == window['all']['started'] + window['all']['client_drop'] and window['all']['started'] == window['all']['success'] + sum((window['all'].get('failures') or {}).values()) for window in trial['ten_second_windows'])
    checks['10s_sums_match_measurement'] = all(sum(window['all'][field] for window in trial['ten_second_windows']) == metrics[field] for field in ('planned', 'started', 'success', 'client_drop', 'unknown'))
    node = json.loads(raw[case['tag'] + '-node.json'])
    routes = json.loads(raw[case['tag'] + '-routes.json'])
    local = routes['services'][0]['local']
    profile = manifest['profile']
    checks['actual_inputs_match_declared'] = node['memory'] == str(profile['memory_mib']) + 'MiB' and node['transport']['max_sessions'] == options['Workers'] == profile['workers'] and node['transport']['max_connections'] == 16 and local['max_concurrency'] == profile['cap'] and local['max_batch_operations'] == profile['batch'] and local['batch_collect'] == str(profile['collect_ms']) + 'ms' and local['max_read_size'] == '16KiB' and options['Rate'] == profile['rate'] and options['ClientQueue'] == profile['client_queue'] and options['WriteEvery'] == profile['write_every']
    checks['sampler_stderr_empty'] = not raw[case['tag'] + '-weir-sampler.log'] and not raw[case['tag'] + '-database-sampler.log']
    analysis = module(root)
    _, data = analysis.load(directory)
    db = data['database']
    weir = data['weir']
    db_id = manifest['database_identity']
    checks['db_sample_identity_matches_manifest'] = {row['process_start_ticks'] for row in db} == {db_id['start_ticks']}
    checks['weir_sample_identity_unique'] = len({row['process_start_ticks'] for row in weir}) == 1
    expected_quota=[manifest['healthy_cpu_m'],manifest['slow_cpu_m'],manifest['healthy_cpu_m']] if profile['dynamic'] else [manifest['healthy_cpu_m']]
    checks['actual_quota_sequence'] = [int(entry['resize']['confirmed']['cpu_max'].split()[0])*1000//int(entry['resize']['confirmed']['cpu_max'].split()[1]) for entry in manifest['transitions']] == expected_quota
    checks['all_resize_identity_fixed'] = all(all(entry['resize'][side][key] == db_id[key] for key in ('start_ticks','container_id','restart_count')) for entry in manifest['transitions'] for side in ('before','confirmed'))
    checks['all_IO_samples_present'] = all('process_io' in row and 'cgroup_io' in row and 'io_pressure' in row for row in db + weir)
    guards = {}
    for name, phase in result['phases'].items():
        windows = phase['windows']
        next_change = manifest['transitions'][1]['resize']['requested_wall_time'] if name == 'healthy' and len(manifest['transitions']) > 1 else manifest['transitions'][2]['resize']['requested_wall_time'] if name == 'slow' else min(db[-1]['wall_time'], weir[-1]['wall_time'])
        complete = [window for window in windows if window['end'] + 1 <= next_change]
        guards[name] = {'arrival_windows': len(windows), 'completion_guarded_windows': len(complete), 'next_quota_request_or_last_sampler_time': next_change, 'eligible_indexes': [window['index'] for window in complete]}
        phase['completion_guarded_windows'] = complete
        if complete:
            interval = [complete[0]['start'], complete[-1]['end']]
            phase['whole_window_database'] = analysis.resources(db, interval)
            phase['whole_window_weir'] = analysis.resources(weir, interval)
            phase['whole_window_controller'] = analysis.phase_stats(weir, interval)
            phase['mean_success_per_second'] = sum(window['success_per_second'] for window in complete) / len(complete)
    db_oom = db[-1]['memory_events']['oom_kill'] - db[0]['memory_events']['oom_kill']
    weir_oom = weir[-1]['memory_events']['oom_kill'] - weir[0]['memory_events']['oom_kill']
    receipt = {'ledger_counts': {str(key): value for key, value in counts.items()}, 'ledger_length': len(ledger), 'full_API_failures': failures, 'full_success': sum(part['success'] for part in full), 'full_client_drop': sum(part['client_drop'] for part in full), 'full_unknown_operations': sum(part['unknown'] for part in full), 'database_OOM_kill_delta': db_oom, 'weir_OOM_kill_delta': weir_oom, 'completion_guards': guards, 'checks': checks, 'raw_config_names': [case['tag'] + suffix for suffix in ('-node.json', '-routes.json', '-client.sh')], 'raw_sample_counts': {'database': len(db), 'weir': len(weir)}, 'database_identity': db_id, 'process_IO_sampling_scope': 'cgroup includes observer overhead; process counters target actual application PID', 'block_delay_scope': 'field presence is not proof kernel delay accounting enabled; zero cannot rule out IO stalls'}
    result['measure_p95_arrival_ms'] = metrics['success_arrival']['p95_us'] / 1000
    result['measure_p95_dispatch_ms'] = metrics['success_dispatch']['p95_us'] / 1000
    result['measure_p99_arrival_ms'] = metrics['success_arrival']['p99_us'] / 1000
    for phase in result['phases'].values():
        for window in phase['windows']:
            original=trial['ten_second_windows'][window['index']]['all']
            window['p95_arrival_ms']=original['success_arrival']['p95_us']/1000
            window['p95_dispatch_ms']=original['success_dispatch']['p95_us']/1000
    result['evidence_checks'] = receipt
    if 'recovery' in result['phases']:
        healthy = result['phases']['healthy'].get('mean_success_per_second')
        recovered = result['phases']['recovery'].get('mean_success_per_second')
        result['recovery_to_healthy_ratio'] = recovered / healthy if healthy and recovered is not None else None
        result['qualification'] = 'formal' if guards['healthy']['completion_guarded_windows'] >= 2 and guards['recovery']['completion_guarded_windows'] >= 3 else 'insufficient completion guarded steady windows'
    (directory / 'analysis.json').write_text(json.dumps(result, indent=2))
    (directory / 'evidence-checks.json').write_text(json.dumps(receipt, indent=2))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    opts = parser.parse_args()
    plan = json.loads((opts.root / 'plan.json').read_text())
    cases = plan['cases'] + plan['performance_regression']['cases']
    cases += [case for case in plan['optional_fixed_cap_cases'] if (opts.root / case['tag'] / 'analysis.json').exists()]
    results = [inspect_case(opts.root, case) for case in cases]
    identities = [result['evidence_checks']['database_identity'] for result in results]
    identity_keys = ['start_ticks', 'container_id', 'restart_count']
    fixed = all(all(identity[key] == identities[0][key] for key in identity_keys) for identity in identities)
    receipts = [result['evidence_checks'] for result in results]
    keys = ['ledger_length', 'full_API_failures', 'full_success', 'full_client_drop', 'full_unknown_operations', 'database_OOM_kill_delta', 'weir_OOM_kill_delta']
    totals = {key: sum(receipt[key] for receipt in receipts) for key in keys}
    ledger = Counter()
    for receipt in receipts:
        ledger.update(receipt['ledger_counts'])
    totals['ledger_counts'] = dict(sorted(ledger.items()))
    value = {'scope': 'Mongo same owned DB/node ABBA4 + performance4; fixed cap diagnostics only if separately declared residual criterion', 'plan': plan, 'binary_provenance': json.loads((opts.root / 'bundle-provenance.json').read_text()), 'same_database_identity_all_trials': fixed, 'database_identity': identities[0], 'checks_all_passed': all(all(receipt['checks'].values()) for receipt in receipts), 'totals': totals, 'results': results, 'cleanup': json.loads((opts.root / 'cleanup.json').read_text())}
    (opts.root / 'summary.json').write_text(json.dumps(value, indent=2))
    print(json.dumps({'cases': len(results), 'same_database_identity': fixed, 'checks_all_passed': value['checks_all_passed'], 'totals': totals}))


if __name__ == '__main__':
    main()
