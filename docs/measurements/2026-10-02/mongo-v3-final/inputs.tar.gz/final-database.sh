set -eu
test "$(cat /proc/1/comm)" = mongod
cat /sys/fs/cgroup/cpu.max > /bench/final-database-quota.txt
cat /proc/1/stat > /bench/final-database-identity.txt
while IFS=" " read -r name action; do
stem=/bench/final/$name
if [ "$action" = stop ]; then
kill -TERM "$(cat "$stem.database_sampler_pid")"
touch "$stem.database_stopped"
continue
fi
/bench/sampler -pid 1 -output "$stem-database.jsonl" > "$stem-database-sampler.log" 2>&1 < /dev/null &
printf "%s" "$!" > "$stem.database_sampler_pid"
touch "$stem.database_ready"
done < /bench/final-database.pipe
