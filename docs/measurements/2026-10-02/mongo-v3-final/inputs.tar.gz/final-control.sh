set -eu
while IFS=" " read -r name binary; do
tag=$(printf "%s" "$name" | sed "s/-[0-9]*$//")
stem=/bench/$tag/$name
if [ "$binary" = stop ]; then
kill -TERM "$(cat "$stem.sampler_pid")"
weir_pid=$(cat "$stem.weir_pid")
test "$(cat /proc/$weir_pid/comm)" = weir || test "$(cat /proc/$weir_pid/comm)" = baseline-weir
kill -TERM "$weir_pid"
for i in 1 2 3 4 5 6 7 8 9 10; do kill -0 "$weir_pid" 2>/dev/null || break; sleep 0.5; done
touch "$stem.stopped"
continue
fi
/bench/$binary serve --config /bench/$name-node.yaml --routes /bench/$name-routes.yaml > "$stem-weir.log" 2>&1 < /dev/null &
weir_pid=$!
printf "%s" "$weir_pid" > "$stem.weir_pid"
for i in 1 2 3 4 5 6 7 8 9 10; do wget -q -O /dev/null http://127.0.0.1:7449/readyz && break; sleep 0.5; done
wget -q -O /dev/null http://127.0.0.1:7449/readyz
/bench/sampler-metrics -pid "$weir_pid" -output "$stem-weir.jsonl" -metrics http://127.0.0.1:7449/metrics > "$stem-weir-sampler.log" 2>&1 < /dev/null &
printf "%s" "$!" > "$stem.sampler_pid"
touch "$stem.ready"
done < /bench/final-control.pipe
