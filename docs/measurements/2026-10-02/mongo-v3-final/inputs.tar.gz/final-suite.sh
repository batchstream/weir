set -eu
mkdir /bench/final
printf started > /bench/final/state
exec 3> /bench/final-control.pipe
exec 4> /bench/final-database.pipe
printf "%s start\n" final-0 >&4
while [ ! -f /bench/final/final-0.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-0.pipe
cat /bench/final/final-0.pipe > /bench/final/final-0-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-0 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final/final-0.pipe 2> /bench/final/final-0-stderr.log
wait "$reader"
printf "%s stop\n" final-0 >&4
while [ ! -f /bench/final/final-0.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-0.done
printf "%s %s\n" final-1 weir >&3
while [ ! -f /bench/final/final-1.ready ]; do sleep 0.1; done
printf "%s start\n" final-1 >&4
while [ ! -f /bench/final/final-1.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-1.pipe
cat /bench/final/final-1.pipe > /bench/final/final-1-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-1 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final/final-1.pipe 2> /bench/final/final-1-stderr.log
wait "$reader"
printf "%s stop\n" final-1 >&4
while [ ! -f /bench/final/final-1.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-1 >&3
while [ ! -f /bench/final/final-1.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-1.done
printf "%s start\n" final-2 >&4
while [ ! -f /bench/final/final-2.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-2.pipe
cat /bench/final/final-2.pipe > /bench/final/final-2-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-2 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final/final-2.pipe 2> /bench/final/final-2-stderr.log
wait "$reader"
printf "%s stop\n" final-2 >&4
while [ ! -f /bench/final/final-2.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-2.done
printf "%s %s\n" final-3 weir >&3
while [ ! -f /bench/final/final-3.ready ]; do sleep 0.1; done
printf "%s start\n" final-3 >&4
while [ ! -f /bench/final/final-3.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-3.pipe
cat /bench/final/final-3.pipe > /bench/final/final-3-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-3 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final/final-3.pipe 2> /bench/final/final-3-stderr.log
wait "$reader"
printf "%s stop\n" final-3 >&4
while [ ! -f /bench/final/final-3.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-3 >&3
while [ ! -f /bench/final/final-3.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-3.done
printf "%s start\n" final-4 >&4
while [ ! -f /bench/final/final-4.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-4.pipe
cat /bench/final/final-4.pipe > /bench/final/final-4-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-4 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final/final-4.pipe 2> /bench/final/final-4-stderr.log
wait "$reader"
printf "%s stop\n" final-4 >&4
while [ ! -f /bench/final/final-4.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-4.done
printf "%s %s\n" final-5 weir >&3
while [ ! -f /bench/final/final-5.ready ]; do sleep 0.1; done
printf "%s start\n" final-5 >&4
while [ ! -f /bench/final/final-5.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-5.pipe
cat /bench/final/final-5.pipe > /bench/final/final-5-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-5 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final/final-5.pipe 2> /bench/final/final-5-stderr.log
wait "$reader"
printf "%s stop\n" final-5 >&4
while [ ! -f /bench/final/final-5.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-5 >&3
while [ ! -f /bench/final/final-5.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-5.done
printf "%s start\n" final-6 >&4
while [ ! -f /bench/final/final-6.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-6.pipe
cat /bench/final/final-6.pipe > /bench/final/final-6-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-6 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final/final-6.pipe 2> /bench/final/final-6-stderr.log
wait "$reader"
printf "%s stop\n" final-6 >&4
while [ ! -f /bench/final/final-6.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-6.done
printf "%s %s\n" final-7 weir >&3
while [ ! -f /bench/final/final-7.ready ]; do sleep 0.1; done
printf "%s start\n" final-7 >&4
while [ ! -f /bench/final/final-7.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-7.pipe
cat /bench/final/final-7.pipe > /bench/final/final-7-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-7 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final/final-7.pipe 2> /bench/final/final-7-stderr.log
wait "$reader"
printf "%s stop\n" final-7 >&4
while [ ! -f /bench/final/final-7.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-7 >&3
while [ ! -f /bench/final/final-7.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-7.done
printf "%s %s\n" final-8 weir >&3
while [ ! -f /bench/final/final-8.ready ]; do sleep 0.1; done
printf "%s start\n" final-8 >&4
while [ ! -f /bench/final/final-8.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-8.pipe
cat /bench/final/final-8.pipe > /bench/final/final-8-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-8 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final/final-8.pipe 2> /bench/final/final-8-stderr.log
wait "$reader"
printf "%s stop\n" final-8 >&4
while [ ! -f /bench/final/final-8.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-8 >&3
while [ ! -f /bench/final/final-8.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-8.done
printf "%s start\n" final-9 >&4
while [ ! -f /bench/final/final-9.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-9.pipe
cat /bench/final/final-9.pipe > /bench/final/final-9-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-9 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final/final-9.pipe 2> /bench/final/final-9-stderr.log
wait "$reader"
printf "%s stop\n" final-9 >&4
while [ ! -f /bench/final/final-9.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-9.done
printf "%s %s\n" final-10 weir >&3
while [ ! -f /bench/final/final-10.ready ]; do sleep 0.1; done
printf "%s start\n" final-10 >&4
while [ ! -f /bench/final/final-10.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-10.pipe
cat /bench/final/final-10.pipe > /bench/final/final-10-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-10 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final/final-10.pipe 2> /bench/final/final-10-stderr.log
wait "$reader"
printf "%s stop\n" final-10 >&4
while [ ! -f /bench/final/final-10.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-10 >&3
while [ ! -f /bench/final/final-10.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-10.done
printf "%s start\n" final-11 >&4
while [ ! -f /bench/final/final-11.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-11.pipe
cat /bench/final/final-11.pipe > /bench/final/final-11-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-11 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final/final-11.pipe 2> /bench/final/final-11-stderr.log
wait "$reader"
printf "%s stop\n" final-11 >&4
while [ ! -f /bench/final/final-11.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-11.done
printf "%s %s\n" final-12 weir >&3
while [ ! -f /bench/final/final-12.ready ]; do sleep 0.1; done
printf "%s start\n" final-12 >&4
while [ ! -f /bench/final/final-12.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-12.pipe
cat /bench/final/final-12.pipe > /bench/final/final-12-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-12 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final/final-12.pipe 2> /bench/final/final-12-stderr.log
wait "$reader"
printf "%s stop\n" final-12 >&4
while [ ! -f /bench/final/final-12.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-12 >&3
while [ ! -f /bench/final/final-12.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-12.done
printf "%s start\n" final-13 >&4
while [ ! -f /bench/final/final-13.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-13.pipe
cat /bench/final/final-13.pipe > /bench/final/final-13-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-13 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final/final-13.pipe 2> /bench/final/final-13-stderr.log
wait "$reader"
printf "%s stop\n" final-13 >&4
while [ ! -f /bench/final/final-13.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-13.done
printf "%s %s\n" final-14 weir >&3
while [ ! -f /bench/final/final-14.ready ]; do sleep 0.1; done
printf "%s start\n" final-14 >&4
while [ ! -f /bench/final/final-14.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-14.pipe
cat /bench/final/final-14.pipe > /bench/final/final-14-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-14 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final/final-14.pipe 2> /bench/final/final-14-stderr.log
wait "$reader"
printf "%s stop\n" final-14 >&4
while [ ! -f /bench/final/final-14.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-14 >&3
while [ ! -f /bench/final/final-14.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-14.done
printf "%s start\n" final-15 >&4
while [ ! -f /bench/final/final-15.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-15.pipe
cat /bench/final/final-15.pipe > /bench/final/final-15-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-15 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final/final-15.pipe 2> /bench/final/final-15-stderr.log
wait "$reader"
printf "%s stop\n" final-15 >&4
while [ ! -f /bench/final/final-15.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-15.done
printf "%s start\n" final-16 >&4
while [ ! -f /bench/final/final-16.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-16.pipe
cat /bench/final/final-16.pipe > /bench/final/final-16-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-16 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 > /bench/final/final-16.pipe 2> /bench/final/final-16-stderr.log
wait "$reader"
printf "%s stop\n" final-16 >&4
while [ ! -f /bench/final/final-16.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-16.done
printf "%s %s\n" final-17 weir >&3
while [ ! -f /bench/final/final-17.ready ]; do sleep 0.1; done
printf "%s start\n" final-17 >&4
while [ ! -f /bench/final/final-17.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-17.pipe
cat /bench/final/final-17.pipe > /bench/final/final-17-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-17 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 3400 -target 127.0.0.1:7447 > /bench/final/final-17.pipe 2> /bench/final/final-17-stderr.log
wait "$reader"
printf "%s stop\n" final-17 >&4
while [ ! -f /bench/final/final-17.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-17 >&3
while [ ! -f /bench/final/final-17.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-17.done
printf "%s start\n" final-18 >&4
while [ ! -f /bench/final/final-18.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-18.pipe
cat /bench/final/final-18.pipe > /bench/final/final-18-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-18 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 > /bench/final/final-18.pipe 2> /bench/final/final-18-stderr.log
wait "$reader"
printf "%s stop\n" final-18 >&4
while [ ! -f /bench/final/final-18.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-18.done
printf "%s %s\n" final-19 weir >&3
while [ ! -f /bench/final/final-19.ready ]; do sleep 0.1; done
printf "%s start\n" final-19 >&4
while [ ! -f /bench/final/final-19.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-19.pipe
cat /bench/final/final-19.pipe > /bench/final/final-19-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-19 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 10600 -target 127.0.0.1:7447 > /bench/final/final-19.pipe 2> /bench/final/final-19-stderr.log
wait "$reader"
printf "%s stop\n" final-19 >&4
while [ ! -f /bench/final/final-19.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-19 >&3
while [ ! -f /bench/final/final-19.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-19.done
printf "%s start\n" final-20 >&4
while [ ! -f /bench/final/final-20.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-20.pipe
cat /bench/final/final-20.pipe > /bench/final/final-20-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-20 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 > /bench/final/final-20.pipe 2> /bench/final/final-20-stderr.log
wait "$reader"
printf "%s stop\n" final-20 >&4
while [ ! -f /bench/final/final-20.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-20.done
printf "%s %s\n" final-21 weir >&3
while [ ! -f /bench/final/final-21.ready ]; do sleep 0.1; done
printf "%s start\n" final-21 >&4
while [ ! -f /bench/final/final-21.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-21.pipe
cat /bench/final/final-21.pipe > /bench/final/final-21-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 800 -warm 10 -seconds 20 -prefix final-21 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 25000 -target 127.0.0.1:7447 > /bench/final/final-21.pipe 2> /bench/final/final-21-stderr.log
wait "$reader"
printf "%s stop\n" final-21 >&4
while [ ! -f /bench/final/final-21.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-21 >&3
while [ ! -f /bench/final/final-21.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-21.done
printf "%s start\n" final-22 >&4
while [ ! -f /bench/final/final-22.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-22.pipe
cat /bench/final/final-22.pipe > /bench/final/final-22-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-22 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 > /bench/final/final-22.pipe 2> /bench/final/final-22-stderr.log
wait "$reader"
printf "%s stop\n" final-22 >&4
while [ ! -f /bench/final/final-22.database_stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-22.done
printf "%s %s\n" final-23 weir >&3
while [ ! -f /bench/final/final-23.ready ]; do sleep 0.1; done
printf "%s start\n" final-23 >&4
while [ ! -f /bench/final/final-23.database_ready ]; do sleep 0.1; done
mkfifo /bench/final/final-23.pipe
cat /bench/final/final-23.pipe > /bench/final/final-23-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -rate 3200 -warm 10 -seconds 20 -prefix final-23 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -mutation-reservation 97000 -target 127.0.0.1:7447 > /bench/final/final-23.pipe 2> /bench/final/final-23-stderr.log
wait "$reader"
printf "%s stop\n" final-23 >&4
while [ ! -f /bench/final/final-23.database_stopped ]; do sleep 0.1; done
printf "%s stop\n" final-23 >&3
while [ ! -f /bench/final/final-23.stopped ]; do sleep 0.1; done
printf completed > /bench/final/final-23.done
exec 3>&-
exec 4>&-
printf completed > /bench/final/state
tar -czf /bench/final.tar.gz -C /bench final final-cases.json
sha256sum /bench/final.tar.gz > /bench/final.sha256
