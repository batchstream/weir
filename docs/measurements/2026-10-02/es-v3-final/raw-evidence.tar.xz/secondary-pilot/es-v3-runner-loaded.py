#!/usr/bin/env python3
"""Frozen v3 ES capacity recovery, then paired tuned/direct performance."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import time

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('phasecommon',HERE/'es-v2-stable-phase-runner-fixedpid.py')
phasecommon=importlib.util.module_from_spec(spec)
spec.loader.exec_module(phasecommon)
comparison=phasecommon.comparison
v2main=phasecommon.v2main


class V3Fixture(phasecommon.StablePhaseFixture):
    def trial(self, mode, rate, repetition, write_every):
        super().trial(mode, rate, repetition, write_every)
        cpu_max = comparison.run(['docker', 'exec', self.db, 'cat', '/sys/fs/cgroup/cpu.max']).stdout.strip()
        quota, period = map(int, cpu_max.split())
        if abs(quota / period - self.args.db_cpu) > 1e-6:
            raise RuntimeError('post-trial actual database quota drift')
        resources = comparison.database_resources(self.db, self.db_pid)
        stat = resources['raw'].split('process_stat\n')[1].split('process_statm\n')[0].strip()
        start_ticks = int(stat[stat.rfind(')') + 2:].split()[19])
        state = json.loads(comparison.run(['docker', 'inspect', '--format', '{{json .State}}', self.db]).stdout)
        identity = (self.db, self.db_pid, start_ticks, state['Pid'], state['StartedAt'])
        if not hasattr(self, 'verified_database_identity'):
            self.verified_database_identity = identity
        if identity != self.verified_database_identity or not state['Running'] or state['OOMKilled']:
            raise RuntimeError('post-trial authoritative database identity drift')
        receipt = {
            'wall_time': time.time(), 'database_cpu_max': cpu_max,
            'database_container': self.db, 'database_pid': self.db_pid,
            'database_start_ticks': start_ticks, 'database_docker_state': state,
            'database_resources': resources,
            'load_start_nano_cpu_verification': 'Fixture.trial checks declared quota/cpuset0/1536MiB before load-delay ends',
        }
        if mode != 'direct':
            receipt['weir_cpu_max'] = comparison.run(['docker', 'exec', self.weir, 'cat', '/sys/fs/cgroup/cpu.max']).stdout.strip()
            receipt['weir_limits'] = comparison.run(['docker', 'inspect', '--format', '{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}}', self.weir]).stdout.split()
            if receipt['weir_limits'] != ['2000000000', '3,4', str(self.weir_memory * 1024**2)]:
                raise RuntimeError('post-trial Weir resource drift')
        record = self.summary['runs'][-1]
        record['actual_resource_receipt'] = receipt
        self.save(record['prefix'] + '-actual-resources.json', receipt)
        self.save('summary.json', self.summary)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--bin-dir',type=Path,required=True)
    parser.add_argument('--reference-raw',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--phase-rate',type=int,choices=(1600,2500),default=2500)
    options=parser.parse_args()
    manifest=json.loads(options.manifest.read_text())
    for name, key in (('client-v2','client'),('weir-v3','weir')):
        actual=hashlib.sha256((options.bin_dir/name).read_bytes()).hexdigest()
        if actual!=manifest['binaries'][key]:
            raise RuntimeError('frozen binary mismatch: '+name)
    reference=json.loads((options.reference_raw/'summary.json').read_text())
    values=reference['provenance']['options'].copy()
    overrides={'client':options.bin_dir/'client-v2','weir':options.bin_dir/'weir-v3','baseline_weir':None,'output':options.output,'workers':32,'pool':4,'batch_operations':8,'collect_ms':3,'max_read_size':'16KiB','seconds':20,'warm':10,'client_queue':32,'modes':'direct,weir','rates':str(options.phase_rate),'write_every':'10','db_cpu':.5,'recovery_rate':0,'recovery_seconds':0}
    values.update(overrides)
    args=argparse.Namespace(**values)
    fixture=V3Fixture(args)
    phase_profile={'pool':4,'collect_ms':3,'max_read_size':'16KiB','workers':32,'batch':8}
    tuning={'pool':2,'collect_ms':5,'max_read_size':'16KiB','workers':64,'batch':32}
    def interrupted(_signum,_frame):
        raise KeyboardInterrupt('owned v3 fixture interrupted; cleanup follows')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        fixture.start()
        fixture.save('frozen-build-manifest.json',manifest)
        resource_system={'clock_ticks':fixture.db_ticks,'page_size':fixture.db_page_size,'database_container':fixture.db,'database_pid':fixture.db_pid}
        fixture.save('resource-system.json',resource_system)
        fixture.summary['experiment']={'version':'v3 slow-fraction confirmation','runner':Path(__file__).name,'kind':'recovery-and-paired-matrix','client_version':'client-v2 unchanged generator; see v2 manifest','started':time.time(),'measurement_cpu_note':'per-run profile is canonical: quota phases .5/.08/.5; performance .25; same DB identity and generator'}
        declared=v2main.configure(fixture,phase_profile)
        declared.update(database_cpu=.5,client_queue=32)
        fixture.prewarm(10)
        fixture.trial('weir',options.phase_rate,0,10)
        pilot=fixture.summary['runs'][-1]
        pilot.update(variant='health-pilot',version='v3',profile=declared)
        m=pilot['measure']['all']
        qualified=(not m['failures'] and m['unknown']==0 and pilot['weir']['window_min']==4 and pilot['weir']['decreases']==0)
        pilot['qualification_note']='Controller health: stable4, no decrease, API/UNKNOWN0. Client queue drops remain reported; qualification does not assert full offered throughput.'
        pilot['qualified_healthy_capacity']=qualified
        fixture.save('summary.json',fixture.summary)
        progress={'event':'v3_health_preflight','qualified':qualified,'rate':options.phase_rate,'measure':{k:m[k]for k in ('planned','success','client_drop','unknown','failures')},'window':[pilot['weir']['window_min'],pilot['weir']['window_max']],'database_cpu':pilot['database']['cpu_cores_mean']}
        print(json.dumps(progress),flush=True)
        if not qualified:
            raise RuntimeError('healthy v3 baseline rejected; pilot preserved, no phase or matrix')
        fixture.summary['selected_offered_rate']=options.phase_rate
        fixture.args.seconds,fixture.args.warm=90,0
        fixture.phase_enabled=True
        for repetition in range(2):
            try:
                fixture.trial('weir',options.phase_rate,repetition,10)
            finally:
                if getattr(fixture,'phase_stop',None) is not None:
                    fixture.phase_stop.set()
                    fixture.phase_thread.join(15)
                fixture.save('phase-last-errors.json',getattr(fixture,'phase_errors',[]))
            if fixture.phase_errors or len(fixture.phase_controls)!=3:
                raise RuntimeError('phase controller incomplete: '+str(fixture.phase_errors))
            record=fixture.summary['runs'][-1]
            record.update(variant='backpressure',version='v3',profile=declared,controls=fixture.phase_controls)
            for name in ('node.yaml','routes.yaml'):
                fixture.save(record['prefix']+'-'+name,(fixture.root/name).read_text())
            fixture.save(record['prefix']+'-controls.json',fixture.phase_controls)
            fixture.save('summary.json',fixture.summary)
            progress={'event':'v3_phase_complete','prefix':record['prefix'],'weir':record['weir'],'audit':record['audit']}
            print(json.dumps(progress),flush=True)
        fixture.phase_enabled=False
        fixture.args.db_cpu=.25
        fixture.args.client_queue=256
        fixture.args.seconds,fixture.args.warm=20,10
        fixture.summary['selected_tuning']=tuning
        for write_every in (10,1):
            v2main.configure(fixture,tuning)
            fixture.prewarm(write_every)
            for rate in (800,3200):
                for repetition in range(3):
                    variants=('matched-direct','new-tuned') if repetition%2==0 else ('new-tuned','matched-direct')
                    for variant in variants:
                        declared=v2main.configure(fixture,tuning)
                        declared.update(database_cpu=.25,client_queue=256)
                        mode='direct' if variant=='matched-direct' else 'weir'
                        fixture.trial(mode,rate,repetition,write_every)
                        record=fixture.summary['runs'][-1]
                        record.update(variant=variant,version='v3',profile=declared)
                        if mode!='direct':
                            for name in ('node.yaml','routes.yaml'):
                                fixture.save(record['prefix']+'-'+name,(fixture.root/name).read_text())
                        fixture.save('summary.json',fixture.summary)
                        progress={'event':'v3_matrix_complete','prefix':record['prefix'],'variant':variant,'rate':rate,'write_every':write_every}
                        print(json.dumps(progress),flush=True)
        fixture.summary['experiment']['completed']=time.time()
        fixture.save('summary.json',fixture.summary)
    finally:
        if not fixture.cleanup():
            raise RuntimeError('fixture cleanup incomplete')


if __name__=='__main__':
    main()
