#!/usr/bin/env python3
"""Healthy ES capacity preflight followed by two v2 .5/.08/.5 quota phases."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import time
import threading

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('v2main', HERE / 'es-v2-runner.py')
v2main = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v2main)
comparison = v2main.comparison


class StablePhaseFixture(comparison.Fixture):
    def start_weir(self, mode):
        super().start_weir(mode)
        if not getattr(self, 'phase_enabled', False):
            return
        self.phase_controls, self.phase_errors = [], []
        self.phase_stop = threading.Event()
        self.phase_thread = threading.Thread(target=self.control_phases)
        self.phase_thread.start()

    def control_phases(self):
        initial = None
        try:
            until = time.monotonic() + 30
            while time.monotonic() < until and not self.phase_stop.is_set():
                raw = comparison.http(self.weir_url + '/metrics')
                if comparison.metric(raw, 'weir_store_executions_total') > 0:
                    break
                self.phase_stop.wait(0.1)
            else:
                raise RuntimeError('phase load start not observed')
            for name, quota, duration in [('baseline', 0.5, 20), ('limited', 0.08, 30), ('restored', 0.5, 30)]:
                comparison.run(['docker', 'update', '--cpus', str(quota), self.db])
                limits = comparison.run(['docker', 'inspect', '--format', '{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}} {{.RestartCount}}', self.db]).stdout.split()
                if limits != [str(int(quota * 1e9)), '0', str(1536 * 1024**2), '0']:
                    raise RuntimeError('phase quota or restart identity drift')
                cpu_max = comparison.run(['docker', 'exec', self.db, 'cat', '/sys/fs/cgroup/cpu.max']).stdout.strip()
                cpu_fields = cpu_max.split()
                if len(cpu_fields) != 2 or abs(int(cpu_fields[0]) / int(cpu_fields[1]) - quota) > 1e-6:
                    raise RuntimeError('actual cgroup quota mismatch')
                resources = comparison.database_resources(self.db, self.db_pid)
                process_stat = resources['raw'].split('process_stat\n')[1].split('process_statm\n')[0].strip()
                process_start = int(process_stat[process_stat.rfind(')') + 2:].split()[19])
                state = json.loads(comparison.run(['docker', 'inspect', '--format', '{{json .State}}', self.db]).stdout)
                identity = (self.db, self.db_pid, process_start, state['Pid'], state['StartedAt'])
                if initial is None:
                    initial = identity
                if identity != initial or not state['Running'] or state['OOMKilled']:
                    raise RuntimeError('database process changed during quota phase')
                control = {
                    'phase': name, 'cpu_quota': quota, 'actual_cpu_max': cpu_max,
                    'duration_seconds': duration, 'wall_time': time.time(), 'monotonic': time.monotonic(),
                    'database_container': self.db, 'database_pid': self.db_pid,
                    'database_start_ticks': process_start, 'docker_state': state,
                    'weir_container': self.weir, 'limits': limits,
                    'database_resources': resources, 'metrics': comparison.http(self.weir_url + '/metrics'),
                }
                self.phase_controls.append(control)
                self.save('phase-controls-live.json', self.phase_controls)
                if self.phase_stop.wait(duration):
                    break
        except Exception as exc:
            self.phase_errors.append(str(exc))
        finally:
            comparison.run(['docker', 'update', '--cpus', '0.5', self.db], check=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bin-dir', type=Path, required=True)
    parser.add_argument('--reference-raw', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--rate', type=int, choices=(1600, 2500, 3200), default=2500)
    options = parser.parse_args()
    manifest = json.loads(options.manifest.read_text())
    for name in ('client-v2', 'weir-v2', 'baseline-weir'):
        actual = hashlib.sha256((options.bin_dir / name).read_bytes()).hexdigest()
        if actual != manifest['binaries'][name]:
            raise RuntimeError('frozen binary mismatch: ' + name)
    reference = json.loads((options.reference_raw / 'summary.json').read_text())
    values = reference['provenance']['options'].copy()
    values.update(client=options.bin_dir / 'client-v2', weir=options.bin_dir / 'weir-v2',
                  baseline_weir=options.bin_dir / 'baseline-weir', output=options.output,
                  workers=32, pool=4, batch_operations=8, collect_ms=3,
                  max_read_size='16KiB', seconds=90, warm=0, client_queue=32,
                  modes='direct,weir', rates=str(options.rate), write_every='10', db_cpu=0.5,
                  recovery_rate=0, recovery_seconds=0)
    args = argparse.Namespace(**values)
    fixture = StablePhaseFixture(args)
    profile = {'pool': 4, 'collect_ms': 3, 'max_read_size': '16KiB', 'workers': 32, 'batch': 8}
    declared = v2main.configure(fixture, profile)
    declared['client_queue'] = 32
    declared['database_cpu'] = 0.5
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt('owned v2 phase fixture interrupted; cleanup follows')
    signal.signal(signal.SIGTERM, interrupted)
    try:
        fixture.start()
        fixture.save('frozen-build-manifest.json', manifest)
        fixture.save('resource-system.json', {'clock_ticks': fixture.db_ticks, 'page_size': fixture.db_page_size,
                                             'database_container': fixture.db, 'database_pid': fixture.db_pid})
        fixture.summary['experiment'] = {'version': 'v2 final CFS hold fix', 'kind': 'healthy-quota-phase-only', 'runner': Path(__file__).name,
            'reference_raw': str(options.reference_raw), 'started': time.time(), 'profile': declared,
            'phase_schedule': 'healthy preflight at .5CPU, then first actual Execute: .5CPU20s -> .08CPU30s -> .5CPU30s; continuous90s',
            'learning_note': 'Common JVM prewarm uses this fixed read/batch profile. Each measured Weir starts fresh; its first20s .5CPU baseline is the controller learning interval. Report readiness before limited phase; no baseline is presumed.'}
        fixture.prewarm(10)
        selected_rate = None
        fixture.args.seconds, fixture.args.warm = 20, 10
        for offered in (options.rate,):
            fixture.trial('weir', offered, 0, 10)
            pilot = fixture.summary['runs'][-1]
            pilot.update(variant='health-pilot', version='v2', profile=declared)
            measured = pilot['measure']['all']
            qualified = (measured['planned'] == measured['success'] and measured['client_drop'] == 0
                         and not measured['failures'] and pilot['weir']['window_min'] == 4
                         and pilot['weir']['decreases'] == 0)
            pilot['qualified_healthy_capacity'] = qualified
            fixture.save('summary.json', fixture.summary)
            print(json.dumps({'event': 'v2_health_preflight', 'prefix': pilot['prefix'], 'offered': offered,
                              'qualified': qualified, 'success': measured['success'], 'drop': measured['client_drop'],
                              'api_errors': measured['failures'], 'weir_window': [pilot['weir']['window_min'],pilot['weir']['window_max']],
                              'database_cpu': pilot['database']['cpu_cores_mean']}), flush=True)
            if qualified:
                selected_rate = offered
                break
        if selected_rate is None:
            raise RuntimeError('no sustainable healthy baseline; all pilots preserved')
        fixture.summary['selected_offered_rate'] = selected_rate
        fixture.args.seconds, fixture.args.warm = 90, 0
        fixture.phase_enabled = True
        for repetition in range(2):
            try:
                fixture.trial('weir', selected_rate, repetition, 10)
            finally:
                if getattr(fixture, 'phase_stop', None) is not None:
                    fixture.phase_stop.set()
                    fixture.phase_thread.join(15)
                fixture.save('phase-last-controls.json', getattr(fixture, 'phase_controls', []))
                fixture.save('phase-last-errors.json', getattr(fixture, 'phase_errors', []))
            if fixture.phase_errors or len(fixture.phase_controls) != 3:
                raise RuntimeError('phase controller incomplete: ' + str(fixture.phase_errors))
            record = fixture.summary['runs'][-1]
            record.update(variant='backpressure', version='v2', profile=declared, controls=fixture.phase_controls)
            for filename in ('node.yaml', 'routes.yaml'):
                fixture.save(record['prefix'] + '-' + filename, (fixture.root / filename).read_text())
            fixture.save(record['prefix'] + '-controls.json', fixture.phase_controls)
            fixture.save('summary.json', fixture.summary)
            print(json.dumps({'event': 'v2_phase_complete', 'prefix': record['prefix'], 'profile': declared,
                              'controls': [{k: c[k] for k in ('phase', 'cpu_quota', 'actual_cpu_max', 'database_pid', 'database_start_ticks')} for c in record['controls']]}), flush=True)
        fixture.phase_enabled = False
        fixture.summary['experiment']['completed'] = time.time()
        fixture.save('summary.json', fixture.summary)
    finally:
        if not fixture.cleanup():
            raise RuntimeError('fixture cleanup incomplete')


if __name__ == '__main__':
    main()
