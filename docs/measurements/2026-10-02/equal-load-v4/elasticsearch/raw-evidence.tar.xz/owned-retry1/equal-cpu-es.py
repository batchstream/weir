#!/usr/bin/env python3
"""Frozen v4 ES throughput at matched complete-window DB process CPU."""
import argparse
import hashlib
import datetime
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import sys
import time

HERE=Path(__file__).parent
sys.path.insert(0,str(HERE))
spec=importlib.util.spec_from_file_location('comparison',HERE/'compare-load.py')
comparison=importlib.util.module_from_spec(spec);spec.loader.exec_module(comparison)


class EqualCPUFixture(comparison.Fixture):
    def __init__(self,args):
        super().__init__(args)
        self.weir_memory=4608
        self.data_volume=None

    def create(self,name,options,command,image=None):
        options=options.copy()
        if name=='db':
            self.data_volume=self.owner+'-data'
            comparison.run(['docker','volume','create','--label',comparison.LABEL+'='+self.owner,self.data_volume])
            volume=json.loads(comparison.run(['docker','volume','inspect',self.data_volume]).stdout)[0]
            if volume['Name']!=self.data_volume or volume['Labels'].get(comparison.LABEL)!=self.owner:
                raise RuntimeError('data volume ownership mismatch')
            self.save('owned-volume-identity.json',volume)
            index=options.index('--tmpfs');options[index:index+2]=['--mount','type=volume,src='+self.data_volume+',dst=/usr/share/elasticsearch/data']
        return super().create(name,options,command,image)

    def start_weir(self,mode):
        super().start_weir(mode)
        result=comparison.run(['docker','exec','-e','WEIR_CAPACITY_INTEGRATION=1',self.weir,'/client','-mode','snapshot'],check=False)
        self.save('last-weir-cgroup-snapshot.json',result.stdout)
        self.save('last-weir-cgroup-stderr.log',result.stderr)
        if result.returncode:
            raise RuntimeError('pre-load Weir cgroup receipt failed')
        self.weir_cgroup_receipt=json.loads(result.stdout)
        if self.weir_cgroup_receipt.get('errors') or self.weir_cgroup_receipt['files']['cpu.max'].strip()!='400000 100000':
            raise RuntimeError('pre-load Weir actual quota invalid')

    def observation(self):
        result={'wall_time':time.time()}
        for filename in('/proc/'+self.db_pid+'/io','/sys/fs/cgroup/io.stat','/sys/fs/cgroup/io.pressure'):
            observed=comparison.run(['docker','exec',self.db,'cat',filename],check=False)
            result[filename]={'status':observed.returncode,'raw':observed.stdout,'error':observed.stderr}
        result['df']=comparison.run(['docker','exec',self.db,'df','-B1','/usr/share/elasticsearch/data']).stdout
        result['index_stats']=json.loads(comparison.http(self.db_url+'/_stats/docs,store,translog?filter_path=_all.primaries.docs,_all.primaries.store,_all.primaries.translog'))
        return result

    def trial(self,mode,rate,repetition,write_every):
        observation=self.observation()
        super().trial(mode,rate,repetition,write_every)
        record=self.summary['runs'][-1]
        client_records=[json.loads(line) for line in (self.root/(record['prefix']+'-client.jsonl')).read_text().splitlines()]
        trial_record=next(row['trial'] for row in client_records if row.get('type')=='trial')
        begin=datetime.datetime.fromisoformat(trial_record['start'].replace('Z','+00:00')).timestamp()+self.args.warm
        end=begin+self.args.seconds
        samples=[json.loads(line) for line in (self.root/(record['prefix']+'-samples.jsonl')).read_text().splitlines()]
        measured=[row for row in samples if begin<=row['wall_time']<=end and 'database_resources' in row]
        coverage={'nominal_measure_seconds':self.args.seconds,'sample_counter_span_seconds':record['database']['sample_seconds'],'first_sample_margin_seconds':measured[0]['wall_time']-begin,'last_sample_margin_seconds':end-measured[-1]['wall_time'],'first_sample_wall_time':measured[0]['wall_time'],'last_sample_wall_time':measured[-1]['wall_time'],'samples':len(measured),'algorithm':'All samples with entry.wall_time inside complete nominal measure, counterfirst/last divided by real countermonotonic span, no window selection'}
        coverage['qualified']=coverage['sample_counter_span_seconds']>=self.args.seconds*.95 and coverage['first_sample_margin_seconds']<=2 and coverage['last_sample_margin_seconds']<=2
        record['cpu_coverage']=coverage
        cpu_max=comparison.run(['docker','exec',self.db,'cat','/sys/fs/cgroup/cpu.max']).stdout.strip()
        if cpu_max!='25000 100000':
            raise RuntimeError('actual DB cpu.max drift')
        resources=comparison.database_resources(self.db,self.db_pid)
        stat=resources['raw'].split('process_stat\n')[1].split('process_statm\n')[0].strip()
        start_ticks=int(stat[stat.rfind(')')+2:].split()[19])
        state=json.loads(comparison.run(['docker','inspect','--format','{{json .State}}',self.db]).stdout)
        limits=comparison.run(['docker','inspect','--format','{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}} {{.RestartCount}}',self.db]).stdout.split()
        identity=(self.db,self.db_pid,start_ticks,state['Pid'],state['StartedAt'])
        if not hasattr(self,'verified_database_identity'):
            self.verified_database_identity=identity
        if identity!=self.verified_database_identity or limits!=['250000000','0',str(1536*2**20),'0'] or state['OOMKilled'] or not state['Running']:
            raise RuntimeError('DB process/resource identity drift')
        receipt={'wall_time':time.time(),'database_cpu_max':cpu_max,'database_container':self.db,'database_pid':self.db_pid,'database_start_ticks':start_ticks,'database_docker_state':state,'database_limits':limits,'database_resources':resources,'storage':'owned standard Docker local disk volume; no data tmpfs','data_volume':self.data_volume}
        if mode!='direct':
            receipt['weir_cpu_max']=self.weir_cgroup_receipt['files']['cpu.max'].strip()
            receipt['weir_limits']=comparison.run(['docker','inspect','--format','{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}}',self.weir]).stdout.split()
            if receipt['weir_limits']!=['4000000000','3,4,5,6',str(4608*2**20)]:
                raise RuntimeError('Weir resource drift')
            receipt['note']='Only shared cgroup fields verify Weir resources; helper PID CPU/RSS is not Weir process. Weir process CPU/RSS comes from Prometheus.'
            self.save(record['prefix']+'-weir-cgroup-receipt.json',self.weir_cgroup_receipt)
        record['actual_resource_receipt']=receipt
        self.save(record['prefix']+'-actual-resources.json',receipt)
        self.save(record['prefix']+'-io-before.json',observation)
        self.save(record['prefix']+'-io-after.json',self.observation())
        self.save('summary.json',self.summary)

    def cleanup(self):
        volume_errors=[]
        if self.data_volume:
            if hasattr(self,'db'):
                inspection=comparison.run(['docker','inspect','--format','{{index .Config.Labels "'+comparison.LABEL+'"}}',self.db],check=False)
                if inspection.returncode==0 and inspection.stdout.strip()==self.owner:
                    comparison.run(['docker','stop','--time','10',self.db],check=False)
                    logs=comparison.run(['docker','logs',self.db],check=False)
                    self.save(self.db[:12]+'-container.log',logs.stdout+logs.stderr)
                    removal=comparison.run(['docker','rm',self.db],check=False)
                    if removal.returncode:
                        volume_errors.append(removal.stderr)
                elif inspection.returncode==0:
                    volume_errors.append('database ownership mismatch during volume cleanup')
            inspection=comparison.run(['docker','volume','inspect',self.data_volume],check=False)
            if inspection.returncode==0:
                volume=json.loads(inspection.stdout)[0]
                if volume['Name']==self.data_volume and volume['Labels'].get(comparison.LABEL)==self.owner:
                    removal=comparison.run(['docker','volume','rm',self.data_volume],check=False)
                    if removal.returncode:
                        volume_errors.append(removal.stderr)
                else:
                    volume_errors.append('data volume ownership mismatch during cleanup')
            remaining=comparison.run(['docker','volume','ls','-q','--filter','label='+comparison.LABEL+'='+self.owner]).stdout.splitlines()
            if remaining:
                volume_errors.append('owned volumes remain')
            self.save('owned-volume-cleanup.json',{'name':self.data_volume,'errors':volume_errors,'remaining_owned_volumes':remaining})
        complete=super().cleanup()
        if volume_errors:
            self.summary['cleanup']['errors'].extend(volume_errors)
            self.summary['cleanup']['pass']=False
            self.save('summary.json',self.summary)
        return complete and not volume_errors


def stage(fixture,options):
    fixture.args.warm,fixture.args.seconds=options['warm'],options['seconds']
    fixture.trial(options['mode'],options['rate'],options.get('repetition',0),options['write_every'])
    record=fixture.summary['runs'][-1]
    record.update(stage=options['stage'],workload='mixed' if options['write_every']==10 else 'pure',version='v4',profile={'workers':64,'sessions':64,'client_queue':256,'direct_pool':4,'weir_pool':2,'batch_operations':32,'collect_ms':5,'max_read_size':'16KiB','database_cpu':.25,'database_memory_mib':1536,'weir_cpu':4,'weir_memory_mib':4608,'client_cpu':2,'client_memory_mib':2048,'storage':'owned ordinary disk volume'},warm_seconds=options['warm'],measure_seconds=options['seconds'])
    for filename in('node.yaml','routes.yaml'):
        if options['mode']!='direct':fixture.save(record['prefix']+'-'+filename,(fixture.root/filename).read_text())
    fixture.save('summary.json',fixture.summary)
    a=record['measure']['all']
    print(json.dumps({'event':'equal_cpu_stage','prefix':record['prefix'],'stage':record['stage'],'workload':record['workload'],'mode':record['mode'],'rate':record['rate'],'cpu':record['database']['cpu_cores_mean'],'success_rps':a['success']/options['seconds'],'p95_ms':a['success_arrival']['p95_us']/1000,'drop':a['client_drop'],'api':sum((a['failures'] or {}).values()),'unknown':a['unknown'],'client_lag_p99_ms':record['client']['lag_p99_us']/1000,'audit':record['audit']}),flush=True)
    return record


def idle(fixture,tag):
    fixture.stop_weir()
    samples=[]
    for index in range(6):
        samples.append(comparison.database_resources(fixture.db,fixture.db_pid))
        if index<5:time.sleep(1)
    resource_options={'cpu':.25,'ticks':fixture.db_ticks,'page_size':fixture.db_page_size}
    receipt={'tag':tag,'wall_time':time.time(),'database':comparison.resource_summary(samples,resource_options),'samples':samples,'io':fixture.observation()}
    fixture.save('idle-'+tag+'.json',receipt)
    fixture.summary.setdefault('idle',[]).append(receipt)
    fixture.save('summary.json',fixture.summary)


def calibrate(fixture,options):
    mode,write_every,round_number=(options[k] for k in('mode','write_every','round'))
    cap=6400 if write_every==10 else 3730
    rate=min(cap,max(10,options['initial_rate']))
    attempts=[]
    for attempt in range(6):
        trial_options={'stage':'calibration','mode':mode,'rate':rate,'warm':20,'seconds':30,'write_every':write_every,'repetition':attempt}
        record=stage(fixture,trial_options)
        cpu=record['database']['cpu_cores_mean'];a=record['measure']['all']
        api=sum((a['failures'] or {}).values())
        drop_fraction=a['client_drop']/a['planned']
        healthy=(api==0 and a['unknown']==0 and drop_fraction<=.005 and record['client']['cpu_cores_measure_bracket']<1.8 and record['client']['lag_p99_us']<=100000 and (mode=='direct' or record['weir']['cpu_cores_mean']<3.6))
        qualified=.095<=cpu<=.105 and healthy and record['cpu_coverage']['qualified']
        record['calibration']={'round':round_number,'attempt':attempt,'qualified':qualified,'healthy':healthy,'target':.10,'target_error_relative':abs(cpu-.1)/.1,'drop_fraction':drop_fraction,'health_gate':'APIUNKNOWN0; drop_fraction<=0.5%; clientCPU<90%quota; clientlagp99<=100ms; WeirCPU<90%quota'}
        attempts.append(record['prefix']);fixture.save('summary.json',fixture.summary)
        if qualified:
            result={'mode':mode,'write_every':write_every,'round':round_number,'rate':rate,'cpu':cpu,'prefix':record['prefix'],'attempts':attempts}
            print(json.dumps({'event':'calibration_qualified',**result}),flush=True)
            return result
        if cpu<=0:
            break
        suggested=int(round(rate*.1/cpu/10)*10)
        suggested=min(cap,max(10,suggested))
        if suggested==rate and cpu<.095 and rate==cap:
            break
        rate=suggested
    result={'mode':mode,'write_every':write_every,'round':round_number,'qualified':False,'rate':None,'attempts':attempts,'reason':'target/health gate not reached within frozen helper and six attempts; no normalized estimate substituted'}
    print(json.dumps({'event':'calibration_unmatched',**result}),flush=True)
    return result


def run_pair(fixture,options):
    records=[]
    for mode in options['order']:
        trial_options={'stage':'formal','mode':mode,'rate':options['rates'][mode],'warm':20,'seconds':60,'write_every':options['write_every'],'repetition':options['pair']}
        record=stage(fixture,trial_options)
        record['formal_pair']={'number':options['pair'],'round':options['round']}
        records.append(record)
    by_mode={r['mode']:r for r in records};d=by_mode['direct']['database']['cpu_cores_mean'];w=by_mode['weir']['database']['cpu_cores_mean']
    difference=abs(d-w)/((d+w)/2)
    pair={'workload':'mixed' if options['write_every']==10 else 'pure','number':options['pair'],'round':options['round'],'order':options['order'],'prefixes':[r['prefix'] for r in records],'rates':options['rates'],'direct_cpu':d,'weir_cpu':w,'pair_relative_cpu_difference':difference,'cpu_coverage_qualified':all(r['cpu_coverage']['qualified'] for r in records),'matched':.095<=d<=.105 and .095<=w<=.105 and difference<=.05 and all(r['cpu_coverage']['qualified'] for r in records)}
    fixture.summary.setdefault('pairs',[]).append(pair)
    fixture.save('summary.json',fixture.summary)
    print(json.dumps({'event':'formal_pair',**pair}),flush=True)
    return pair


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--bin-dir',type=Path,required=True)
    parser.add_argument('--reference-raw',type=Path,required=True)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--repo',type=Path,default=Path('/Users/liran/Projects/liran/go/weir'))
    options=parser.parse_args()
    comparison.REPO=options.repo.resolve()
    plan=json.loads(options.plan.read_text())
    for filename,key in [('weir','weir_binary_sha256'),('client','common_client_sha256')]:
        if hashlib.sha256((options.bin_dir/filename).read_bytes()).hexdigest()!=plan['provenance'][key]:raise RuntimeError('frozen binary mismatch '+filename)
    reference=json.loads((options.reference_raw/'summary.json').read_text())
    values=reference['provenance']['options'].copy()
    values.update(client=options.bin_dir/'client',weir=options.bin_dir/'weir',baseline_weir=None,output=options.output,workers=64,pool=2,direct_pool=4,batch_operations=32,collect_ms=5,max_read_size='16KiB',seconds=30,warm=20,client_queue=256,modes='direct,weir',rates='800,2800,3200,3730,6400',write_every='10,1',db_cpu=.25,weir_cpu=4,recovery_rate=0,recovery_seconds=0)
    args=argparse.Namespace(**values);fixture=EqualCPUFixture(args)
    def interrupted(_signum,_frame):raise KeyboardInterrupt('owned equalCPU fixture interrupted; cleanup follows')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        fixture.start()
        for source in HERE.glob('*.py'):shutil.copyfile(source,fixture.root/source.name)
        shutil.copyfile(options.plan,fixture.root/'plan.json');shutil.copyfile(options.manifest,fixture.root/'frozen-v4-manifest.json')
        fixture.save('resource-system.json',{'clock_ticks':fixture.db_ticks,'page_size':fixture.db_page_size,'database_container':fixture.db,'database_pid':fixture.db_pid})
        fixture.summary['experiment']={'kind':'equal-measured-DB-process-CPU','started':time.time(),'target_cpu':.10,'storage':'one new owned standard Docker local disk volume, distinct from prior tmpfs experiments','plan':plan,'rates_frozen_per_round':True,'calibration_only_adjusts_offered_input_no_CPU_normalized_throughput':True}
        fixture.summary['runner_hash']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        fixture.save('host-before.json',{'wall_time':time.time(),'uptime':comparison.run(['uptime']).stdout})
        for write_every in(10,1):
            workload='mixed' if write_every==10 else 'pure'
            idle(fixture,workload+'-before')
            for mode in('direct','weir'):
                warm_options={'stage':'common-prewarm','mode':mode,'rate':800,'warm':0,'seconds':30,'write_every':write_every}
                stage(fixture,warm_options)
            idle(fixture,workload+'-after-commonwarm')
            initial={'direct':800,'weir':3000 if write_every==10 else 2800}
            selection={}
            for mode in('direct','weir'):
                calibration_options={'mode':mode,'write_every':write_every,'round':0,'initial_rate':initial[mode]}
                selection[mode]=calibrate(fixture,calibration_options)
            fixture.summary.setdefault('calibrations',[]).extend(selection.values());fixture.save('summary.json',fixture.summary)
            if any(x.get('rate') is None for x in selection.values()):
                continue
            rates={mode:x['rate'] for mode,x in selection.items()};orders=[['direct','weir'],['weir','direct'],['direct','weir']]
            latest={}
            for number,order in enumerate(orders):
                pair_options={'order':order,'rates':rates,'write_every':write_every,'pair':number,'round':0}
                latest[number]=run_pair(fixture,pair_options)
            for round_number in(1,2):
                unmatched=[number for number,pair in latest.items() if not pair['matched']]
                if not unmatched:break
                selection={}
                for mode in('direct','weir'):
                    calibration_options={'mode':mode,'write_every':write_every,'round':round_number,'initial_rate':rates[mode]}
                    selection[mode]=calibrate(fixture,calibration_options)
                fixture.summary['calibrations'].extend(selection.values());fixture.save('summary.json',fixture.summary)
                if any(x.get('rate') is None for x in selection.values()):break
                rates={mode:x['rate'] for mode,x in selection.items()}
                for number in unmatched:
                    pair_options={'order':orders[number],'rates':rates,'write_every':write_every,'pair':number,'round':round_number}
                    latest[number]=run_pair(fixture,pair_options)
            fixture.summary.setdefault('selected_pairs',{})[workload]=list(latest.values());fixture.save('summary.json',fixture.summary)
            idle(fixture,workload+'-after-formal')
        fixture.summary['experiment']['completed']=time.time();fixture.save('summary.json',fixture.summary)
    finally:
        if not fixture.cleanup():raise RuntimeError('owned equalCPU cleanup incomplete')


if __name__=='__main__':main()
