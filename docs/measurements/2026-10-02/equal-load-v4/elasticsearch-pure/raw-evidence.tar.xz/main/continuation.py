#!/usr/bin/env python3
"""Adopt the same owned ES fixture after an explicit coordinator handoff."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import sys
import time

HERE=Path(__file__).parent
sys.path.insert(0,str(HERE))
spec=importlib.util.spec_from_file_location('equal_cpu',HERE/'equal-cpu-es.py')
suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
c=suite.comparison
c.REPO=Path('/Users/liran/Projects/liran/go/weir')
DIAGNOSTIC='/_nodes/stats/thread_pool,http,jvm,process,indexing_pressure,fs?filter_path=nodes.*.thread_pool.write,nodes.*.http.current_open,nodes.*.http.total_opened,nodes.*.process.cpu,nodes.*.jvm.mem,nodes.*.jvm.gc,nodes.*.indexing_pressure,nodes.*.fs.io_stats'


def adopt(root):
    summary=json.loads((root/'summary.json').read_text());owner=summary['owner']
    values=summary['provenance']['options'].copy();values.update(output=root,es_stats_interval_seconds=0,run_prefix_offset=1)
    args=argparse.Namespace(**values)
    f=suite.EqualCPUFixture.__new__(suite.EqualCPUFixture)
    f.args=args;f.root=root;f.owner=owner;f.network=owner;f.backend='elasticsearch';f.backend_url='http://elasticsearch:9200'
    f.workers=64;f.weir_cpu=4;f.weir_cpuset='3,4,5,6';f.weir_memory=4608;f.summary=summary;f.data_volume=owner+'-data'
    inspected=json.loads(c.run(['docker','inspect',owner+'-db',owner+'-client']).stdout)
    for item in inspected:
        if item['Config']['Labels'].get(c.LABEL)!=owner or not item['State']['Running']:
            raise RuntimeError('adopted container identity/state mismatch')
    f.db=inspected[0]['Id'];f.client=inspected[1]['Id'];f.image=inspected[1]['Config']['Image'];f.ids=[f.db,f.client]
    image=json.loads(c.run(['docker','image','inspect',f.image]).stdout)[0]
    network=json.loads(c.run(['docker','network','inspect',f.network]).stdout)[0]
    volume=json.loads(c.run(['docker','volume','inspect',f.data_volume]).stdout)[0]
    if image['Config']['Labels'].get(c.LABEL)!=owner or network['Labels'].get(c.LABEL)!=owner or volume['Labels'].get(c.LABEL)!=owner:
        raise RuntimeError('adopted image/network/volume ownership mismatch')
    others=c.run(['docker','ps','-aq','--filter','label='+c.LABEL+'='+owner]).stdout.splitlines()
    f.weir=None
    for cid in others:
        item=json.loads(c.run(['docker','inspect',cid]).stdout)[0]
        if item['Id'] not in f.ids:
            if item['Name']!='/'+owner+'-weir':raise RuntimeError('unexpected owned container during adoption')
            f.weir=item['Id'];f.ids.append(item['Id'])
    system=json.loads((root/'resource-system.json').read_text());f.db_pid=system['database_pid'];f.db_ticks=system['clock_ticks'];f.db_page_size=system['page_size']
    port=c.run(['docker','port',f.db,'9200/tcp']).stdout.strip().split(':')[-1];f.db_url='http://127.0.0.1:'+port
    latest=summary['runs'][-1]['actual_resource_receipt'];state=inspected[0]['State']
    resource=c.database_resources(f.db,f.db_pid)
    stat=resource['raw'].split('process_stat\n')[1].split('process_statm\n')[0].strip();start_ticks=int(stat[stat.rfind(')')+2:].split()[19])
    identity=(f.db,f.db_pid,start_ticks,state['Pid'],state['StartedAt'])
    if identity!=(latest['database_container'],latest['database_pid'],latest['database_start_ticks'],latest['database_docker_state']['Pid'],latest['database_docker_state']['StartedAt']):
        raise RuntimeError('same Java process handoff mismatch')
    f.verified_database_identity=identity
    cpu_max=c.run(['docker','exec',f.db,'cat','/sys/fs/cgroup/cpu.max']).stdout.strip()
    if cpu_max!='25000 100000':raise RuntimeError('quota changed before adoption')
    client_processes=c.run(['docker','top',f.client,'-eo','pid,args']).stdout
    if '-mode trial' in client_processes or '-mode pace' in client_processes:raise RuntimeError('old helper still active')
    receipt={'wall_time':time.time(),'owner':owner,'database_container':f.db,'client_container':f.client,'other_owned_containers':[x for x in f.ids if x not in (f.db,f.client)],'network':{'name':f.network,'id':network['Id'],'labels':network['Labels']},'image':{'id':image['Id'],'labels':image['Config']['Labels']},'volume':{'name':volume['Name'],'labels':volume['Labels']},'database_identity':identity,'actual_cpu_max':cpu_max,'client_processes':client_processes,'sole_cleanup_coordinator':'continuation.py','old_python_coordinator_exited':True,'note':'No DB process restart. Old sampler/coordinator stopped and terminated; no old helper business process active.'}
    f.save('owner-adoption.json',receipt)
    f.stop_weir()
    return f


def observer_baseline(f):
    samples=[];begin=time.monotonic()
    while time.monotonic()-begin<30:
        entry={'wall_time':time.time(),'database_resources':c.database_resources(f.db,f.db_pid)}
        entry['database']=json.loads(c.http(f.db_url+DIAGNOSTIC))
        samples.append(entry);time.sleep(.5)
    resource_options={'cpu':.25,'ticks':f.db_ticks,'page_size':f.db_page_size}
    receipt={'wall_time':time.time(),'kind':'no-business-load original2Hz fullESdiagnostics observer baseline','samples':samples,'database':c.resource_summary([s['database_resources'] for s in samples],resource_options),'business_requests':0,'storage':'same ordinary owned volume','database_container':f.db,'database_pid':f.db_pid,'sampler_note':'Same original observer sequence resources then fullESstats then0.5s wait. Process CPU is measured without baseline subtraction.'}
    f.save('observer-only-2hz-baseline.json',receipt)
    print(json.dumps({'event':'observer_only_baseline','database':receipt['database']}),flush=True)
    return receipt


def continue_trials(f):
    revision={'wall_time':time.time(),'revision':1,'reason':'Observer-only baseline disproved large Java diagnostic floor; preserve original every-loop fullESstats. Same-owner coordinator handoff only, no instrument cadence change.','es_diagnostic_interval_seconds':0,'database_resource_wait_seconds':.5,'counter_time':'request/read bracket retained','database_restarted':False,'previous_revision_formal_trials':0,'all_new_trials_profile_unchanged':True}
    f.summary['instrumentation_revision']=revision;f.summary['experiment']['instrumentation_revision']=1
    f.save('instrumentation-revision.json',revision)
    shutil.copyfile(HERE/'compare-load.py',f.root/'compare-load-continuation.py')
    shutil.copyfile(Path(__file__),f.root/'continuation.py')
    f.summary.setdefault('interrupted_trials',[]).append({'prefix':'r008','reason':'Coordinator paused to investigate instrumentation floor; full client output was not captured before handoff. No CPU/health/audit qualification claimed. DB process unchanged.','instrument_failed':True})
    f.save('r008-interrupted.json',f.summary['interrupted_trials'][-1])
    f.summary.setdefault('calibrations',[]).append({'mode':'direct','write_every':10,'round':0,'qualified':False,'rate':None,'attempts':['r002','r003','r004','r005','r006','r007'],'reason':'Original six calibration trials exhausted target gate; preserved before same-process observer-baseline diagnosis.'})
    amendment={'authorized_wall_time':time.time(),'authority':'root samefixture measured observer baseline disproved diagnostic floor; preserve original2Hz instrumentation','mixed':'One additional60s commonwarm220/s splitD/W30s each, then recalibrationround1 andround2 only, Dinitial120/Winitial3000; oldround0 failure andr008 interrupted preserved; no thirdrecalibrationround','pure':'Original independent protocol commonwarm>=60s and initialround0 plus atmost2recalibrationrounds','CPU_target':.10,'formal_health_gate_unchanged':True,'database_restart':False,'baseline_subtracted':False}
    f.save('protocol-amendment.json',amendment);f.summary['protocol_amendment']=amendment;f.save('summary.json',f.summary)
    orders=[['direct','weir'],['weir','direct'],['direct','weir']]
    for write_every in (10,1):
        workload='mixed' if write_every==10 else 'pure'
        suite.idle(f,workload+'-continuation-before')
        for mode in ('direct','weir'):
            warm_options={'stage':'common-prewarm-continuation','mode':mode,'rate':220 if write_every==10 else 800,'warm':0,'seconds':30,'write_every':write_every}
            record=suite.stage(f,warm_options);record['instrumentation_revision']=1
        suite.idle(f,workload+'-continuation-after-commonwarm')
        rates={'direct':120 if write_every==10 else 800,'weir':3000 if write_every==10 else 2800};latest={}
        rounds=(1,2) if write_every==10 else (0,1,2)
        for round_number in rounds:
            pending=[number for number,pair in latest.items() if not pair['matched'] or not pair['healthy_qualified']] if latest else list(range(3))
            if not pending:break
            selection={}
            for mode in ('direct','weir'):
                options={'mode':mode,'write_every':write_every,'round':round_number,'initial_rate':rates[mode]}
                selection[mode]=suite.calibrate(f,options)
            f.summary.setdefault('calibrations',[]).extend(selection.values());f.save('summary.json',f.summary)
            if any(r.get('rate') is None for r in selection.values()):
                by_id={r['prefix']:r for r in f.summary['runs']}
                for mode,choice in selection.items():
                    if choice.get('rate') is not None:rates[mode]=choice['rate']
                    elif choice['attempts']:
                        closest=min((by_id[p] for p in choice['attempts']),key=lambda r:abs(r['database']['cpu_cores_mean']-.10))
                        rates[mode]=closest['rate']
                continue
            rates={mode:r['rate'] for mode,r in selection.items()}
            print(json.dumps({'event':'rates_locked','workload':workload,'round':round_number,'rates':rates}),flush=True)
            for number in pending:
                options={'order':orders[number],'rates':rates,'write_every':write_every,'pair':number,'round':round_number}
                latest[number]=suite.run_pair(f,options)
        f.summary.setdefault('selected_pairs',{})[workload]=list(latest.values());f.save('summary.json',f.summary)
        suite.idle(f,workload+'-after-formal')
    f.summary['experiment']['completed']=time.time();f.save('summary.json',f.summary)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('raw',type=Path);parser.add_argument('--diagnose-only',action='store_true')
    args=parser.parse_args();f=adopt(args.raw)
    if args.diagnose_only:
        observer_baseline(f)
        # Explicit handoff has sole ownership; the human-authorized next turn
        # immediately adopts these same objects and performs final cleanup.
        return
    def interrupted(_signum,_frame):raise KeyboardInterrupt('continuation interrupted; owned cleanup follows')
    signal.signal(signal.SIGTERM,interrupted)
    try:continue_trials(f)
    finally:
        if not f.cleanup():raise RuntimeError('owned continuation cleanup failed')


if __name__=='__main__':main()
