#!/usr/bin/env python3
"""One final independent pure-write fixture, frozen binaries and bounded rounds."""
import argparse
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import sys
import time

HERE=Path(__file__).parent;sys.path.insert(0,str(HERE))
spec=importlib.util.spec_from_file_location('equal_cpu',HERE/'equal-cpu-es.py')
suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
c=suite.comparison;c.REPO=Path('/Users/liran/Projects/liran/go/weir')


class PureFixture(suite.EqualCPUFixture):
    def restart_idle_client(self,force=False):
        identity=c.run(['docker','inspect','--format','{{.Id}} {{.Config.Image}} {{index .Config.Labels "'+c.LABEL+'"}}',self.client]).stdout.split()
        if identity!=[self.client,self.image,self.owner]:raise RuntimeError('client restart ownership/image mismatch')
        state=json.loads(c.run(['docker','inspect','--format','{{json .State}}',self.client]).stdout)
        started=datetime.datetime.fromisoformat(state['StartedAt'].replace('Z','+00:00')).timestamp()
        if not force and time.time()-started<25*60:return
        top=c.run(['docker','top',self.client,'-eo','pid,args']).stdout
        commands=[line.split(maxsplit=1)[1] for line in top.splitlines()[1:] if line.strip()]
        if commands!=['/client -mode idle']:raise RuntimeError('client restart requires only owned idle PID1')
        limits=c.run(['docker','inspect','--format','{{.HostConfig.NanoCpus}} {{.HostConfig.CpusetCpus}} {{.HostConfig.Memory}}',self.client]).stdout.split()
        if limits!=['2000000000','1,2',str(2048*2**20)]:raise RuntimeError('client restart limits mismatch')
        db_state=json.loads(c.run(['docker','inspect','--format','{{json .State}}',self.db]).stdout)
        before={'state':state,'top':top,'limits':limits,'database_state':db_state,'identity':identity}
        requested=time.time();c.run(['docker','restart','--time','5',self.client])
        after=json.loads(c.run(['docker','inspect','--format','{{json .State}}',self.client]).stdout)
        db_after=json.loads(c.run(['docker','inspect','--format','{{json .State}}',self.db]).stdout)
        if not after['Running'] or after['StartedAt']==state['StartedAt'] or db_after['Pid']!=db_state['Pid'] or db_after['StartedAt']!=db_state['StartedAt']:
            raise RuntimeError('safe idle restart process state invalid')
        snapshot=c.run(['docker','exec',self.client,'/client','-mode','snapshot'])
        probe=json.loads(snapshot.stdout)
        if probe.get('errors') or probe['process']['identity']['exe_sha256']!=self.summary['provenance']['binary_sha256']['client']:
            raise RuntimeError('restarted frozen helper identity invalid')
        receipt={'requested_wall_time':requested,'completed_wall_time':time.time(),'forced_preflight':force,'client_container':self.client,'before':before,'after':after,'database_after':db_after,'helper_snapshot':probe,'note':'Exact labelled idle client only. Same cid/image/limits, frozen binary. No active trial/pace, no DB restart. Future restarts only before a trial at>=25minutes.'}
        events=self.summary.setdefault('idle_client_restarts',[]);events.append(receipt)
        self.save('client-restart-'+str(len(events))+'.json',receipt);self.save('summary.json',self.summary)

    def trial(self,mode,rate,repetition,write_every):
        self.restart_idle_client()
        return super().trial(mode,rate,repetition,write_every)

    def capture_failure(self,error):
        observations=[]
        for cid in self.ids:
            owner=c.run(['docker','inspect','--format','{{index .Config.Labels "'+c.LABEL+'"}}',cid],check=False)
            if owner.returncode==0 and owner.stdout.strip()==self.owner:
                state=c.run(['docker','inspect','--format','{{json .State}}',cid],check=False)
                top=c.run(['docker','top',cid,'-eo','pid,etime,args'],check=False)
                observations.append({'container':cid,'state':json.loads(state.stdout) if state.returncode==0 else state.stderr,'top':top.stdout,'top_status':top.returncode})
        receipt={'wall_time':time.time(),'error':str(error),'owned_states_before_finally':observations,'audit_or_ledger_incomplete_trials_excluded':True}
        self.save('failure-state-before-cleanup.json',receipt)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path);parser.add_argument('bin_dir',type=Path);parser.add_argument('reference',type=Path);parser.add_argument('plan',type=Path);parser.add_argument('manifest',type=Path)
    args=parser.parse_args();plan=json.loads(args.plan.read_text())
    for name,key in [('weir','weir_binary_sha256'),('client','common_client_sha256')]:
        if hashlib.sha256((args.bin_dir/name).read_bytes()).hexdigest()!=plan['provenance'][key]:raise RuntimeError('frozen binary mismatch')
    reference=json.loads((args.reference/'summary.json').read_text());values=reference['provenance']['options'].copy()
    values.update(client=args.bin_dir/'client',weir=args.bin_dir/'weir',baseline_weir=None,output=args.output,workers=64,pool=2,direct_pool=4,batch_operations=32,collect_ms=5,max_read_size='16KiB',seconds=30,warm=20,client_queue=256,modes='direct,weir',rates='670,2360,3730',write_every='1',db_cpu=.25,weir_cpu=4,recovery_rate=0,recovery_seconds=0,run_prefix_offset=0,allow_failed_unused_pacing=True)
    options=argparse.Namespace(**values);f=PureFixture(options)
    def interrupted(_signum,_frame):raise KeyboardInterrupt('final pure fixture interrupted; capture and cleanup follow')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        f.start()
        for path in HERE.glob('*.py'):shutil.copyfile(path,f.root/path.name)
        shutil.copyfile(args.plan,f.root/'plan.json');shutil.copyfile(args.manifest,f.root/'frozen-v4-manifest.json')
        f.save('resource-system.json',{'clock_ticks':f.db_ticks,'page_size':f.db_page_size,'database_container':f.db,'database_pid':f.db_pid})
        f.summary['experiment']={'kind':'one final independent pure-only equal-DB-CPU cohort','target_cpu':.10,'storage':'new uniform owned ordinary disk volume','plan':plan,'started':time.time(),'rounds_allowed':[1,2],'prior_round0':'Original cohort purecal r031-34 ended in fixture failure; retained independently, no prior rates/CPU reused.'}
        f.restart_idle_client(force=True)
        suite.idle(f,'pure-before-commonwarm')
        for mode in ('direct','weir'):
            warm={'stage':'common-prewarm','mode':mode,'rate':800,'warm':0,'seconds':30,'write_every':1};suite.stage(f,warm)
        suite.idle(f,'pure-after-commonwarm')
        rates={'direct':670,'weir':2360};latest={};orders=[['direct','weir'],['weir','direct'],['direct','weir']]
        for round_number in (1,2):
            pending=[n for n,p in latest.items() if not p['matched'] or not p['healthy_qualified']] if latest else list(range(3))
            if not pending:break
            selection={}
            for mode in ('direct','weir'):
                opts={'mode':mode,'write_every':1,'round':round_number,'initial_rate':rates[mode]};selection[mode]=suite.calibrate(f,opts)
            f.summary.setdefault('calibrations',[]).extend(selection.values());f.save('summary.json',f.summary)
            if any(v.get('rate') is None for v in selection.values()):
                by_id={r['prefix']:r for r in f.summary['runs']}
                for mode,v in selection.items():
                    if v.get('rate') is not None:rates[mode]=v['rate']
                    elif v['attempts']:rates[mode]=min((by_id[p] for p in v['attempts']),key=lambda r:abs(r['database']['cpu_cores_mean']-.1))['rate']
                continue
            rates={mode:v['rate'] for mode,v in selection.items()}
            print(json.dumps({'event':'rates_locked','workload':'pure','round':round_number,'rates':rates}),flush=True)
            for number in pending:
                opts={'order':orders[number],'rates':rates,'write_every':1,'pair':number,'round':round_number};latest[number]=suite.run_pair(f,opts)
        f.summary['selected_pairs']={'pure':list(latest.values())};f.summary['experiment']['completed']=time.time();f.save('summary.json',f.summary)
        suite.idle(f,'pure-after-formal')
    except BaseException as error:
        f.capture_failure(error);raise
    finally:
        if not f.cleanup():raise RuntimeError('final pure fixture cleanup failed')


if __name__=='__main__':main()
