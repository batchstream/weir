import importlib.util
import json
import time
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent
RESULTS=[]
PAIRS=[]
CALIBRATION=[]


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def save():
    value={'results':RESULTS,'pairs':PAIRS,'calibration':CALIBRATION}
    (ROOT/'suite-progress.json').write_text(json.dumps(value,indent=2))


def case(opts):
    runner=module('equal-case')
    analyzer=module('equal-analysis')
    output=runner.run(opts)
    result=analyzer.analyze(output)
    RESULTS.append(result)
    disk=runner.shell('df -k /data/db /bench', 'database')
    (output/'disk-after.txt').write_text(disk+'\n')
    save()
    return result


def options(value):
    defaults={'binary':'weir-v4','pool':4,'warm':20,'workers':64,'memory_mib':4608,'cap':2,'batch':32,'client_queue':256}
    defaults.update(value)
    opts=SimpleNamespace(**defaults)
    return opts


def idle():
    runner=module('equal-case')
    before=runner.identity()
    runner.shell('/bench/sampler-io -pid 1 -output /bench/common-idle-database.jsonl > /bench/common-idle-sampler.log 2>&1 < /dev/null & echo $! > /bench/common-idle-sampler.pid','database')
    time.sleep(20)
    runner.shell('stop_pid=$(cat /bench/common-idle-sampler.pid); test "$(cat /proc/$stop_pid/comm)" = sampler-io; kill -TERM "$stop_pid"','database')
    raw=runner.http('common-idle-database.jsonl')
    (ROOT/'common-idle-database.jsonl').write_bytes(raw)
    after=runner.identity()
    disk=runner.shell('df -k /data/db /bench','database')
    (ROOT/'common-idle-disk.txt').write_text(disk+'\n')
    value={'before':before,'after':after,'idle_seconds':20,'no_running_load':True,'weir_application_running':False}
    (ROOT/'common-idle.json').write_text(json.dumps(value,indent=2))
    message={'stage':'common-idle','finished':True,'database':after}
    print(json.dumps(message),flush=True)


def calibrate(opts):
    current=opts.rate
    cap=6400 if opts.workload=='mixed' else 3730
    candidates=[]
    for attempt in range(1,7):
        value={'mode':opts.mode,'tag':'cal-'+opts.workload+'-'+opts.mode+'-r'+str(opts.round)+'-'+str(attempt),'rate':current,'write_every':opts.write_every,'seconds':30,'collect_ms':opts.collect_ms,'stage':'calibration','workload':opts.workload,'calibration_round':opts.round,'calibration_attempt':attempt}
        trial=options(value)
        result=case(trial)
        cpu=result['database']['process_cpu_cores']
        if result['qualified']:
            candidates.append(result)
            if .098<=cpu<=.102:
                break
        if not result['qualifications']['evidence'] or not result['qualifications']['API_UNKNOWN_zero']:
            message={'calibration_boundary':True,'tag':result['tag'],'qualifications':result['qualifications']}
            print(json.dumps(message),flush=True)
            break
        proposed=max(1,min(cap,round(current*max(.5,min(1.8,.1/cpu))))) if cpu>0 else min(cap,current*2)
        if proposed==current:
            break
        current=proposed
    selected=min(candidates,key=lambda item:abs(item['database']['process_cpu_cores']-.1)) if candidates else None
    record={'workload':opts.workload,'mode':opts.mode,'round':opts.round,'initial_rate':opts.rate,'max_trials':6,'selected_tag':selected['tag'] if selected else None,'selected_rate':selected['offered_rate'] if selected else None,'qualified':selected is not None,'trials':[result['tag'] for result in RESULTS if result['stage']=='calibration' and result['tag'].startswith('cal-'+opts.workload+'-'+opts.mode+'-r'+str(opts.round)+'-')]}
    CALIBRATION.append(record)
    save()
    message={'rate_freeze':record,'selected_cpu':selected['database']['process_cpu_cores'] if selected else None,'selected_drop':selected['overall_measure']['client_drop'] if selected else None,'selected_lag_p99_ms':selected['scheduler_lag_p99_ms'] if selected else None}
    print(json.dumps(message),flush=True)
    return selected


def pair(opts):
    records={}
    for mode in opts.order:
        value={'mode':mode,'tag':'formal-'+opts.workload+'-'+str(opts.pair_index)+'-'+mode+opts.suffix,'rate':opts.rates[mode],'write_every':opts.write_every,'seconds':60,'collect_ms':opts.collect_ms,'stage':'formal' if not opts.suffix else 'formal_supplement','workload':opts.workload,'pair_index':opts.pair_index,'cohort':opts.cohort}
        trial=options(value)
        records[mode]=case(trial)
    dcpu=records['direct']['database']['process_cpu_cores']
    wcpu=records['weir']['database']['process_cpu_cores']
    difference=abs(dcpu-wcpu)/((dcpu+wcpu)/2)
    matched=all(item['qualified'] for item in records.values()) and difference<=.05
    value={'workload':opts.workload,'pair_index':opts.pair_index,'cohort':opts.cohort,'order':opts.order,'tags':{mode:item['tag'] for mode,item in records.items()},'rates':opts.rates,'DB_CPU':{'direct':dcpu,'weir':wcpu},'cpu_relative_mean_difference':difference,'CPU_target_pass':all(item['qualifications']['CPU_in_target'] for item in records.values()),'all_cell_qualification_pass':all(item['qualified'] for item in records.values()),'matched':matched,'successful_RPS':{mode:item['success_per_second'] for mode,item in records.items()},'RPS_ratio_weir_to_direct':records['weir']['success_per_second']/records['direct']['success_per_second']}
    PAIRS.append(value)
    save()
    message={'formal_pair_complete':value}
    print(json.dumps(message),flush=True)
    return value


def main():
    plan=json.loads((ROOT/'plan.json').read_text())
    initial={'mixed':{'direct':900,'weir':3000},'pure':{'direct':400,'weir':1600}}
    commonvalue={'mode':'direct','tag':'common-prewarm','rate':900,'write_every':10,'seconds':40,'collect_ms':10,'stage':'common','workload':'mixed'}
    common=options(commonvalue)
    case(common)
    idle()
    for workload in ('mixed','pure'):
        write_every=10 if workload=='mixed' else 1
        collect=10 if workload=='mixed' else 5
        selected={}
        for mode in ('direct','weir'):
            value={'workload':workload,'mode':mode,'rate':initial[workload][mode],'round':0,'write_every':write_every,'collect_ms':collect}
            opts=SimpleNamespace(**value)
            chosen=calibrate(opts)
            if chosen is not None:
                selected[mode]=chosen['offered_rate']
        if len(selected)!=2:
            message={'workload_boundary':workload,'formal_skipped':'one or both paths have no qualified calibration','selected':selected}
            print(json.dumps(message),flush=True)
            continue
        freeze={'workload':workload,'rates':selected,'round':0,'frozen_before_formal':True,'warm_seconds':20,'measure_seconds':60}
        (ROOT/('rate-freeze-'+workload+'.json')).write_text(json.dumps(freeze,indent=2))
        message={'formal_start':freeze}
        print(json.dumps(message),flush=True)
        originals=[]
        for index,order in enumerate((('direct','weir'),('weir','direct'),('direct','weir')),1):
            value={'workload':workload,'pair_index':index,'cohort':0,'suffix':'','rates':selected,'write_every':write_every,'collect_ms':collect,'order':order}
            opts=SimpleNamespace(**value)
            originals.append(pair(opts))
        pending=[item for item in originals if not item['matched']]
        for round_index in (1,2):
            if not pending:
                break
            refined={}
            for mode in ('direct','weir'):
                last=next(item for item in reversed(RESULTS) if item['workload']==workload and item['mode']==mode and item['stage'].startswith('formal'))
                cpu=last['database']['process_cpu_cores']
                cap=6400 if workload=='mixed' else 3730
                rate=max(1,min(cap,round(last['offered_rate']*.1/cpu))) if cpu>0 else selected[mode]
                value={'workload':workload,'mode':mode,'rate':rate,'round':round_index,'write_every':write_every,'collect_ms':collect}
                opts=SimpleNamespace(**value)
                chosen=calibrate(opts)
                if chosen is not None:
                    refined[mode]=chosen['offered_rate']
            if len(refined)!=2:
                message={'workload_boundary':workload,'supplement_skipped':round_index,'selected':refined}
                print(json.dumps(message),flush=True)
                break
            replacement=[]
            for item in pending:
                value={'workload':workload,'pair_index':item['pair_index'],'cohort':round_index,'suffix':'-r'+str(round_index),'rates':refined,'write_every':write_every,'collect_ms':collect,'order':item['order']}
                opts=SimpleNamespace(**value)
                current=pair(opts)
                if not current['matched']:
                    replacement.append(current)
            pending=replacement
    summary={'formal_pairs':PAIRS,'calibration':CALIBRATION,'trials':len(RESULTS),'source_plan':plan,'complete':True}
    (ROOT/'suite-final.json').write_text(json.dumps(summary,indent=2))
    message={'suite_complete':True,'trials':len(RESULTS),'formal_pairs':len(PAIRS),'matched_pairs':sum(item['matched'] for item in PAIRS)}
    print(json.dumps(message),flush=True)
