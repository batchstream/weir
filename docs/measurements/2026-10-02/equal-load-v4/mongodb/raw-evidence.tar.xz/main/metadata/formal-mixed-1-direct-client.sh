set -eu
mkfifo /bench/formal-mixed-1-direct/formal-mixed-1-direct.pipe
cat /bench/formal-mixed-1-direct/formal-mixed-1-direct.pipe > /bench/formal-mixed-1-direct/formal-mixed-1-direct-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 900 -warm 20 -seconds 60 -prefix formal-mixed-1-direct -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 8200 > /bench/formal-mixed-1-direct/formal-mixed-1-direct.pipe 2> /bench/formal-mixed-1-direct/formal-mixed-1-direct-client-stderr.log
wait "$reader"
touch /bench/formal-mixed-1-direct/formal-mixed-1-direct.done
