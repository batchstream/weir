set -eu
mkfifo /bench/common-prewarm/common-prewarm.pipe
cat /bench/common-prewarm/common-prewarm.pipe > /bench/common-prewarm/common-prewarm-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 900 -warm 20 -seconds 40 -prefix common-prewarm -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 6400 > /bench/common-prewarm/common-prewarm.pipe 2> /bench/common-prewarm/common-prewarm-client-stderr.log
wait "$reader"
touch /bench/common-prewarm/common-prewarm.done
