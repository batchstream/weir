set -eu
mkfifo /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3.pipe
cat /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3.pipe > /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 2145 -warm 20 -seconds 30 -prefix cal-mixed-weir-r0-3 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 11725 > /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3.pipe 2> /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3-client-stderr.log
wait "$reader"
touch /bench/cal-mixed-weir-r0-3/cal-mixed-weir-r0-3.done
