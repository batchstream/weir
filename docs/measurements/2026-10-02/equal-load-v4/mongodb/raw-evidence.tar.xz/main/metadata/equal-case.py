import argparse
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import shlex
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
OWNER = json.loads((ROOT / 'state.json').read_text())['owner']
ENV = dict(os.environ)
ENV['KUBECTL_REMOTE_COMMAND_WEBSOCKETS'] = 'false'
HTTP = 'http://127.0.0.1:19187'


def kube(args, role=None, timeout=60):
    command = ['kubectl', '-n', OWNER]
    if role:
        command += ['exec', 'fixture', '-c', role, '--']
    result = subprocess.run(command + args, env=ENV, capture_output=True,
                            text=True, timeout=timeout, check=True)
    return result.stdout.strip()


def put(path):
    kube(['cp', str(path), 'fixture:/bench/' + path.name, '-c', 'client'], timeout=90)


def shell(script, role='client'):
    return kube(['sh', '-c', script], role)


def http(name):
    with urllib.request.urlopen(HTTP + '/' + name, timeout=5) as response:
        return response.read()


def identity():
    raw = shell('cat /proc/1/comm /proc/1/stat /sys/fs/cgroup/cpu.max; date +%s.%N', 'database')
    lines = raw.splitlines()
    stat = lines[1][lines[1].rfind(')') + 2:].split()
    pod = json.loads(kube(['get', 'pod', 'fixture', '-o', 'json']))
    database = next(c for c in pod['status']['containerStatuses'] if c['name'] == 'database')
    value = {'comm': lines[0], 'start_ticks': int(stat[19]), 'cpu_max': lines[2],
             'wall_time': float(lines[3]), 'container_id': database['containerID'],
             'restart_count': database['restartCount']}
    if value['comm'] != 'mongod':
        raise RuntimeError('database PID1 is not mongod')
    with (ROOT / 'database-identity.jsonl').open('a') as log:
        log.write(json.dumps({'raw': raw, 'parsed': value}) + '\n')
    return value




def wait_file(name, timeout=180):
    until = time.monotonic() + timeout
    while time.monotonic() < until:
        try:
            return http(name)
        except Exception:
            time.sleep(0.5)
    raise RuntimeError('missing owned evidence file: ' + name)


def run(opts):
    mode, tag, rate = opts.mode, opts.tag, opts.rate
    write_every = opts.write_every
    namespace = json.loads(kube(['get', 'namespace', OWNER, '-o', 'json']))
    if namespace['metadata']['labels'].get('weir.load-comparison.owner') != OWNER:
        raise RuntimeError('namespace owner mismatch')
    output = ROOT / tag
    output.mkdir()
    hashes = shell('sha256sum /bench/weir-v4 /bench/client-final /bench/sampler-io')
    (output / 'remote-binary-hashes.txt').write_text(hashes + '\n')
    before = identity()
    if before['cpu_max'] != '25000 100000':
        raise RuntimeError('constant database quota changed')
    transitions = [{'phase': 'constant', 'actual': before}]
    binary = opts.binary
    basic = {'listeners': {'application': '127.0.0.1:7447'},
             'diagnostics': {'address': '127.0.0.1:7449'}, 'memory': str(opts.memory_mib)+'MiB',
             'transport': {'max_connections': 16, 'max_sessions': opts.workers}}
    local = {'max_concurrency': opts.cap, 'max_batch_operations': opts.batch,
             'mongodb': {'uri': 'mongodb://127.0.0.1:27017/?directConnection=true'}}
    local.update(batch_collect=str(opts.collect_ms)+'ms', max_read_size='16KiB')
    routes = {'services': [{'name': 'database', 'local': local}],
              'routes': [{'store': 'records', 'service': 'database'}]}
    for kind, value in [('node', basic), ('routes', routes)]:
        path = ROOT / (tag + '-' + kind + '.json')
        path.write_text(json.dumps(value, indent=2))
        put(path)
    shell('mkdir /bench/' + tag)
    stem = '/bench/' + tag + '/' + tag
    start = ' '.join(['/bench/' + binary, 'serve', '--config', '/bench/' + tag + '-node.json',
                      '--routes', '/bench/' + tag + '-routes.json'])
    if mode == 'weir':
        shell(start + ' > ' + stem + '-weir.log 2>&1 < /dev/null & echo $! > ' + stem + '-weir.pid', 'weir')
        shell('for n in 1 2 3 4 5 6 7 8 9 10; do wget -q -O /dev/null http://127.0.0.1:7449/readyz && exit 0; sleep 0.5; done; exit 1', 'weir')
        target_pid = '"$(cat ' + stem + '-weir.pid)"'
        metrics = ' -metrics http://127.0.0.1:7449/metrics'
    else:
        target_pid = '1'
        metrics = ''
    shell('/bench/sampler-io -pid ' + target_pid + ' -output ' + stem + '-weir.jsonl' + metrics + ' > ' + stem + '-weir-sampler.log 2>&1 < /dev/null & echo $! > ' + stem + '-weir-sampler.pid', 'weir')
    shell('/bench/sampler-io -pid 1 -output ' + stem + '-database.jsonl > ' + stem + '-database-sampler.log 2>&1 < /dev/null & echo $! > ' + stem + '-database-sampler.pid', 'database')
    command = ['env', 'WEIR_CAPACITY_INTEGRATION=1', '/bench/client-final', '-mode', 'trial',
               '-backend', 'mongodb://127.0.0.1:27017/?directConnection=true', '-target', '127.0.0.1:7447' if mode == 'weir' else '',
               '-rate', str(rate), '-warm', str(opts.warm), '-seconds', str(opts.seconds), '-prefix', tag,
               '-pool', str(opts.pool), '-workers', str(opts.workers), '-write-every', str(write_every),
               '-arrival-expiry-ms', '100', '-max-catchup', '512', '-client-queue', str(opts.client_queue),
               '-load-delay-ms', '3000', '-mutation-reservation', str(1000 + rate * (opts.warm + opts.seconds) // write_every)]
    script = 'set -eu\nmkfifo ' + stem + '.pipe\ncat ' + stem + '.pipe > ' + stem + '-client.jsonl &\nreader=$!\n' + shlex.join(command) + ' > ' + stem + '.pipe 2> ' + stem + '-client-stderr.log\nwait "$reader"\ntouch ' + stem + '.done\n'
    path = ROOT / (tag + '-client.sh')
    path.write_text(script)
    put(path)
    shell('cp /bench/'+tag+'-node.json /bench/'+tag+'-routes.json /bench/'+path.name+' /bench/'+tag+'/')
    shell('sh /bench/' + path.name + ' > ' + stem + '-client-launch.log 2>&1 < /dev/null &')
    begin = None
    for _ in range(90):
        try:
            raw = http(tag + '/' + tag + '-client.jsonl')
        except Exception:
            time.sleep(0.5)
            continue
        for line in raw.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if value.get('type') == 'client_start':
                begin = datetime.datetime.fromisoformat(value['sample']['end'].replace('Z', '+00:00')).timestamp() + 3.02
                break
        if begin is not None:
            break
        time.sleep(0.5)
    if begin is None:
        raise RuntimeError('client start marker absent')
    message = {'tag': tag, 'mode': mode, 'estimated_load_start': begin}
    print(json.dumps(message), flush=True)
    wait_file(tag + '/' + tag + '.done')
    shell('stop_pid=$(cat ' + stem + '-database-sampler.pid); test "$(cat /proc/$stop_pid/comm)" = sampler-io; kill -TERM "$stop_pid"', 'database')
    shell('stop_pid=$(cat ' + stem + '-weir-sampler.pid); test "$(cat /proc/$stop_pid/comm)" = sampler-io; kill -TERM "$stop_pid"', 'weir')
    if mode == 'weir':
        shell('stop_pid=$(cat ' + stem + '-weir.pid); test "$(cat /proc/$stop_pid/comm)" = weir-v4; kill -TERM "$stop_pid"; for n in 1 2 3 4 5 6 7 8 9 10; do test -f /proc/$stop_pid/stat || exit 0; grep -q ") Z " /proc/$stop_pid/stat && exit 0; sleep 0.2; done; exit 1', 'weir')
    shell('tar -czf /bench/' + tag + '.tar.gz -C /bench ' + tag)
    archive = http(tag + '.tar.gz')
    (output / 'raw.tar.gz').write_bytes(archive)
    remote_hash = shell('sha256sum /bench/' + tag + '.tar.gz').split()[0]
    if hashlib.sha256(archive).hexdigest() != remote_hash:
        raise RuntimeError('raw archive checksum mismatch')
    manifest = {'tag': tag, 'mode': mode, 'rate': rate, 'write_every': write_every,
                'healthy_cpu_m': 250, 'constant_quota_m': 250, 'batch_operations': opts.batch, 'client_queue': opts.client_queue, 'measure_seconds': opts.seconds, 'transitions': transitions,
                'profile': vars(opts), 'raw_sha256': remote_hash, 'database_identity': identity(), 'binary_hashes': hashes,
                'database_fixed_request_cpu_m': 50, 'weir_request_cpu_m': 1000, 'client_request_cpu_m': 1000}
    after = manifest['database_identity']
    if any(before[key] != after[key] for key in ('start_ticks', 'container_id', 'restart_count', 'cpu_max')):
        raise RuntimeError('constant database identity/quota changed during trial')
    manifest['weir_process_role'] = 'application' if mode == 'weir' else 'idle-container-sleep'
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    message = {'tag': tag, 'finished': True, 'profile': vars(opts), 'raw_sha256': remote_hash}
    print(json.dumps(message), flush=True)


    return output
