set -eu
mkfifo /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1.pipe
cat /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1.pipe > /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 900 -warm 20 -seconds 30 -prefix cal-mixed-direct-r0-1 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 5500 > /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1.pipe 2> /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1-client-stderr.log
wait "$reader"
touch /bench/cal-mixed-direct-r0-1/cal-mixed-direct-r0-1.done
