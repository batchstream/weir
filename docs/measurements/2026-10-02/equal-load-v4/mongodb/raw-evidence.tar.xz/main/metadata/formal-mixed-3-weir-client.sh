set -eu
mkfifo /bench/formal-mixed-3-weir/formal-mixed-3-weir.pipe
cat /bench/formal-mixed-3-weir/formal-mixed-3-weir.pipe > /bench/formal-mixed-3-weir/formal-mixed-3-weir-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 1745 -warm 20 -seconds 60 -prefix formal-mixed-3-weir -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 14960 > /bench/formal-mixed-3-weir/formal-mixed-3-weir.pipe 2> /bench/formal-mixed-3-weir/formal-mixed-3-weir-client-stderr.log
wait "$reader"
touch /bench/formal-mixed-3-weir/formal-mixed-3-weir.done
