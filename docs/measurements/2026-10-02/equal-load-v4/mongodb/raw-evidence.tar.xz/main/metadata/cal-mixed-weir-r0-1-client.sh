set -eu
mkfifo /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1.pipe
cat /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1.pipe > /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 3000 -warm 20 -seconds 30 -prefix cal-mixed-weir-r0-1 -pool 4 -workers 64 -write-every 10 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 16000 > /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1.pipe 2> /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1-client-stderr.log
wait "$reader"
touch /bench/cal-mixed-weir-r0-1/cal-mixed-weir-r0-1.done
