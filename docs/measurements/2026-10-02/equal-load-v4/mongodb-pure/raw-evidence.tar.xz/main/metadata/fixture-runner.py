import argparse
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import subprocess
import tarfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
STATE = json.loads((ROOT/'state.json').read_text())
OWNER = STATE['owner']
LABEL = 'weir.load-comparison.owner'
ENV = dict(os.environ,KUBECTL_REMOTE_COMMAND_WEBSOCKETS='false')
HTTP = 'http://127.0.0.1:19188'
FORWARDS=[]
FORWARD_LOG=None


def kube(args,role=None,timeout=60,check=True):
    command=['kubectl','-n',OWNER]
    if role:
        command+=['exec','fixture','-c',role,'--']
    value=subprocess.run(command+args,env=ENV,capture_output=True,text=True,timeout=timeout,check=check)
    return value


def shell(script,role='client'):
    return kube(['sh','-c',script],role).stdout.strip()


def remote(name):
    with urllib.request.urlopen(HTTP+'/'+name,timeout=10) as response:
        data=response.read((32<<20)+1)
        if len(data)>32<<20:
            raise RuntimeError('owned evidence response exceeds32MiB')
        return data


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    result=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def owned():
    ns=json.loads(kube(['get','namespace',OWNER,'-o','json']).stdout)
    if ns['metadata']['labels'].get(LABEL)!=OWNER or (STATE.get('namespace_uid') and ns['metadata']['uid']!=STATE['namespace_uid']):
        raise RuntimeError('namespace owner mismatch')
    return ns


def bootstrap(opts):
    for name in ('namespace','policy','pod'):
        source=ROOT/(name+'.json')
        value=json.loads(source.read_text())
        expected=value['metadata'].get('namespace',value['metadata'].get('name'))
        if expected!=OWNER or value['metadata']['labels'].get(LABEL)!=OWNER:
            raise RuntimeError('prepared manifest owner mismatch')
    node=STATE['planned_node']['kubernetes.io/hostname']
    raw_node=kube(['get','node',node,'-o','json']).stdout
    (ROOT/'node-before.json').write_text(raw_node)
    info=json.loads(raw_node);conditions={entry['type']:entry['status'] for entry in info['status']['conditions']}
    if info['status']['nodeInfo']['architecture']!='arm64' or int(info['status']['capacity']['cpu'])<8 or info['spec'].get('unschedulable') or info['spec'].get('taints') or info['metadata'].get('deletionTimestamp') or conditions.get('Ready')!='True' or any(conditions.get(name)!='False' for name in ('MemoryPressure','DiskPressure','PIDPressure')):
        raise RuntimeError('selected node failed fresh ARM capacity/readiness/pressure/taint check')
    (ROOT/'node-before-describe.txt').write_text(kube(['describe','node',node]).stdout)
    (ROOT/'node-before-top.txt').write_text(kube(['top','node',node],check=False).stdout)
    prior=kube(['get','namespace',OWNER,'-o','json'],check=False)
    if prior.returncode==0 or 'NotFound' not in prior.stderr:
        raise RuntimeError('fresh namespace is not known absent')
    STATE['create_attempted']=True
    (ROOT/'state.json').write_text(json.dumps(STATE,indent=2))
    kube(['create','-f',str(ROOT/'namespace.json')])
    STATE['created']=True
    STATE['namespace_uid']=owned()['metadata']['uid']
    (ROOT/'state.json').write_text(json.dumps(STATE,indent=2))
    kube(['create','-f',str(ROOT/'policy.json')])
    kube(['create','-f',str(ROOT/'pod.json')])
    deadline=time.monotonic()+300
    while time.monotonic()<deadline:
        pod=json.loads(kube(['get','pod','fixture','-o','json']).stdout)
        (ROOT/'scheduled-pod.json').write_text(json.dumps(pod,indent=2))
        if pod['status'].get('phase')=='Running' and all(c.get('ready') for c in pod['status'].get('containerStatuses',[])):
            break
        if pod['status'].get('phase') in ('Failed','Succeeded'):
            raise RuntimeError('fixture Pod did not stay Running')
        time.sleep(1)
    else:
        raise RuntimeError('fixture scheduling/startup timed out')
    if pod['spec']['nodeName']!=STATE['planned_node']['kubernetes.io/hostname']:
        raise RuntimeError('fixture scheduled outside isolated planned node')
    STATE['pod_uid']=pod['metadata']['uid']
    (ROOT/'state.json').write_text(json.dumps(STATE,indent=2))
    (ROOT/'pod-before-trials.json').write_text(kube(['get','pod','fixture','-o','json']).stdout)
    (ROOT/'node-during-top.txt').write_text(kube(['top','node',pod['spec']['nodeName']],check=False).stdout)
    kube(['cp',str(opts.archive),'fixture:/bench/binaries.tar.gz','-c','client'],timeout=300)
    shell('tar -xzof /bench/binaries.tar.gz -C /bench; chmod 755 /bench/client-final /bench/weir-v4 /bench/sampler-io')
    hashes=shell('sha256sum /bench/client-final /bench/weir-v4 /bench/sampler-io')
    actual={Path(line.split()[1]).name:line.split()[0] for line in hashes.splitlines()}
    if actual!=opts.binary_hashes:
        raise RuntimeError('remote frozen binary hash mismatch')
    (ROOT/'remote-binary-hashes.json').write_text(json.dumps(actual,indent=2))
    units=shell('getconf CLK_TCK; getconf PAGESIZE; cat /proc/1/comm','database').splitlines()
    if units!=['100','4096','mongod']:
        raise RuntimeError('archived sampler analysis units do not match fixture')
    (ROOT/'sampler-units.json').write_text(json.dumps({'clock_ticks_per_second':100,'page_size_bytes':4096,'database_pid1':'mongod'},indent=2))
    script='rs.initiate({_id:"weir_load_test",members:[{_id:0,host:"127.0.0.1:27017"}]}); for(let i=0;i<120;i++){if(db.hello().isWritablePrimary){print(JSON.stringify({version:db.version(),hello:db.hello()}));quit(0);} sleep(500);}quit(1);'
    result=kube(['mongosh','--quiet','--norc','--eval',script],'database',timeout=90)
    (ROOT/'database-bootstrap.jsonl').write_text(result.stdout)
    shell('busybox httpd -f -p 8080 -h /bench > /bench/fixture-http.log 2>&1 < /dev/null & echo $! > /bench/fixture-http.pid')
    return pod


def owned_pod():
    owned()
    pod=json.loads(kube(['get','pod','fixture','-o','json']).stdout)
    if pod['metadata']['labels'].get(LABEL)!=OWNER or pod['metadata']['uid']!=STATE['pod_uid']:
        raise RuntimeError('owned Pod UID/label changed')
    return pod


def ensure_forward():
    current=FORWARDS[-1] if FORWARDS else None
    if current and current.poll() is None:
        try:
            remote('fixture-http.pid')
            return current
        except Exception:
            pass
    pod=owned_pod()
    if current and current.poll() is None:
        current.terminate()
        try:
            current.wait(timeout=10)
        except subprocess.TimeoutExpired:
            current.kill()
            current.wait(timeout=5)
    command=['kubectl','-n',OWNER,'port-forward','pod/fixture','19188:8080']
    process=subprocess.Popen(command,env=ENV,stdout=FORWARD_LOG,stderr=FORWARD_LOG)
    FORWARDS.append(process)
    (ROOT/'portforward.pid').write_text(str(process.pid))
    message={'wall_time':time.time(),'namespace_uid':STATE['namespace_uid'],'pod_uid':pod['metadata']['uid'],'previous_pid':current.pid if current else None,'new_pid':process.pid,'command':command,'reason':'before_case_readonly_forward_recovery; no client or mutation replay'}
    with (ROOT/'forward-recovery.jsonl').open('a') as log:
        log.write(json.dumps(message)+'\n')
    for _ in range(40):
        if process.poll() is not None:
            raise RuntimeError('recovered owned port-forward exited')
        try:
            remote('fixture-http.pid')
            return process
        except Exception:
            time.sleep(.25)
    raise RuntimeError('recovered owned HTTP not ready')


def partial_export():
    errors=[]
    current=json.loads((ROOT/'current-case.json').read_text()) if (ROOT/'current-case.json').exists() else {}
    try:
        pod=owned_pod()
        (ROOT/'pod-at-failure.json').write_text(json.dumps(pod,indent=2))
        event=kube(['get','events','--field-selector','involvedObject.name=fixture','-o','json'],check=False)
        value={'exit_code':event.returncode,'stdout':event.stdout,'stderr':event.stderr}
        (ROOT/'events-at-failure.json').write_text(json.dumps(value,indent=2))
        for role in ('database','client','weir'):
            result=kube(['logs','fixture','-c',role,'--tail=100','--limit-bytes=32768'],check=False)
            (ROOT/('container-'+role+'-failure.log')).write_text(result.stdout)
        tag=current.get('tag')
        if tag and re.fullmatch('[a-zA-Z0-9-]+',tag):
            size=kube(['du','-sk','/bench/'+tag],'client',check=False)
            if size.returncode==0:
                if int(size.stdout.split()[0])>64*1024:
                    raise RuntimeError('owned failed-case raw exceeds64MiB')
                raw_path='/bench/partial-'+tag+'.tar'
                capture=kube(['tar','-cf',raw_path,'--exclude=*.pipe','-C','/bench',tag],'client',check=False)
                receipt={'exit_code':capture.returncode,'stdout':capture.stdout,'stderr':capture.stderr,'limitation':'uncompressed failed-case snapshot; active files may be partial; no writes replay'}
                (ROOT/'partial-tar-receipt.json').write_text(json.dumps(receipt,indent=2))
                kube(['cp','fixture:'+raw_path,str(ROOT/('partial-'+tag+'.tar')),'-c','client'],timeout=120)
    except Exception as error:
        errors.append(str(error))
    value={'attempted':True,'current_case':current,'errors':errors,'transport':'kubectl API/cp independent of PF; readonly evidence only'}
    (ROOT/'partial-export.json').write_text(json.dumps(value,indent=2))


def cleanup(pf):
    value={'owner':OWNER,'namespace_uid':STATE.get('namespace_uid'),'port_forward_pid':pf.pid if pf else None}
    errors=[]
    try:
        if STATE.get('create_attempted'):
            probe=kube(['get','namespace',OWNER,'-o','json'],check=False)
            if probe.returncode and 'NotFound' in probe.stderr:
                value['namespace_not_found']=probe.stderr.strip()
            else:
                probe.check_returncode()
                ns=json.loads(probe.stdout)
                if ns['metadata']['labels'].get(LABEL)!=OWNER or (STATE.get('namespace_uid') and ns['metadata']['uid']!=STATE['namespace_uid']):
                    raise RuntimeError('namespace owner/UID changed; refuse deletion')
                value['namespace_uid']=ns['metadata']['uid']
                value['delete']=kube(['delete','namespace',OWNER,'--wait=false']).stdout.strip()
                deadline=time.monotonic()+90
                while time.monotonic()<deadline:
                    result=kube(['get','namespace',OWNER,'-o','json'],check=False)
                    if result.returncode and 'NotFound' in result.stderr:
                        value['namespace_not_found']=result.stderr.strip()
                        break
                    time.sleep(1)
                if 'namespace_not_found' not in value:
                    raise RuntimeError('owned namespace cleanup missingNotFound')
    except Exception as error:
        errors.append(str(error))
    finally:
        histories=[]
        for previous in FORWARDS:
            if previous is pf:
                continue
            if previous.poll() is None:
                previous.terminate()
            try:
                code=previous.wait(timeout=10)
            except subprocess.TimeoutExpired:
                previous.kill();code=previous.wait(timeout=5)
            entry={'pid':previous.pid,'command':previous.args,'exit_code':code,'pid_absent':subprocess.run(['ps','-p',str(previous.pid),'-o','pid='],capture_output=True,text=True).returncode!=0}
            histories.append(entry)
        value['previous_port_forwards']=histories
        if pf:
            if pf.poll() is None:
                pf.terminate()
            try:
                value['port_forward_exit']=pf.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pf.kill();value['port_forward_exit']=pf.wait(timeout=5)
            value['port_forward_command']=pf.args
            value['port_forward_pid_absent']=subprocess.run(['ps','-p',str(pf.pid),'-o','pid='],capture_output=True,text=True).returncode!=0
        value['errors']=errors
        (ROOT/'cleanup.json').write_text(json.dumps(value,indent=2))
        print(json.dumps(value),flush=True)
    if errors:
        raise RuntimeError('owned fixture cleanup failed: '+str(errors))


def main():
    global FORWARD_LOG
    parser=argparse.ArgumentParser()
    parser.add_argument('--binaries',type=Path,required=True)
    parser.add_argument('--expected-hashes',type=Path,required=True)
    parser.add_argument('--node',required=True)
    parser.add_argument('--live',action='store_true')
    parser.add_argument('--fixed-cap-diagnostics',action='store_true')
    opts=parser.parse_args()
    if not opts.live:raise RuntimeError('explicit root live notice required before --live')
    STATE['planned_node']={'kubernetes.io/hostname':opts.node,'kubernetes.io/arch':'arm64'}
    pod=json.loads((ROOT/'pod.json').read_text());pod['spec']['nodeSelector']=STATE['planned_node']
    (ROOT/'pod.json').write_text(json.dumps(pod,indent=2));(ROOT/'state.json').write_text(json.dumps(STATE,indent=2))
    opts.archive=opts.binaries.resolve()
    opts.binary_hashes=json.loads(opts.expected_hashes.read_text())
    if set(opts.binary_hashes)!={'weir-v4','client-final','sampler-io'}:raise RuntimeError('frozen threebinary set required')
    (ROOT/'frozen-binaries.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(opts.archive.read_bytes()).hexdigest(),'binary_sha256':opts.binary_hashes},indent=2))
    with tarfile.open(opts.archive) as archive:
        members=archive.getmembers()
        names={member.name.lstrip('./') for member in members if member.isfile()}
        if names!=set(opts.binary_hashes) or any(not member.isfile() or member.name.startswith('/') or '..' in Path(member.name).parts for member in members):
            raise RuntimeError('frozen binary archive must contain exactly declared regular files')
        for member in members:
            if hashlib.sha256(archive.extractfile(member).read()).hexdigest()!=opts.binary_hashes[member.name.lstrip('./')]:
                raise RuntimeError('local frozen archive checksum mismatch')
    pf=None;pf_log=None
    try:
        bootstrap(opts)
        pf_log=(ROOT/'portforward.log').open('w')
        FORWARD_LOG=pf_log
        command=['kubectl','-n',OWNER,'port-forward','pod/fixture','19188:8080']
        pf=subprocess.Popen(command,env=ENV,stdout=pf_log,stderr=pf_log)
        FORWARDS.append(pf)
        (ROOT/'portforward.pid').write_text(str(pf.pid))
        for _ in range(40):
            if pf.poll() is not None:
                raise RuntimeError('owned port-forward exited')
            try:
                remote('fixture-http.pid');break
            except Exception:
                time.sleep(.25)
        else:
            raise RuntimeError('owned HTTP not ready')
        units=shell('cat /proc/1/io /sys/fs/cgroup/io.stat /sys/fs/cgroup/io.pressure','database')
        (ROOT/'database-io-before.txt').write_text(units)
        deadline=time.monotonic()+1200
        while not (ROOT/'suite-ready').exists():
            if time.monotonic()>deadline:raise RuntimeError('bounded suite preparation deadline')
            time.sleep(.5)
        suite=module('equal-suite')
        suite.main()
        (ROOT/'pod-after-trials.json').write_text(kube(['get','pod','fixture','-o','json']).stdout)
        (ROOT/'database-final-disk.txt').write_text(shell('df -h /data/db /bench; du -sh /data/db /bench','database'))
        (ROOT/'final-processes-client.txt').write_text(shell('ps','client'))
        (ROOT/'final-processes-weir.txt').write_text(shell('ps','weir'))
    except Exception as error:
        current=json.loads((ROOT/'current-case.json').read_text()) if (ROOT/'current-case.json').exists() else {}
        instrument={'exception_type':type(error).__name__,'error':str(error),'wall_time':time.time(),'tag':current.get('tag'),'classification':'instrumentation_or_fixture_failure; assess archived client business outcomes separately'}
        (ROOT/'instrumentation-error.json').write_text(json.dumps(instrument,indent=2))
        if STATE.get('created'):
            partial_export()
        raise
    finally:
        cleanup(FORWARDS[-1] if FORWARDS else pf)
        if pf_log:pf_log.close()


if __name__=='__main__':
    main()
