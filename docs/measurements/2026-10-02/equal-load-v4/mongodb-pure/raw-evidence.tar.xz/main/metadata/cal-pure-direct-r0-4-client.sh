set -eu
mkfifo /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4.pipe
cat /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4.pipe > /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 343 -warm 20 -seconds 30 -prefix cal-pure-direct-r0-4 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 18150 > /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4.pipe 2> /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4-client-stderr.log
wait "$reader"
touch /bench/cal-pure-direct-r0-4/cal-pure-direct-r0-4.done
