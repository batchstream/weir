import hashlib
import importlib.util
import io
import json
from pathlib import Path
import statistics
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
DEST=Path('/Users/liran/Projects/liran/go/weir/docs/measurements/2026-10-02/equal-load-v4/mongodb-pure')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def totals(rows):
    keys=('planned','started','success','client_drop','unknown')
    result={'measure':{key:sum(row['overall_measure'][key] for row in rows) for key in keys},'warm':{key:sum(row['warm'][key] for row in rows) for key in keys},'API_measure':sum(row['API_failures'] for row in rows),'API_warm':sum(sum((row['warm']['failures'] or {}).values()) for row in rows),'ledger_length':sum(row['ledger_length'] for row in rows),'ledger_counts':{str(code):sum(row['ledger_counts'].get(str(code),0) for row in rows) for code in range(5)},'audit_APPLIED':sum(row['audit']['applied'] for row in rows),'audit_found_documents':sum(row['audit']['found_documents'] for row in rows),'audit_UNKNOWN_found':sum(row['audit']['unknown_found'] for row in rows),'run_audit_errors_zero':all(row['run_error']=='<nil>' and row['audit']['error']=='<nil>' for row in rows),'all_checks':all(all(row['checks'].values()) for row in rows)}
    return result


def pairs(results, raw_pairs):
    bytag={row['tag']:row for row in results}
    output=[]
    for original in raw_pairs:
        value=dict(original)
        values=[bytag[value['tags'][mode]] for mode in ('direct','weir')]
        value['cpu_matched']=all(row['cpu_matched'] for row in values) and value['cpu_relative_mean_difference']<=.05
        value['healthy_qualified']=value['cpu_matched'] and all(row['healthy_qualified'] for row in values)
        value['all_evidence_valid']=all(all(row['checks'].values()) for row in values)
        value['same_initial_database_and_pod']=all(row['checks'].get('same_database_across_cohort',False) for row in values)
        healthy_without_target=all(all(check for key,check in row['qualifications'].items() if key!='CPU_in_target') and all(row['checks'].values()) for row in values)
        value['whole_measurement_healthy_without_CPU_target']=healthy_without_target
        value['secondary_nearby_CPU_healthy_observation']=healthy_without_target and value['cpu_relative_mean_difference']<=.05
        value['secondary_scope']='full60s healthy observations at actual nearby CPU points; does not satisfy fixed0.10target repeated comparison or maximum capacity'
        output.append(value)
    return output


def cohort_identity(rows, state):
    history=[json.loads(line)['parsed'] for line in (ROOT/'database-identity.jsonl').read_text().splitlines()]
    initial=history[0]
    keys=('start_ticks','container_id','restart_count')
    before=json.loads((ROOT/'pod-before-trials.json').read_text())
    finalpath=ROOT/'pod-after-trials.json'
    if not finalpath.exists():
        finalpath=ROOT/'pod-at-failure.json'
    after=json.loads(finalpath.read_text()) if finalpath.exists() else None
    beforedb=next(c for c in before['status']['containerStatuses'] if c['name']=='database')
    pod_before_valid=before['metadata']['uid']==state['pod_uid'] and before['metadata']['labels'].get('weir.load-comparison.owner')==state['owner']
    initial_container_valid=beforedb['containerID']==initial['container_id'] and beforedb['restartCount']==initial['restart_count']
    final_valid=False
    if after:
        afterdb=next(c for c in after['status']['containerStatuses'] if c['name']=='database')
        final_valid=after['metadata']['uid']==state['pod_uid'] and after['metadata']['labels'].get('weir.load-comparison.owner')==state['owner'] and afterdb['containerID']==initial['container_id'] and afterdb['restartCount']==initial['restart_count']
    history_valid=all(all(value[key]==initial[key] for key in keys) and value.get('pod_uid',state['pod_uid'])==state['pod_uid'] for value in history)
    generic=module('analyze')
    cases={}
    for row in rows:
        manifest,data=generic.load(ROOT/row['tag'])
        identities=[manifest['database_identity']]+[transition['actual'] for transition in manifest['transitions']]
        identity_valid=all(all(value[key]==initial[key] for key in keys) for value in identities)
        explicit_pod_uids=[value.get('pod_uid') for value in identities]
        pod_valid=all(uid==state['pod_uid'] for uid in explicit_pod_uids if uid is not None)
        if row['stage'].startswith('formal'):
            pod_valid=pod_valid and all(uid is not None for uid in explicit_pod_uids)
        ticks=sorted({sample['process_start_ticks'] for sample in data['database']})
        sample_valid=ticks==[initial['start_ticks']]
        checks={'initial_container':initial_container_valid,'initial_pod_uid':pod_before_valid,'history_identity':history_valid,'case_identity':identity_valid,'case_pod_uid':pod_valid,'all_raw_sample_start_ticks':sample_valid,'final_pod_uid_container':final_valid}
        valid=all(checks.values())
        row['checks']['same_database_across_cohort']=valid
        row['healthy_qualified']=row['healthy_qualified'] and valid
        cases[row['tag']]={'checks':checks,'valid':valid,'raw_start_ticks':ticks,'explicit_pod_uids':explicit_pod_uids,'common_pod_uid_missing':row['stage']=='common' and any(uid is None for uid in explicit_pod_uids)}
    proof={'initial_database_identity':initial,'initial_pod_uid':state['pod_uid'],'initial_namespace_uid':state['namespace_uid'],'pod_before_valid':pod_before_valid,'final_pod_valid':final_valid,'history_valid':history_valid,'cases':cases,'all_completed_cases_same_identity':all(value['valid'] for value in cases.values()),'common_pod_uid_provenance':'common before/after preceded explicit per-case PodUID field; bootstrap PodUID and common raw start ticks/container/restart are retained rather than altering original records'}
    proof['final_pod_snapshot_source']=finalpath.name if finalpath.exists() else None
    (ROOT/'cohort-identity-verification.json').write_text(json.dumps(proof,indent=2))
    return proof


def table(rows):
    lines=['|格|路径|offered/s|success/s|DB CPU核|Weir CPU核|DB RSS峰值MiB|Weir RSS峰值MiB|p95/p99 ms|drop|API/UNKNOWN|CPU gate|health gate|','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|']
    for row in rows:
        wc=f"{row['weir']['process_cpu_cores']:.4f}" if row['weir'] else '—'
        wr=f"{row['weir']['rss_peak_mib']:.1f}" if row['weir'] else '—'
        lines.append(f"|{row['tag']}|{row['mode']}|{row['offered_rate']}|{row['success_per_second']:.2f}|{row['database']['process_cpu_cores']:.5f}|{wc}|{row['database']['rss_peak_mib']:.1f}|{wr}|{row['measure_p95_arrival_ms']:.1f}/{row['measure_p99_arrival_ms']:.1f}|{row['overall_measure']['client_drop']}|{row['API_failures']}/{row['overall_measure']['unknown']}|{row['cpu_matched']}|{row['healthy_qualified']}|")
    return '\n'.join(lines)


def add(archive, name, raw, hashes):
    if name in hashes:
        raise RuntimeError('duplicate archive member '+name)
    if any(part in ('.env','.ssh','credentials') or part.startswith('.env.') or part.endswith(('.pem','.key')) for part in Path(name).parts):
        raise RuntimeError('sensitive member name rejected')
    info=tarfile.TarInfo(name)
    info.size=len(raw)
    info.mode=0o644
    archive.addfile(info,io.BytesIO(raw))
    hashes[name]=digest(raw)


def main(opts):
    if not (ROOT/'cleanup.json').exists():
        raise RuntimeError('cleanup must finish before export')
    if not (ROOT/'suite-final.json').exists() and not opts.partial:
        raise RuntimeError('incomplete suite requires explicit --partial')
    analyzer=module('equal-analysis')
    rows=[analyzer.analyze(path.parent) for path in sorted(ROOT.glob('*/manifest.json'))]
    suite_path=ROOT/'suite-final.json' if (ROOT/'suite-final.json').exists() else ROOT/'suite-progress.json'
    suite=json.loads(suite_path.read_text())
    state=json.loads((ROOT/'state.json').read_text())
    identity_proof=cohort_identity(rows,state)
    identities={tuple(json.loads((ROOT/row['tag']/'manifest.json').read_text())['database_identity'][key] for key in ('start_ticks','container_id','restart_count')) for row in rows}
    same_database_identity=identity_proof['all_completed_cases_same_identity']
    paired=pairs(rows,suite.get('formal_pairs',suite.get('pairs',[])))
    formal=[row for row in rows if row['stage'].startswith('formal')]
    calibration=[row for row in rows if row['stage']=='calibration']
    common=[row for row in rows if row['stage']=='common']
    cleanup=json.loads((ROOT/'cleanup.json').read_text())
    notfound=subprocess.run(['kubectl','get','namespace',state['owner'],'-o','json'],capture_output=True,text=True,timeout=60)
    independent={'command':['kubectl','get','namespace',state['owner'],'-o','json'],'exit_code':notfound.returncode,'stdout':notfound.stdout,'stderr':notfound.stderr,'NotFound':notfound.returncode!=0 and 'NotFound' in notfound.stderr}
    (ROOT/'cleanup-independent.json').write_text(json.dumps(independent,indent=2))
    if not independent['NotFound']:
        raise RuntimeError('independent cleanup is not NotFound')
    idle=[json.loads(line) for line in (ROOT/'common-idle-database.jsonl').read_text().splitlines()]
    generic=module('analyze')
    idle_resource=generic.resources(idle,(idle[0]['wall_time'],idle[-1]['wall_time']))
    failure_details=json.loads((ROOT/'failed-case.json').read_text()) if (ROOT/'failed-case.json').exists() else None
    instrumentation=json.loads((ROOT/'instrumentation-error.json').read_text()) if (ROOT/'instrumentation-error.json').exists() else None
    result={'same_database_identity_across_cohort':same_database_identity,'cohort_identities':[list(value) for value in sorted(identities)],'completed_cases':len(rows),'suite_complete':(ROOT/'suite-final.json').exists(),'instrumentation_error':instrumentation,'failed_case_unobserved_business_outcomes':failure_details,'database':'mongodb','version':'frozen-v4','scope':'successful throughput with matched measured total MongoDB process CPU, same workload/resource/quota; calibration excluded','plan':json.loads((ROOT/'plan.json').read_text()),'provenance':json.loads((ROOT/'bundle-provenance.json').read_text()),'owner':state,'cleanup':cleanup,'cleanup_independent':independent,'common_idle':idle_resource,'pairs':paired,'formal_results':formal,'calibration_results':calibration,'common_results':common,'totals':{name:totals(values) for name,values in [('formal',formal),('calibration',calibration),('common',common),('all',rows)]},'gates':{'cpu_matched':'both full measurement CPU0.095..0.105 with coverage nominal-3s and each boundarygap<=2s, pair difference to mean<=5%; all 1Hz samples, actual span','healthy_qualified':'CPUmatched and valid audit/identity/hash/conservation/coverage, OOM/API/UNKNOWN0, total measurementdrop<=0.1% and fewer than2 highdrop10s buckets, client/WeirprocessCPU below90%of2/4core and client CFS<=10%periods','timing':'sampler-io timestamps collect start and sequentially reads local proc/cgroup files; frozen sampler has no end-of-collect bracket. Client helper supplies own duration/end bracket. Not all fields exact same instant'},'attempted_formal_pairs':len(paired),'cpu_matched_pairs':sum(p['cpu_matched'] for p in paired),'healthy_qualified_pairs':sum(p['healthy_qualified'] for p in paired)}
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/'results.json').write_text(json.dumps(result,indent=2))
    (DEST/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
    (DEST/'cleanup-independent.json').write_text(json.dumps(independent,indent=2))
    for proofname in ('cleanup-local.json','failed-case.json','node-after-failure-summary.json','events-after-failure.json','cohort-identity-verification.json','mutation-semantics-verification.json','node-after-trials-summary.json'):
        if (ROOT/proofname).exists():
            (DEST/proofname).write_text((ROOT/proofname).read_text())
    (DEST/'bundle-provenance.json').write_text((ROOT/'bundle-provenance.json').read_text())
    lines=['# MongoDB 相同实际数据库 CPU 测量','', '当前为中断pure-only cohort。完整数量和未观察业务结果在results.json逐项列出；不得报告已完成三次匹配或稳定headline。' if opts.partial else '完整cohort。','', '数据库固定 quota0.25核/1536Mi、WiredTiger256Mi、oplog64Mi和普通磁盘4Gi；目标仅实际数据库总进程 CPU0.10核。Direct和Weir路径独立校准后锁速率；同workers64、client2CPU、Weir4CPU/4608Mi；directpool4，Weircap2/batch32/read16KiB/mixed10ms/pure5ms。','', '共同预热60秒及空闲采样不计正式结论。校准warm20/measure30，正式warm20/measure60；CPU使用全测量内全部1Hz计数样本的实际first/last跨度。正式吞吐为success/60秒，延迟与丢弃均只取measurement；账本审计涵盖warm+measurement。','', 'CPUmatched与healthy-qualified分列，所有失配与补测原样保留，不取10秒片段、不插值、不按CPU归一化吞吐。Direct没有运行Weir应用，Weir容器中sleep及观测器另列为idle容器，不算运行Weir的成本。','', table(formal),'','|workload|pair/cohort|CPU相对均值差|CPU matched|healthy qualified|Weir/Direct成功吞吐比|','|---|---|---:|---|---|---:|']
    for item in paired:
        lines.append(f"|{item['workload']}|{item['pair_index']}/{item['cohort']}|{item['cpu_relative_mean_difference']*100:.2f}%|{item['cpu_matched']}|{item['healthy_qualified']}|{item['RPS_ratio_weir_to_direct']:.3f}|")
    lines+=['','次要观测仅列整60秒健康、两侧实际CPU相对差≤5%的配对，不要求各侧在0.095..0.105核。它不改变主门槛、有限重校准和原始失配记录，也不算固定0.10核重复或最大容量。','', '|pair/cohort|Direct实际CPU|Weir实际CPU|CPU相对差|成功吞吐比|','|---|---:|---:|---:|---:|']
    for item in paired:
        if item['secondary_nearby_CPU_healthy_observation']:
            lines.append(f"|{item['pair_index']}/{item['cohort']}|{item['DB_CPU']['direct']:.5f}|{item['DB_CPU']['weir']:.5f}|{item['cpu_relative_mean_difference']*100:.2f}%|{item['RPS_ratio_weir_to_direct']:.3f}|")
    lines += ['','|Weir正式格|采样区间execution计数|平均batch operations|execution平均ms|pending min/max|window min/max|hold采样占比|','|---|---:|---:|---:|---:|---:|---:|']
    for row in formal:
        if row['weir'] is None:
            continue
        control=row['controller']
        lines.append(f"|{row['tag']}|{control['execution_histogram']['samples']:.0f}|{control['batch_operations']:.2f}|{control['execution_ms']:.2f}|{control['pending']['min']:.0f}/{control['pending']['max']:.0f}|{control['window']['min']:.0f}/{control['window']['max']:.0f}|{control['recovery_hold']['positive_sample_fraction']*100:.1f}%|")
    lines += ['','上表控制器计数差分/平均值为全measurement内first/last指标采样之间的区间，未覆盖每端不足1Hz的少量事件；原始trace/finalcounter保留。低目标CPU时每批固定成本可能主导属于诊断推断，不据batch/IO数值证明单一原因。']
    lines += ['',f"正式所有attempted格完整warm+measure写账本：{result['totals']['formal']['ledger_length']}；APPLIED={result['totals']['formal']['audit_APPLIED']}，UNKNOWN_found={result['totals']['formal']['audit_UNKNOWN_found']}。全部calibration/common/formal账本和totals在results.json分别列出。",'', '只有同一workload满足三次健康合格配对时，才支持该目标CPU与该部署profile下的成功吞吐比较。此结果不测最大容量、不证明相同内存/IO，也不保证其他延迟约束或任意资源下的收益。单次CPU小差异不能称性能改善。','', 'IO记录包含proc/io、cgroup io.stat和IO PSI；它们不是逐条数据库命令的IO延迟。blockdelay字段存在且值0不能证明kernel启用了delay accounting，也不能排除IO影响。数据库RSS/cache和IO允许不同，但必须保留供解释。','', 'sampler-io wall_time/monotonic取collect开始，随后顺序读本地文件；冻结采样器没有读完成bracket，因此CPU边界是1Hz读数时序估计，不能声称计数精确发生在时戳瞬间。client_sample包含time/end/duration，raw保留完整读取bracket。','', '正式节点为on-demand ip-172-31-12-243.us-west-1.compute.internal；same mongod身份与实际25000/100000配额从各raw及manifest核验。本fixture仅pure，前一mixed中断cohort独立保留，数据库PID不同不合并。中央plan统一64workers/4608Mi。','', 'cleanup.json含精确owned UID/label删除及PF子进程退出；cleanup-independent.json含独立namespace NotFound。证据原始账本、配置、实际配额、PID、CPU/RSS/IO、控制器指标与远端hash全部归档。']
    report='\n'.join(lines)+'\n'
    report+='\nDirect 和 Weir 均使用同一 localhost MongoDB URI、同一 1024-byte BSON/unique ID/ReplaceOne upsert 与 majority 写确认；Direct 等待单操作 ClientBulkWrite acknowledgement，Weir 等待 bulkWrite 命令及逐项结果校验、API 完成后才计成功。测试副本集只有一个成员；此为冻结代码和实际配置核验，没有进行 wire 抓包。pool4 与 Weir pool/cap2、batch32 属于两条部署路径的差异。详见 mutation-semantics-verification.json。\n'
    (DEST/'report.md').write_text(report)
    finding={'formal_pairs':paired,'totals':result['totals'],'idle':idle_resource,'attempted_formal_pairs':len(paired),'cpu_matched_pairs':result['cpu_matched_pairs'],'healthy_qualified_pairs':result['healthy_qualified_pairs'],'secondary_nearby_CPU_healthy_pairs':[item for item in paired if item['secondary_nearby_CPU_healthy_observation']],'limits':result['gates']}
    (DEST/'findings.json').write_text(json.dumps(finding,indent=2))
    (DEST/'findings.md').write_text(report)
    entries=[]
    hashes={}
    excluded={'frozen-binaries.tar.gz','frozen-binaries.json','suite-ready','export.log'}
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and path.name not in excluded:
            raw=path.read_bytes()
            name='main/metadata/'+path.name
            entries.append({'name':name,'source_file':str(path),'size':len(raw),'sha256':digest(raw)})
            hashes[name]=digest(raw)
    for row in rows:
        folder=ROOT/row['tag']
        for path in sorted(folder.iterdir()):
            if path.is_file():
                raw=path.read_bytes();name='main/cases/'+row['tag']+'/'+path.name
                entries.append({'name':name,'source_file':str(path),'size':len(raw),'sha256':digest(raw)})
                hashes[name]=digest(raw)
        with tarfile.open(folder/'raw.tar.gz') as source:
            for member in source.getmembers():
                if member.isfile():
                    raw=source.extractfile(member).read();name='main/raw/'+row['tag']+'/'+member.name
                    entries.append({'name':name,'source_archive':str(folder/'raw.tar.gz'),'source_member':member.name,'size':len(raw),'sha256':digest(raw)})
                    hashes[name]=digest(raw)
    inventory={'scratch':str(ROOT),'regular_members':entries,'archive_pending':not opts.archive,'member_count':len(entries)}
    (DEST/'raw-member-manifest.json').write_text(json.dumps(inventory,indent=2))
    output=DEST/'raw-evidence.tar.xz'
    if opts.archive:
        hashes={}
        with tarfile.open(output,'w:xz',preset=6) as archive:
            for entry in entries:
                if 'source_file' in entry:
                    raw=Path(entry['source_file']).read_bytes()
                else:
                    with tarfile.open(entry['source_archive']) as source:
                        raw=source.extractfile(entry['source_member']).read()
                if digest(raw)!=entry['sha256']:
                    raise RuntimeError('raw source changed after inventory')
                add(archive,entry['name'],raw,hashes)
    outputs={path.name:digest(path.read_bytes()) for path in sorted(DEST.iterdir()) if path.is_file() and path.name not in ('sha256.json','SHA256SUMS')}
    sha={'raw_evidence_sha256':digest(output.read_bytes()) if opts.archive else None,'archive_pending':not opts.archive,'raw_evidence_regular_files':hashes,'output_files':outputs}
    (DEST/'sha256.json').write_text(json.dumps(sha,indent=2))
    sums=''.join(digest(path.read_bytes())+'  '+path.name+'\n' for path in sorted(DEST.iterdir()) if path.is_file() and path.name!='SHA256SUMS')
    (DEST/'SHA256SUMS').write_text(sums)
    message={'export':str(DEST),'archive_sha':sha['raw_evidence_sha256'],'regular_members':len(hashes),'formal_pairs':len(paired),'healthy_qualified_pairs':result['healthy_qualified_pairs'],'totals':result['totals'],'independent_NotFound':independent['NotFound']}
    print(json.dumps(message),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--partial',action='store_true',help='Export an interrupted cohort without treating it as complete')
    parser.add_argument('--archive',action='store_true',help='Only after both live databases finish; otherwise export lightweight inventory without compression')
    args=parser.parse_args()
    main(args)
