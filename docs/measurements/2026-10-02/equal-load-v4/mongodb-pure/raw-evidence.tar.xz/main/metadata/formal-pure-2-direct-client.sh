set -eu
mkfifo /bench/formal-pure-2-direct/formal-pure-2-direct.pipe
cat /bench/formal-pure-2-direct/formal-pure-2-direct.pipe > /bench/formal-pure-2-direct/formal-pure-2-direct-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 338 -warm 20 -seconds 60 -prefix formal-pure-2-direct -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 28040 > /bench/formal-pure-2-direct/formal-pure-2-direct.pipe 2> /bench/formal-pure-2-direct/formal-pure-2-direct-client-stderr.log
wait "$reader"
touch /bench/formal-pure-2-direct/formal-pure-2-direct.done
