set -eu
mkfifo /bench/formal-pure-1-weir/formal-pure-1-weir.pipe
cat /bench/formal-pure-1-weir/formal-pure-1-weir.pipe > /bench/formal-pure-1-weir/formal-pure-1-weir-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 482 -warm 20 -seconds 60 -prefix formal-pure-1-weir -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 39560 > /bench/formal-pure-1-weir/formal-pure-1-weir.pipe 2> /bench/formal-pure-1-weir/formal-pure-1-weir-client-stderr.log
wait "$reader"
touch /bench/formal-pure-1-weir/formal-pure-1-weir.done
