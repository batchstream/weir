set -eu
mkfifo /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1.pipe
cat /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1.pipe > /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 410 -warm 20 -seconds 60 -prefix formal-pure-3-weir-r1 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 33800 > /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1.pipe 2> /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1-client-stderr.log
wait "$reader"
touch /bench/formal-pure-3-weir-r1/formal-pure-3-weir-r1.done
