set -eu
mkfifo /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6.pipe
cat /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6.pipe > /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target '' -rate 338 -warm 20 -seconds 30 -prefix cal-pure-direct-r0-6 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 17900 > /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6.pipe 2> /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6-client-stderr.log
wait "$reader"
touch /bench/cal-pure-direct-r0-6/cal-pure-direct-r0-6.done
