set -eu
mkfifo /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5.pipe
cat /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5.pipe > /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5-client.jsonl &
reader=$!
env WEIR_CAPACITY_INTEGRATION=1 /bench/client-final -mode trial -backend 'mongodb://127.0.0.1:27017/?directConnection=true' -target 127.0.0.1:7447 -rate 410 -warm 20 -seconds 30 -prefix cal-pure-weir-r1-5 -pool 4 -workers 64 -write-every 1 -arrival-expiry-ms 100 -max-catchup 512 -client-queue 256 -load-delay-ms 3000 -mutation-reservation 21500 > /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5.pipe 2> /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5-client-stderr.log
wait "$reader"
touch /bench/cal-pure-weir-r1-5/cal-pure-weir-r1-5.done
