import base64
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parent


def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def counters(raw):
    value={line.split()[0]:int(line.split()[1]) for line in raw.splitlines()}
    return value


def analyze(directory):
    helper=module('analyze')
    result=helper.analyze(directory)
    manifest,data=helper.load(directory)
    client=data['client']
    trialrow=next(row for row in client if row['type']=='trial')
    trial=trialrow['trial']
    audit=next(row for row in client if row['type']=='audit')
    measure=trial['measure']['all']
    ledger=base64.b64decode(audit['ledger'],validate=True)
    counts=dict(sorted(Counter(ledger).items()))
    left=helper.stamp(trial['start'])+trial['options']['WarmSeconds']
    right=left+trial['options']['Seconds']
    samples=[s for s in data['database'] if left<=s['wall_time']<=right]
    seconds=samples[-1]['wall_time']-samples[0]['wall_time'] if len(samples)>1 else 0
    coverage={'measurement_start':left,'measurement_end':right,'nominal_seconds':right-left,'samples':len(samples),'first_wall_time':samples[0]['wall_time'] if samples else None,'last_wall_time':samples[-1]['wall_time'] if samples else None,'actual_seconds':seconds,'minimum_seconds':right-left-3,'first_distance_seconds':samples[0]['wall_time']-left if samples else None,'last_distance_seconds':right-samples[-1]['wall_time'] if samples else None}
    coverage['pass']=len(samples)>1 and seconds>=right-left-3 and coverage['first_distance_seconds']<=2 and coverage['last_distance_seconds']<=2
    client_samples=[row['sample'] for row in client if row['type']=='client_sample' and left<=helper.stamp(row['sample']['time'])<=right]
    client_resource={}
    if len(client_samples)>1:
        first,last=client_samples[0],client_samples[-1];elapsed=(last['monotonic_ns']-first['monotonic_ns'])/1e9
        tick_delta=sum(last['process'][key]-first['process'][key] for key in ('user_ticks','system_ticks'))
        before=counters(first['files']['cpu.stat']);after=counters(last['files']['cpu.stat'])
        client_resource={'samples':len(client_samples),'seconds':elapsed,'process_cpu_cores':tick_delta/100/elapsed,'cgroup_cpu_cores':(after['usage_usec']-before['usage_usec'])/1e6/elapsed,'cfs_throttled_periods':after['nr_throttled']-before['nr_throttled'],'cfs_periods':after['nr_periods']-before['nr_periods'],'rss_peak_mib':max(s['process']['rss_bytes'] for s in client_samples)/1048576,'process_start_ticks':sorted({s['process']['identity']['start_ticks'] for s in client_samples}),'sample_errors':[s['errors'] for s in client_samples if s.get('errors')]}
    hashes=json.loads((ROOT/'expected-hashes.json').read_text())
    actual={Path(line.split()[1]).name:line.split()[0] for line in manifest['binary_hashes'].splitlines()}
    checks={'raw_sha':hashlib.sha256((directory/'raw.tar.gz').read_bytes()).hexdigest()==manifest['raw_sha256'],'binary_sha':actual==hashes,'run_error':trialrow['run_error']=='<nil>','audit_error':audit['error']=='<nil>','ledger_length':len(ledger)==trial['options']['Rate']*(trial['options']['WarmSeconds']+trial['options']['Seconds'])//trial['options']['WriteEvery'],'ledger_valid':set(counts).issubset({0,1,2,3,4}),'APPLIED_audited':counts.get(1,0)==audit['audit']['applied'],'ledger_matches_audit_plan':len(ledger)==audit['audit']['planned_writes'],'alltrial_conservation':all(t['all']['planned']==t['all']['started']+t['all']['client_drop'] and t['all']['started']==t['all']['success']+sum((t['all'].get('failures') or {}).values()) for t in (trial['warm'],trial['measure'])),'measurement_conservation':measure['planned']==measure['started']+measure['client_drop'] and measure['started']==measure['success']+sum((measure.get('failures') or {}).values()),'ten_second_conservation':all(w['all']['planned']==w['all']['started']+w['all']['client_drop'] and w['all']['started']==w['all']['success']+sum((w['all'].get('failures') or {}).values()) for w in trial['ten_second_windows']),'window_sums_match':all(sum(w['all'][key] for w in trial['ten_second_windows'])==measure[key] for key in ('planned','started','success','client_drop','unknown')),'DB_sample_identity':{s['process_start_ticks'] for s in data['database']}=={manifest['database_identity']['start_ticks']},'constant_actual_quota':all(s['cpu_max']=='25000 100000' for s in samples),'actual_weir_container_quota':all(s['cpu_max']=='400000 100000' for s in data['weir']),'actual_client_quota':all(s['files']['cpu.max'].strip()=='200000 100000' for s in client_samples),'coverage':coverage['pass'],'client_samples_valid':bool(client_resource) and not client_resource.get('sample_errors'),'client_identity_constant':len(client_resource.get('process_start_ticks',[]))==1}
    phase=result['phases']['healthy']
    api=sum((measure.get('failures') or {}).values())
    CPU=phase['database'].get('process_cpu_cores')
    drop_fraction=measure['client_drop']/measure['planned']
    high_drop_windows=sum(w['all']['client_drop']/w['all']['planned']>.001 for w in trial['ten_second_windows'])
    frontend=(client_resource.get('process_cpu_cores',2)>=1.8 or client_resource.get('cfs_throttled_periods',0)>max(1,client_resource.get('cfs_periods',0))*.1 or (manifest['mode']=='weir' and phase['weir'].get('process_cpu_cores',4)>=3.6))
    client_boundary={'measurement_start':left,'measurement_end':right,'sample_time_is_read_start':True,'durations_ns':[s['duration_ns'] for s in client_samples],'max_read_duration_ms':max((s['duration_ns']/1e6 for s in client_samples),default=None)}
    oom_zero=phase['database'].get('oom_kill_delta')==0 and phase['weir'].get('oom_kill_delta')==0
    qualifications={'OOM_zero':oom_zero,'CPU_in_target':CPU is not None and .095<=CPU<=.105,'coverage':coverage['pass'],'API_UNKNOWN_zero':api==0 and measure['unknown']==0,'no_sustained_drop':drop_fraction<=.001 and high_drop_windows<2,'no_frontend_bottleneck':not frontend,'evidence':all(checks.values())}
    cpu_matched=qualifications['CPU_in_target'] and qualifications['coverage']
    result.update(cpu_matched=cpu_matched,healthy_qualified=all(qualifications.values()),sampling_timing='wall_time/monotonic taken at collect start, then proc/cgroup files read sequentially; frozen sampler provides no end-of-collect bracket; not exact counter instant',stage=manifest['profile']['stage'],workload=manifest['profile']['workload'],offered_rate=manifest['rate'],success_per_second=measure['success']/trial['options']['Seconds'],database=phase['database'],weir=phase['weir'] if manifest['mode']=='weir' else None,weir_idle_container=phase['weir'] if manifest['mode']=='direct' else None,controller=phase['controller'] if manifest['mode']=='weir' else None,client=client_resource,client_sample_read_bracket=client_boundary,coverage=coverage,measure_p95_arrival_ms=measure['success_arrival']['p95_us']/1000,measure_p99_arrival_ms=measure['success_arrival']['p99_us']/1000,measure_p95_dispatch_ms=measure['success_dispatch']['p95_us']/1000,measure_p99_dispatch_ms=measure['success_dispatch']['p99_us']/1000,scheduler_lag_p99_ms=measure['lag']['p99_us']/1000,ledger_counts={str(key):value for key,value in counts.items()},ledger_length=len(ledger),checks=checks,qualifications=qualifications,qualified=all(qualifications.values()),API_failures=api,drop_fraction=drop_fraction,high_drop_windows=high_drop_windows)
    (directory/'analysis.json').write_text(json.dumps(result,indent=2))
    message={'tag':result['tag'],'stage':result['stage'],'mode':result['mode'],'rate':result['offered_rate'],'CPU':CPU,'RPS':result['success_per_second'],'drop':measure['client_drop'],'API':api,'UNKNOWN':measure['unknown'],'lag_p99_ms':result['scheduler_lag_p99_ms'],'coverage':coverage,'qualifications':qualifications}
    print(json.dumps(message),flush=True)
    return result
