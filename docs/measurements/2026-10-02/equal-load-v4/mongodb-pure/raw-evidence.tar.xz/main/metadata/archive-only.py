import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_name(name):
    parts=Path(name).parts
    if name.startswith('/') or '..' in parts:
        raise RuntimeError('unsafe archive path')
    if any(part in ('.env','.ssh','credentials') or part.startswith('.env.') or part.endswith(('.pem','.key')) for part in parts):
        raise RuntimeError('sensitive source name rejected')


def source(entry, scratch):
    path=Path(entry.get('source_file',entry.get('source_archive')))
    safe_name(str(path.relative_to(path.anchor)))
    if path.is_symlink() or not path.resolve().is_relative_to(scratch.resolve()):
        raise RuntimeError('source outside owned scratch')
    if 'source_file' in entry:
        raw=path.read_bytes()
    else:
        safe_name(entry['source_member'])
        with tarfile.open(path) as archive:
            member=archive.getmember(entry['source_member'])
            if not member.isfile():
                raise RuntimeError('source archive member is not regular')
            raw=archive.extractfile(member).read()
    if len(raw)!=entry['size'] or digest(raw)!=entry['sha256']:
        raise RuntimeError('sealed source bytes changed: '+entry['name'])
    return raw


def main(opts):
    directory=opts.directory.resolve()
    inventory_path=directory/'raw-member-manifest.json'
    inventory_bytes=inventory_path.read_bytes()
    inventory=json.loads(inventory_bytes)
    scratch=Path(inventory['scratch'])
    checksum_path=directory/'sha256.json'
    checksum=json.loads(checksum_path.read_text())
    members=inventory['regular_members']
    expected={entry['name']:entry['sha256'] for entry in members}
    if len(expected)!=len(members) or expected!=checksum['raw_evidence_regular_files']:
        raise RuntimeError('sealed inventory and source checksums disagree')
    before={path.name:digest(path.read_bytes()) for path in directory.iterdir() if path.is_file() and path.name not in ('sha256.json','SHA256SUMS')}
    output=directory/'raw-evidence.tar.xz'
    if output.exists():
        raise RuntimeError('archive already exists; do not overwrite a sealed archive')
    with tarfile.open(output,'x:xz',preset=6) as archive:
        for entry in members:
            safe_name(entry['name'])
            raw=source(entry,scratch)
            info=tarfile.TarInfo(entry['name'])
            info.size=len(raw)
            info.mode=0o644
            buffer=io.BytesIO(raw)
            archive.addfile(info,buffer)
    actual={}
    with tarfile.open(output) as archive:
        for member in archive.getmembers():
            if not member.isfile() or member.name in actual:
                raise RuntimeError('nonregular or duplicate archived member')
            actual[member.name]=digest(archive.extractfile(member).read())
    if actual!=expected:
        raise RuntimeError('archived bytes do not match sealed inventory')
    for name,original in before.items():
        if digest((directory/name).read_bytes())!=original:
            raise RuntimeError('historical output bytes changed: '+name)
    archive_sha=digest(output.read_bytes())
    receipt={'operation':'archive-only','regular_member_count':len(actual),'archive_sha256':archive_sha,'archive_bytes':output.stat().st_size,'all_member_sha256_match_sealed_inventory':True,'all_prearchive_outputs_byte_identical':True,'preserved_prearchive_output_sha256':before,'input_manifest_sha256':digest(inventory_bytes),'inventory_archive_pending_flag_preserved':inventory.get('archive_pending'),'inventory_flag_explanation':'raw-member-manifest.json retains its historical generation state. sha256.json records the completed archive; the sealed inventory and results were not regenerated.'}
    (directory/'archive-receipt.json').write_text(json.dumps(receipt,indent=2))
    checksum.update(raw_evidence_sha256=archive_sha,archive_pending=False)
    checksum['output_files']={path.name:digest(path.read_bytes()) for path in sorted(directory.iterdir()) if path.is_file() and path.name not in ('sha256.json','SHA256SUMS')}
    checksum_path.write_text(json.dumps(checksum,indent=2))
    sums=''.join(digest(path.read_bytes())+'  '+path.name+'\n' for path in sorted(directory.iterdir()) if path.is_file() and path.name!='SHA256SUMS')
    (directory/'SHA256SUMS').write_text(sums)
    message={'directory':str(directory),'regular_members':len(actual),'archive_sha256':archive_sha,'archive_bytes':output.stat().st_size,'prearchive_outputs_unchanged':True,'historical_manifest_sha256':digest(inventory_bytes)}
    print(json.dumps(message),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    main(args)
